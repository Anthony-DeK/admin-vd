import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const RESEND_API_KEY = 're_TjPMSHhY_HMh6psoTEYsxanRMnCC4edtA';
const SUPABASE_URL = 'https://hbszokfkhrodyilydqlv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhic3pva2ZraHJvZHlpbHlkcWx2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk2NTkxNzIsImV4cCI6MjA2NTIzNTE3Mn0.ff9bEGQGyRzZXEOCB5wLReH_q7qpCtxVMKWPUnBz1zE';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookingData {
  id: string;
  guest_name: string;
  guest_email: string;
  check_in: string;
  check_out: string;
  check_in_time?: string;
  check_out_time?: string;
  apartment_name: string;
  status: string;
  total_amount: number;
  guests: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { bookingData, event } = await req.json();

    console.log('Received request:', { bookingData, event });

    if (!bookingData || !event) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: bookingData and event' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Create Supabase client
    const { createClient } = await import('npm:@supabase/supabase-js@2.50.3');
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    console.log('Searching for templates with event:', event);

    // Find active templates for this event
    const { data: templates, error: templatesError } = await supabase
      .from('message_templates')
      .select('*')
      .eq('schedule_event', event)
      .eq('schedule_type', 'immediate')
      .eq('is_active', true);

    if (templatesError) {
      console.error('Template fetch error:', templatesError);
      throw new Error(`Failed to fetch templates: ${templatesError.message}`);
    }

    console.log(`Found ${templates?.length || 0} active templates`);

    if (!templates || templates.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true,
          message: 'No active templates found for this event',
          event: event,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const emailsSent = [];
    const errors = [];

    // Send email for each active template
    for (const template of templates) {
      try {
        console.log(`Processing template: ${template.name}`);

        // Get user settings for sender info
        const { data: settings } = await supabase
          .from('user_settings')
          .select('*')
          .eq('user_id', template.user_id)
          .maybeSingle();

        // Resend requires a verified domain/email. Using a default that should work for testing.
        const senderEmail = settings?.sender_email || 'onboarding@resend.dev';
        const senderName = settings?.sender_name || 'Property Manager';

        console.log(`Sender: ${senderName} <${senderEmail}>`);

        // Replace placeholders in subject and body
        let subject = template.subject;
        let body = template.body;

        const replacements = {
          '{{guest_name}}': bookingData.guest_name,
          '{{property_name}}': bookingData.apartment_name,
          '{{check_in_date}}': new Date(bookingData.check_in).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          }),
          '{{check_out_date}}': new Date(bookingData.check_out).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          }),
          '{{check_in}}': new Date(bookingData.check_in).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          }),
          '{{check_out}}': new Date(bookingData.check_out).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          }),
          '{{check_in_time}}': bookingData.check_in_time || 'Not specified',
          '{{check_out_time}}': bookingData.check_out_time || 'Not specified',
          '{{total_amount}}': `$${bookingData.total_amount.toFixed(2)}`,
          '{{guests}}': bookingData.guests.toString(),
          '{{num_guests}}': bookingData.guests.toString(),
        };

        for (const [placeholder, value] of Object.entries(replacements)) {
          subject = subject.replace(new RegExp(placeholder.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&'), 'g'), value);
          body = body.replace(new RegExp(placeholder.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&'), 'g'), value);
        }

        console.log('Email subject:', subject);

        // Get attachments for this template
        const { data: attachments } = await supabase
          .from('template_attachments')
          .select('*')
          .eq('template_id', template.id);

        console.log(`Found ${attachments?.length || 0} attachments`);

        // Prepare attachments for Resend
        const resendAttachments = [];
        if (attachments && attachments.length > 0) {
          for (const attachment of attachments) {
            try {
              // Download file from Supabase storage
              const { data: fileData, error: downloadError } = await supabase.storage
                .from('template-attachments')
                .download(attachment.storage_path);

              if (downloadError) {
                console.error(`Failed to download attachment ${attachment.file_name}:`, downloadError);
                continue;
              }

              if (fileData) {
                // Convert to base64
                const arrayBuffer = await fileData.arrayBuffer();
                const uint8Array = new Uint8Array(arrayBuffer);
                const base64 = btoa(String.fromCharCode.apply(null, Array.from(uint8Array)));
                
                resendAttachments.push({
                  filename: attachment.file_name,
                  content: base64,
                });

                console.log(`Added attachment: ${attachment.file_name}`);
              }
            } catch (err) {
              console.error(`Failed to process attachment ${attachment.file_name}:`, err);
            }
          }
        }

        // Send email via Resend
        const emailPayload: any = {
          from: `${senderName} <${senderEmail}>`,
          to: [bookingData.guest_email],
          subject: subject,
          html: body.replace(/\n/g, '<br>'),
        };

        if (resendAttachments.length > 0) {
          emailPayload.attachments = resendAttachments;
        }

        console.log('Sending email to:', bookingData.guest_email);

        const resendResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${RESEND_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(emailPayload),
        });

        const resendData = await resendResponse.json();
        console.log('Resend response:', resendData);

        if (!resendResponse.ok) {
          throw new Error(`Resend API error: ${JSON.stringify(resendData)}`);
        }

        emailsSent.push({
          templateName: template.name,
          emailId: resendData.id,
          to: bookingData.guest_email,
        });

        console.log(`Successfully sent email using template: ${template.name}`);
      } catch (err) {
        console.error(`Error processing template ${template.name}:`, err);
        errors.push({
          templateName: template.name,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    return new Response(
      JSON.stringify({ 
        success: emailsSent.length > 0, 
        message: `Sent ${emailsSent.length} email(s)${errors.length > 0 ? ` with ${errors.length} error(s)` : ''}`,
        emails: emailsSent,
        errors: errors.length > 0 ? errors : undefined,
      }),
      {
        status: emailsSent.length > 0 ? 200 : 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error in send-booking-email function:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
