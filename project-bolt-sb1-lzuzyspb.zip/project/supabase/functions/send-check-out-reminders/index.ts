import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY') || 're_TjPMSHhY_HMh6psoTEYsxanRMnCC4edtA';
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookingData {
  id: string;
  guest_name: string;
  guest_email: string;
  check_in: string;
  check_out: string;
  apartment_id: string;
  total_amount: number;
  guests: number;
}

interface ApartmentData {
  name: string;
  check_out_time?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    console.log('Starting check-out reminder job...');

    // Create Supabase client with service role
    const { createClient } = await import('npm:@supabase/supabase-js@2.50.3');
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Calculate tomorrow's date (24 hours from now)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDate = tomorrow.toISOString().split('T')[0];

    console.log(`Looking for bookings with check-out date: ${tomorrowDate}`);

    // Find bookings with check-out tomorrow that are confirmed
    const { data: bookings, error: bookingsError } = await supabase
      .from('bookings')
      .select('*')
      .eq('check_out', tomorrowDate)
      .eq('status', 'confirmed');

    if (bookingsError) {
      console.error('Bookings fetch error:', bookingsError);
      throw new Error(`Failed to fetch bookings: ${bookingsError.message}`);
    }

    console.log(`Found ${bookings?.length || 0} bookings with check-out tomorrow`);

    if (!bookings || bookings.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true,
          message: 'No bookings found with check-out tomorrow',
          date: tomorrowDate,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Find active templates for check-out reminders
    const { data: templates, error: templatesError } = await supabase
      .from('message_templates')
      .select('*')
      .eq('schedule_event', 'check_out')
      .eq('schedule_type', 'before')
      .eq('schedule_value', 24)
      .eq('schedule_unit', 'hours')
      .eq('is_active', true);

    if (templatesError) {
      console.error('Template fetch error:', templatesError);
      throw new Error(`Failed to fetch templates: ${templatesError.message}`);
    }

    console.log(`Found ${templates?.length || 0} active check-out reminder templates`);

    if (!templates || templates.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true,
          message: 'No active check-out reminder templates found',
          bookingsFound: bookings.length,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const emailsSent = [];
    const errors = [];

    // Process each booking
    for (const booking of bookings) {
      try {
        console.log(`Processing booking ${booking.id} for ${booking.guest_name}`);

        // Get apartment details
        const { data: apartment, error: apartmentError } = await supabase
          .from('apartments')
          .select('name')
          .eq('id', booking.apartment_id)
          .maybeSingle();

        if (apartmentError) {
          console.error('Apartment fetch error:', apartmentError);
          throw new Error(`Failed to fetch apartment: ${apartmentError.message}`);
        }

        // Get apartment details (check-out time)
        const { data: apartmentDetails } = await supabase
          .from('apartment_details')
          .select('check_out_time')
          .eq('apartment_id', booking.apartment_id)
          .maybeSingle();

        const apartmentName = apartment?.name || 'Your accommodation';
        const checkOutTime = apartmentDetails?.check_out_time || 'Not specified';

        // Send email for each active template
        for (const template of templates) {
          try {
            console.log(`Using template: ${template.name}`);

            // Get user settings for sender info
            const { data: settings } = await supabase
              .from('user_settings')
              .select('*')
              .eq('user_id', template.user_id)
              .maybeSingle();

            const senderEmail = settings?.sender_email || 'onboarding@resend.dev';
            const senderName = settings?.sender_name || 'Property Manager';

            // Replace placeholders in subject and body
            let subject = template.subject;
            let body = template.body;

            const replacements = {
              '{{guest_name}}': booking.guest_name,
              '{{property_name}}': apartmentName,
              '{{check_in_date}}': new Date(booking.check_in).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }),
              '{{check_out_date}}': new Date(booking.check_out).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }),
              '{{check_in}}': new Date(booking.check_in).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }),
              '{{check_out}}': new Date(booking.check_out).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }),
              '{{check_out_time}}': checkOutTime,
              '{{total_amount}}': `$${booking.total_amount.toFixed(2)}`,
              '{{guests}}': booking.guests.toString(),
              '{{num_guests}}': booking.guests.toString(),
            };

            for (const [placeholder, value] of Object.entries(replacements)) {
              const regex = new RegExp(placeholder.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&'), 'g');
              subject = subject.replace(regex, value);
              body = body.replace(regex, value);
            }

            // Get attachments for this template
            const { data: attachments } = await supabase
              .from('template_attachments')
              .select('*')
              .eq('template_id', template.id);

            // Prepare attachments for Resend
            const resendAttachments = [];
            if (attachments && attachments.length > 0) {
              for (const attachment of attachments) {
                try {
                  const { data: fileData, error: downloadError } = await supabase.storage
                    .from('template-attachments')
                    .download(attachment.storage_path);

                  if (!downloadError && fileData) {
                    const arrayBuffer = await fileData.arrayBuffer();
                    const uint8Array = new Uint8Array(arrayBuffer);
                    const base64 = btoa(String.fromCharCode.apply(null, Array.from(uint8Array)));
                    
                    resendAttachments.push({
                      filename: attachment.file_name,
                      content: base64,
                    });
                  }
                } catch (err) {
                  console.error(`Failed to process attachment ${attachment.file_name}:`, err);
                }
              }
            }

            // Send email via Resend
            const emailPayload: any = {
              from: `${senderName} <${senderEmail}>`,
              to: [booking.guest_email],
              subject: subject,
              html: body.replace(/\n/g, '<br>'),
            };

            if (resendAttachments.length > 0) {
              emailPayload.attachments = resendAttachments;
            }

            const resendResponse = await fetch('https://api.resend.com/emails', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${RESEND_API_KEY}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(emailPayload),
            });

            const resendData = await resendResponse.json();

            if (!resendResponse.ok) {
              throw new Error(`Resend API error: ${JSON.stringify(resendData)}`);
            }

            emailsSent.push({
              bookingId: booking.id,
              guestName: booking.guest_name,
              guestEmail: booking.guest_email,
              templateName: template.name,
              emailId: resendData.id,
            });

            console.log(`Successfully sent check-out reminder to ${booking.guest_email}`);
          } catch (err) {
            console.error(`Error sending email with template ${template.name}:`, err);
            errors.push({
              bookingId: booking.id,
              templateName: template.name,
              error: err instanceof Error ? err.message : String(err),
            });
          }
        }
      } catch (err) {
        console.error(`Error processing booking ${booking.id}:`, err);
        errors.push({
          bookingId: booking.id,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    return new Response(
      JSON.stringify({ 
        success: emailsSent.length > 0 || errors.length === 0, 
        message: `Processed ${bookings.length} booking(s), sent ${emailsSent.length} email(s)${errors.length > 0 ? ` with ${errors.length} error(s)` : ''}`,
        bookingsProcessed: bookings.length,
        emailsSent: emailsSent.length,
        emails: emailsSent,
        errors: errors.length > 0 ? errors : undefined,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error in send-check-out-reminders function:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
