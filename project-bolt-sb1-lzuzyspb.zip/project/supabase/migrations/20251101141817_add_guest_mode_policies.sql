/*
  # Add Guest Mode Policies
  
  1. Changes
    - Add anonymous read access to bookings table
    - Keep all other tables as-is (they already allow anonymous SELECT)
  
  2. Security
    - Anonymous users can only SELECT (read) data
    - All write operations still require authentication
*/

-- Drop existing bookings policy
DROP POLICY IF EXISTS "Authenticated users can manage bookings" ON bookings;
DROP POLICY IF EXISTS "Anonymous users can view bookings" ON bookings;

-- Allow anonymous users to view bookings
CREATE POLICY "Anonymous users can view bookings" ON bookings
    FOR SELECT USING (true);

-- Allow authenticated users to manage bookings
CREATE POLICY "Authenticated users can manage bookings" ON bookings
    FOR ALL TO authenticated USING (true) WITH CHECK (true);