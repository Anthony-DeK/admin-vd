/*
  # Add Missing Columns to Apartment Tables

  1. Changes to `apartment_details` table
    - check_in_instructions - Text field for check-in info
    - wifi_name - WiFi network name
    - wifi_password - WiFi password
    - emergency_contact - Emergency contact phone
    - pets_allowed - Boolean for pets policy
    - parties_allowed - Boolean for parties policy
    - smoking_allowed - Boolean for smoking policy
    - photoshoots_allowed - Boolean for photoshoots policy
    - quiet_hours_start - Time when quiet hours begin
    - quiet_hours_end - Time when quiet hours end
    - check_in_time - Default check-in time
    - check_out_time - Default check-out time
    - custom_house_rules - Additional custom rules text
    - pool_opening_season - Pool availability season
    - pool_opening_hours - Pool operating hours

  2. Changes to `apartments` table
    - base_price - Base nightly rate
    - cleaning_fee - One-time cleaning fee
    - service_fee - Service fee
    - is_active - Soft delete flag
    - minimum_stay - Minimum nights required
    - maximum_stay - Maximum nights allowed
*/

-- Add columns to apartment_details table
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS check_in_instructions TEXT;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS wifi_name VARCHAR(100);
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS wifi_password VARCHAR(100);
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS emergency_contact VARCHAR(20);
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS pets_allowed BOOLEAN DEFAULT false;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS parties_allowed BOOLEAN DEFAULT false;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS smoking_allowed BOOLEAN DEFAULT false;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS photoshoots_allowed BOOLEAN DEFAULT false;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS quiet_hours_start TIME;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS quiet_hours_end TIME;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS check_in_time TIME;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS check_out_time TIME;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS custom_house_rules TEXT;
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS pool_opening_season VARCHAR(100);
ALTER TABLE apartment_details ADD COLUMN IF NOT EXISTS pool_opening_hours VARCHAR(100);

-- Add columns to apartments table
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS base_price DECIMAL(10,2) DEFAULT 0 CHECK (base_price >= 0);
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS cleaning_fee DECIMAL(10,2) DEFAULT 0 CHECK (cleaning_fee >= 0);
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS service_fee DECIMAL(10,2) DEFAULT 0 CHECK (service_fee >= 0);
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS minimum_stay INTEGER DEFAULT 1 CHECK (minimum_stay > 0);
ALTER TABLE apartments ADD COLUMN IF NOT EXISTS maximum_stay INTEGER;