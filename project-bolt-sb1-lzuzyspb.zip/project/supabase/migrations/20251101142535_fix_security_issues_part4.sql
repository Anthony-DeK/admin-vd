/*
  # Fix Security Issues - Part 4: Add Missing RLS Policies
  
  1. Add RLS Policies for Remaining Tables
    - apartment_images
    - check_in_attachments  
    - message_templates
    - template_attachments
    - user_settings
    - booking_payments
*/

-- Clean up any existing policies and create new ones for apartment_images
DROP POLICY IF EXISTS "Public can view apartment images" ON apartment_images;
DROP POLICY IF EXISTS "Authenticated users can manage apartment images" ON apartment_images;

CREATE POLICY "apartment_images_select_for_all" ON apartment_images
  FOR SELECT USING (true);

CREATE POLICY "apartment_images_write_for_authenticated" ON apartment_images
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up and create policies for check_in_attachments
DROP POLICY IF EXISTS "check_in_attachments_select_for_all" ON check_in_attachments;
DROP POLICY IF EXISTS "check_in_attachments_write_for_authenticated" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow public to view check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated users to manage check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow anon to view check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated to manage check-in attachments" ON check_in_attachments;

CREATE POLICY "check_in_attachments_select_for_all" ON check_in_attachments
  FOR SELECT USING (true);

CREATE POLICY "check_in_attachments_write_for_authenticated" ON check_in_attachments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up and create policies for message_templates
DROP POLICY IF EXISTS "message_templates_select_for_all" ON message_templates;
DROP POLICY IF EXISTS "message_templates_write_for_authenticated" ON message_templates;
DROP POLICY IF EXISTS "Allow anonymous users to view message templates" ON message_templates;
DROP POLICY IF EXISTS "Allow authenticated users to manage their own message templates" ON message_templates;

CREATE POLICY "message_templates_select_for_all" ON message_templates
  FOR SELECT USING (true);

CREATE POLICY "message_templates_write_for_authenticated" ON message_templates
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up and create policies for template_attachments
DROP POLICY IF EXISTS "template_attachments_select_for_all" ON template_attachments;
DROP POLICY IF EXISTS "template_attachments_write_for_authenticated" ON template_attachments;

CREATE POLICY "template_attachments_select_for_all" ON template_attachments
  FOR SELECT USING (true);

CREATE POLICY "template_attachments_write_for_authenticated" ON template_attachments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up and create policies for user_settings
DROP POLICY IF EXISTS "user_settings_select_for_all" ON user_settings;
DROP POLICY IF EXISTS "user_settings_write_for_authenticated" ON user_settings;

CREATE POLICY "user_settings_select_for_all" ON user_settings
  FOR SELECT USING (true);

CREATE POLICY "user_settings_write_for_authenticated" ON user_settings
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up and create policies for booking_payments
DROP POLICY IF EXISTS "Authenticated users can manage payments" ON booking_payments;
DROP POLICY IF EXISTS "booking_payments_select_for_all" ON booking_payments;
DROP POLICY IF EXISTS "booking_payments_write_for_authenticated" ON booking_payments;

CREATE POLICY "booking_payments_select_for_all" ON booking_payments
  FOR SELECT USING (true);

CREATE POLICY "booking_payments_write_for_authenticated" ON booking_payments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);