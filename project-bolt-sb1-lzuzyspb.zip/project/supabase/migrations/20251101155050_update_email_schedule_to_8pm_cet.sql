/*
  # Update Email Reminder Schedule to 8 PM CET
  
  1. Update Scheduled Jobs
    - Change check-in reminder to run at 19:00 UTC (8 PM CET/7 PM UTC)
    - Change check-out reminder to run at 19:00 UTC (8 PM CET/7 PM UTC)
  
  Note: CET is UTC+1, so 8 PM CET = 7 PM UTC (19:00)
  During CEST (summer time UTC+2), 7 PM UTC = 9 PM CEST
*/

-- Remove existing jobs
DO $$
BEGIN
  PERFORM cron.unschedule('send-check-in-reminders-daily');
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
  PERFORM cron.unschedule('send-check-out-reminders-daily');
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Schedule check-in reminder job to run daily at 7 PM UTC (8 PM CET)
SELECT cron.schedule(
  'send-check-in-reminders-daily',
  '0 19 * * *', -- Run at 19:00 UTC (8 PM CET) every day
  $$
  SELECT net.http_post(
    url := current_setting('app.supabase_url') || '/functions/v1/send-check-in-reminders',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key')
    ),
    body := '{}'::jsonb
  );
  $$
);

-- Schedule check-out reminder job to run daily at 7 PM UTC (8 PM CET)
SELECT cron.schedule(
  'send-check-out-reminders-daily',
  '0 19 * * *', -- Run at 19:00 UTC (8 PM CET) every day
  $$
  SELECT net.http_post(
    url := current_setting('app.supabase_url') || '/functions/v1/send-check-out-reminders',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key')
    ),
    body := '{}'::jsonb
  );
  $$
);