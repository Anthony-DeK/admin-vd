/*
  # Allow Anonymous Storage Access

  1. Changes
    - Add storage policies for anon role to allow uploads in development/demo mode
    - Keep existing authenticated policies
  
  2. Security
    - Anon users can upload/manage files (for demo purposes)
    - Public can read files
    - Authenticated users can also upload/manage files
*/

-- Allow anon users to insert files (for development/demo)
CREATE POLICY "Anon insert apartments"
  ON storage.objects FOR INSERT
  TO anon
  WITH CHECK (bucket_id = 'apartments');

-- Allow anon users to update files
CREATE POLICY "Anon update apartments"
  ON storage.objects FOR UPDATE
  TO anon
  USING (bucket_id = 'apartments')
  WITH CHECK (bucket_id = 'apartments');

-- Allow anon users to delete files
CREATE POLICY "Anon delete apartments"
  ON storage.objects FOR DELETE
  TO anon
  USING (bucket_id = 'apartments');
