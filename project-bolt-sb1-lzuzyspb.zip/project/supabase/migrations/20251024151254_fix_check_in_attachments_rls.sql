/*
  # Fix Check-in Attachments RLS Policies

  1. Changes
    - Drop existing policies
    - Recreate policies with proper permissions
    - Ensure policies work for both authenticated and anon users with proper session

  2. Security
    - Policies now check for valid session
    - All operations allowed for authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can view check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can insert check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can update check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can delete check-in attachments" ON check_in_attachments;

-- Recreate policies with proper auth checks
CREATE POLICY "Allow authenticated users to view check-in attachments"
  ON check_in_attachments
  FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Allow authenticated users to insert check-in attachments"
  ON check_in_attachments
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Allow authenticated users to update check-in attachments"
  ON check_in_attachments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Allow authenticated users to delete check-in attachments"
  ON check_in_attachments
  FOR DELETE
  TO authenticated
  USING (auth.uid() IS NOT NULL);