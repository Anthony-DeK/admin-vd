/*
  # Enhanced Accommodation Rental Database Schema

  1. New Tables
    - Enhanced existing tables with additional fields
    - `booking_payments` - Track payment history and status
    - `reviews` - Guest review system with detailed ratings

  2. Schema Improvements
    - Consolidated pricing into apartments table
    - Enhanced data validation with CHECK constraints
    - Better guest tracking (adults/children breakdown)
    - Improved image management with categorization

  3. Security
    - Enable RLS on all tables
    - Comprehensive policies for public/authenticated access
    - Storage bucket policies for image management

  4. Performance
    - Strategic indexing for common queries
    - Optimized for date-range and filtering operations
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create or replace updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add new columns to existing apartments table
DO $$
BEGIN
    -- Add square_feet if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'square_feet'
    ) THEN
        ALTER TABLE apartments ADD COLUMN square_feet INTEGER CHECK (square_feet > 0);
    END IF;

    -- Add base_price if it doesn't exist (consolidating pricing)
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'base_price'
    ) THEN
        ALTER TABLE apartments ADD COLUMN base_price DECIMAL(10,2) DEFAULT 0 CHECK (base_price >= 0);
    END IF;

    -- Add cleaning_fee if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'cleaning_fee'
    ) THEN
        ALTER TABLE apartments ADD COLUMN cleaning_fee DECIMAL(10,2) DEFAULT 0 CHECK (cleaning_fee >= 0);
    END IF;

    -- Add service_fee if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'service_fee'
    ) THEN
        ALTER TABLE apartments ADD COLUMN service_fee DECIMAL(10,2) DEFAULT 0 CHECK (service_fee >= 0);
    END IF;

    -- Add security_deposit
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'security_deposit'
    ) THEN
        ALTER TABLE apartments ADD COLUMN security_deposit DECIMAL(10,2) DEFAULT 0 CHECK (security_deposit >= 0);
    END IF;

    -- Add currency
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'currency'
    ) THEN
        ALTER TABLE apartments ADD COLUMN currency VARCHAR(3) DEFAULT 'USD';
    END IF;

    -- Add is_active for soft deletion
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'is_active'
    ) THEN
        ALTER TABLE apartments ADD COLUMN is_active BOOLEAN DEFAULT true;
    END IF;

    -- Add minimum_stay
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'minimum_stay'
    ) THEN
        ALTER TABLE apartments ADD COLUMN minimum_stay INTEGER DEFAULT 1 CHECK (minimum_stay > 0);
    END IF;

    -- Add maximum_stay
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartments' AND column_name = 'maximum_stay'
    ) THEN
        ALTER TABLE apartments ADD COLUMN maximum_stay INTEGER CHECK (maximum_stay IS NULL OR maximum_stay >= minimum_stay);
    END IF;
END $$;

-- Add constraints to existing apartments table
DO $$
BEGIN
    -- Add check constraints if they don't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'apartments_max_guests_check'
    ) THEN
        ALTER TABLE apartments ADD CONSTRAINT apartments_max_guests_check CHECK (max_guests > 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'apartments_bedrooms_check'
    ) THEN
        ALTER TABLE apartments ADD CONSTRAINT apartments_bedrooms_check CHECK (bedrooms >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'apartments_bathrooms_check'
    ) THEN
        ALTER TABLE apartments ADD CONSTRAINT apartments_bathrooms_check CHECK (bathrooms > 0);
    END IF;
END $$;

-- Enhance apartment_details table
DO $$
BEGIN
    -- Add new columns to apartment_details
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_details' AND column_name = 'check_in_instructions'
    ) THEN
        ALTER TABLE apartment_details ADD COLUMN check_in_instructions TEXT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_details' AND column_name = 'wifi_name'
    ) THEN
        ALTER TABLE apartment_details ADD COLUMN wifi_name VARCHAR(100);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_details' AND column_name = 'wifi_password'
    ) THEN
        ALTER TABLE apartment_details ADD COLUMN wifi_password VARCHAR(100);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_details' AND column_name = 'emergency_contact'
    ) THEN
        ALTER TABLE apartment_details ADD COLUMN emergency_contact VARCHAR(20);
    END IF;

    -- Add unique constraint for apartment_details
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'unique_apartment_details'
    ) THEN
        ALTER TABLE apartment_details ADD CONSTRAINT unique_apartment_details UNIQUE (apartment_id);
    END IF;
END $$;

-- Enhance apartment_images table
DO $$
BEGIN
    -- Add new columns to apartment_images
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_images' AND column_name = 'storage_path'
    ) THEN
        ALTER TABLE apartment_images ADD COLUMN storage_path TEXT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_images' AND column_name = 'alt_text'
    ) THEN
        ALTER TABLE apartment_images ADD COLUMN alt_text VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'apartment_images' AND column_name = 'image_type'
    ) THEN
        ALTER TABLE apartment_images ADD COLUMN image_type VARCHAR(50) DEFAULT 'general' CHECK (image_type IN ('general', 'bedroom', 'bathroom', 'kitchen', 'living_room', 'exterior'));
    END IF;
END $$;

-- Enhance bookings table
DO $$
BEGIN
    -- Add new columns to bookings
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'guest_address'
    ) THEN
        ALTER TABLE bookings ADD COLUMN guest_address TEXT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'adults'
    ) THEN
        ALTER TABLE bookings ADD COLUMN adults INTEGER CHECK (adults > 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'children'
    ) THEN
        ALTER TABLE bookings ADD COLUMN children INTEGER DEFAULT 0 CHECK (children >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'base_amount'
    ) THEN
        ALTER TABLE bookings ADD COLUMN base_amount DECIMAL(10,2) CHECK (base_amount >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'cleaning_fee'
    ) THEN
        ALTER TABLE bookings ADD COLUMN cleaning_fee DECIMAL(10,2) DEFAULT 0 CHECK (cleaning_fee >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'service_fee'
    ) THEN
        ALTER TABLE bookings ADD COLUMN service_fee DECIMAL(10,2) DEFAULT 0 CHECK (service_fee >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'tax_amount'
    ) THEN
        ALTER TABLE bookings ADD COLUMN tax_amount DECIMAL(10,2) DEFAULT 0 CHECK (tax_amount >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'currency'
    ) THEN
        ALTER TABLE bookings ADD COLUMN currency VARCHAR(3) DEFAULT 'USD';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'booking_source'
    ) THEN
        ALTER TABLE bookings ADD COLUMN booking_source VARCHAR(50) DEFAULT 'direct';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'bookings' AND column_name = 'special_requests'
    ) THEN
        ALTER TABLE bookings ADD COLUMN special_requests TEXT;
    END IF;
END $$;

-- Update bookings status constraint to include new status
DO $$
BEGIN
    -- Drop existing constraint if it exists
    IF EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings DROP CONSTRAINT bookings_status_check;
    END IF;

    -- Add updated constraint
    ALTER TABLE bookings ADD CONSTRAINT bookings_status_check 
        CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed', 'no_show'));

    -- Add guest count validation constraint
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'valid_guest_count'
    ) THEN
        ALTER TABLE bookings ADD CONSTRAINT valid_guest_count 
            CHECK (adults IS NULL OR children IS NULL OR adults + children = guests);
    END IF;
END $$;

-- Enhance date_specific_pricing table
DO $$
BEGIN
    -- Add new columns
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'date_specific_pricing' AND column_name = 'fixed_price'
    ) THEN
        ALTER TABLE date_specific_pricing ADD COLUMN fixed_price DECIMAL(10,2) CHECK (fixed_price >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'date_specific_pricing' AND column_name = 'reason'
    ) THEN
        ALTER TABLE date_specific_pricing ADD COLUMN reason VARCHAR(100);
    END IF;

    -- Add pricing method constraint
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.check_constraints 
        WHERE constraint_name = 'pricing_method'
    ) THEN
        ALTER TABLE date_specific_pricing ADD CONSTRAINT pricing_method 
            CHECK (
                (price_multiplier IS NOT NULL AND fixed_price IS NULL) OR
                (price_multiplier IS NULL AND fixed_price IS NOT NULL)
            );
    END IF;
END $$;

-- Enhance date_specific_availability table
DO $$
BEGIN
    -- Add notes column
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'date_specific_availability' AND column_name = 'notes'
    ) THEN
        ALTER TABLE date_specific_availability ADD COLUMN notes TEXT;
    END IF;
END $$;

-- Create booking_payments table
CREATE TABLE IF NOT EXISTS booking_payments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) DEFAULT 'USD',
    payment_method VARCHAR(50), -- 'credit_card', 'bank_transfer', 'cash', etc.
    payment_status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded', 'partially_refunded')),
    transaction_id VARCHAR(255), -- External payment processor ID
    payment_date TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
    guest_name VARCHAR(255) NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(255),
    comment TEXT,
    cleanliness_rating INTEGER CHECK (cleanliness_rating >= 1 AND cleanliness_rating <= 5),
    communication_rating INTEGER CHECK (communication_rating >= 1 AND communication_rating <= 5),
    location_rating INTEGER CHECK (location_rating >= 1 AND location_rating <= 5),
    value_rating INTEGER CHECK (value_rating >= 1 AND value_rating <= 5),
    is_public BOOLEAN DEFAULT true,
    host_response TEXT,
    host_response_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Ensure one review per booking
    CONSTRAINT unique_booking_review UNIQUE (booking_id)
);

-- CREATE INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_apartments_location ON apartments(location);
CREATE INDEX IF NOT EXISTS idx_apartments_type ON apartments(type);
CREATE INDEX IF NOT EXISTS idx_apartments_available ON apartments(is_available, is_active);
CREATE INDEX IF NOT EXISTS idx_apartments_price ON apartments(base_price);

CREATE INDEX IF NOT EXISTS idx_apartment_images_apartment ON apartment_images(apartment_id, display_order);
CREATE INDEX IF NOT EXISTS idx_apartment_images_primary ON apartment_images(apartment_id, is_primary);

CREATE INDEX IF NOT EXISTS idx_bookings_apartment_dates ON bookings(apartment_id, check_in, check_out);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_guest_email ON bookings(guest_email);

CREATE INDEX IF NOT EXISTS idx_date_pricing_apartment_dates ON date_specific_pricing(apartment_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_date_availability_apartment_dates ON date_specific_availability(apartment_id, start_date, end_date);

CREATE INDEX IF NOT EXISTS idx_payments_booking ON booking_payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON booking_payments(payment_status);

CREATE INDEX IF NOT EXISTS idx_reviews_apartment ON reviews(apartment_id, is_public);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);

-- CREATE TRIGGERS FOR UPDATED_AT (only for new tables or if trigger doesn't exist)
DO $$
BEGIN
    -- Trigger for booking_payments
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'update_booking_payments_updated_at'
    ) THEN
        CREATE TRIGGER update_booking_payments_updated_at
            BEFORE UPDATE ON booking_payments
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
    END IF;

    -- Trigger for reviews
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'update_reviews_updated_at'
    ) THEN
        CREATE TRIGGER update_reviews_updated_at
            BEFORE UPDATE ON reviews
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- ENABLE ROW LEVEL SECURITY (only if not already enabled)
DO $$
BEGIN
    -- Enable RLS on new tables
    ALTER TABLE booking_payments ENABLE ROW LEVEL SECURITY;
    ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
END $$;

-- CREATE RLS POLICIES (drop existing conflicting policies first)
-- Apartments policies
DROP POLICY IF EXISTS "Public can view available apartments" ON apartments;
DROP POLICY IF EXISTS "Authenticated users can manage apartments" ON apartments;

CREATE POLICY "Public can view available apartments" ON apartments
    FOR SELECT USING (is_available = true AND is_active = true);

CREATE POLICY "Authenticated users can manage apartments" ON apartments
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Apartment Details policies
DROP POLICY IF EXISTS "Public can view apartment details" ON apartment_details;
DROP POLICY IF EXISTS "Authenticated users can manage apartment details" ON apartment_details;

CREATE POLICY "Public can view apartment details" ON apartment_details
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can manage apartment details" ON apartment_details
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Apartment Images policies
DROP POLICY IF EXISTS "Public can view apartment images" ON apartment_images;
DROP POLICY IF EXISTS "Authenticated users can manage apartment images" ON apartment_images;

CREATE POLICY "Public can view apartment images" ON apartment_images
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can manage apartment images" ON apartment_images
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Bookings policies
DROP POLICY IF EXISTS "Authenticated users can manage bookings" ON bookings;

CREATE POLICY "Authenticated users can manage bookings" ON bookings
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Date Specific Pricing policies
DROP POLICY IF EXISTS "Public can view pricing" ON date_specific_pricing;
DROP POLICY IF EXISTS "Authenticated users can manage pricing" ON date_specific_pricing;

CREATE POLICY "Public can view pricing" ON date_specific_pricing
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can manage pricing" ON date_specific_pricing
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Date Specific Availability policies
DROP POLICY IF EXISTS "Public can view availability" ON date_specific_availability;
DROP POLICY IF EXISTS "Authenticated users can manage availability" ON date_specific_availability;

CREATE POLICY "Public can view availability" ON date_specific_availability
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can manage availability" ON date_specific_availability
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Booking Payments policies
CREATE POLICY "Authenticated users can manage payments" ON booking_payments
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Reviews policies
CREATE POLICY "Public can view public reviews" ON reviews
    FOR SELECT USING (is_public = true);

CREATE POLICY "Authenticated users can manage reviews" ON reviews
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- CREATE STORAGE BUCKET AND POLICIES
INSERT INTO storage.buckets (id, name, public)
VALUES ('apartments', 'apartments', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing storage policies to avoid conflicts
DROP POLICY IF EXISTS "Public can view apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete apartment images" ON storage.objects;

-- Create storage policies
CREATE POLICY "Public can view apartment images"
ON storage.objects FOR SELECT
USING (bucket_id = 'apartments');

CREATE POLICY "Authenticated users can upload apartment images"
ON storage.objects FOR INSERT
WITH CHECK (
    bucket_id = 'apartments'
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Authenticated users can update apartment images"
ON storage.objects FOR UPDATE
USING (
    bucket_id = 'apartments'
    AND auth.role() = 'authenticated'
);

CREATE POLICY "Authenticated users can delete apartment images"
ON storage.objects FOR DELETE
USING (
    bucket_id = 'apartments'
    AND auth.role() = 'authenticated'
);