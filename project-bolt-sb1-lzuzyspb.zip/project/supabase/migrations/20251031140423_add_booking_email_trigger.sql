/*
  # Add Automatic Email Trigger for Bookings

  1. Changes
    - Create a function to send emails when bookings are created or status changes
    - Add trigger on bookings table to automatically invoke the edge function
    - Supports booking_confirmed and booking_cancelled events
  
  2. How it Works
    - When a booking is inserted with status 'confirmed', sends booking_confirmed email
    - When a booking status changes to 'confirmed', sends booking_confirmed email
    - When a booking status changes to 'cancelled', sends booking_cancelled email
    - Uses the send-booking-email edge function via HTTP request
  
  3. Security
    - Function uses security definer to run with elevated privileges
    - Only triggers for relevant status changes
*/

-- Create function to invoke edge function for sending emails
CREATE OR REPLACE FUNCTION send_booking_email_notification()
RETURNS TRIGGER
SECURITY DEFINER
AS $$
DECLARE
  event_type text;
  booking_info jsonb;
  apartment_name text;
  supabase_url text;
  supabase_key text;
BEGIN
  -- Determine the event type
  IF (TG_OP = 'INSERT' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'confirmed' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'cancelled' AND NEW.status = 'cancelled') THEN
    event_type := 'booking_cancelled';
  ELSE
    -- No email needed for this change
    RETURN NEW;
  END IF;

  -- Get apartment name
  SELECT name INTO apartment_name
  FROM apartments
  WHERE id = NEW.apartment_id;

  -- Get Supabase credentials from environment
  supabase_url := current_setting('app.settings.supabase_url', true);
  supabase_key := current_setting('app.settings.supabase_key', true);

  -- If settings are not configured, use default approach
  IF supabase_url IS NULL THEN
    supabase_url := 'https://' || current_setting('request.header.host', true);
  END IF;

  -- Prepare booking data
  booking_info := jsonb_build_object(
    'id', NEW.id,
    'guest_name', NEW.guest_name,
    'guest_email', NEW.guest_email,
    'check_in', NEW.check_in,
    'check_out', NEW.check_out,
    'apartment_name', apartment_name,
    'status', NEW.status,
    'total_amount', NEW.total_amount,
    'guests', NEW.guests
  );

  -- Call edge function asynchronously using pg_net if available
  -- Note: This is a fire-and-forget approach
  PERFORM net.http_post(
    url := supabase_url || '/functions/v1/send-booking-email',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || supabase_key
    ),
    body := jsonb_build_object(
      'bookingData', booking_info,
      'event', event_type,
      'supabaseUrl', supabase_url,
      'supabaseKey', supabase_key
    )
  );

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the booking operation
    RAISE WARNING 'Failed to send email notification: %', SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new bookings and status changes
DROP TRIGGER IF EXISTS booking_email_notification_trigger ON bookings;
CREATE TRIGGER booking_email_notification_trigger
  AFTER INSERT OR UPDATE OF status
  ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION send_booking_email_notification();