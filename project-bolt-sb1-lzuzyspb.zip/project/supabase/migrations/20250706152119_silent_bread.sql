/*
  # Fix RLS policies for apartment_details table

  1. Security Updates
    - Drop existing problematic policies on apartment_details table
    - Create new comprehensive RLS policies that properly handle INSERT, UPDATE, SELECT, and DELETE operations
    - Ensure authenticated users can perform all operations
    - Ensure public users can view apartment details
    - Add proper policy conditions to prevent conflicts

  2. Changes
    - Remove duplicate and conflicting policies
    - Add clear, non-overlapping policies for different operations
    - Ensure INSERT operations work for authenticated users
*/

-- Drop existing policies that might be causing conflicts
DROP POLICY IF EXISTS "Authenticated users can manage apartment details" ON apartment_details;
DROP POLICY IF EXISTS "Enable all operations for authenticated users" ON apartment_details;
DROP POLICY IF EXISTS "Public can view apartment details" ON apartment_details;

-- Create new, clear RLS policies
CREATE POLICY "authenticated_users_can_select_apartment_details"
  ON apartment_details
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "authenticated_users_can_insert_apartment_details"
  ON apartment_details
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "authenticated_users_can_update_apartment_details"
  ON apartment_details
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "authenticated_users_can_delete_apartment_details"
  ON apartment_details
  FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "public_can_view_apartment_details"
  ON apartment_details
  FOR SELECT
  TO public
  USING (true);