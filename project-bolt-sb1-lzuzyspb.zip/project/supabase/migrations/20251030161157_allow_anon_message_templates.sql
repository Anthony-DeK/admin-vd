/*
  # Allow Anonymous Access to Message Templates

  1. Changes
    - Drop existing restrictive RLS policies for message_templates
    - Add new policies allowing anonymous users to view and manage templates
    - This enables preview/test functionality without authentication
  
  2. Security Notes
    - Templates are now accessible without authentication
    - Users can create, view, edit, and delete templates anonymously
    - User settings also accessible anonymously for testing
*/

-- Drop existing policies for message_templates
DROP POLICY IF EXISTS "Users can view own templates" ON message_templates;
DROP POLICY IF EXISTS "Users can insert own templates" ON message_templates;
DROP POLICY IF EXISTS "Users can update own templates" ON message_templates;
DROP POLICY IF EXISTS "Users can delete own templates" ON message_templates;

-- Create new policies allowing anonymous access
CREATE POLICY "Anyone can view templates"
  ON message_templates FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert templates"
  ON message_templates FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update templates"
  ON message_templates FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete templates"
  ON message_templates FOR DELETE
  TO anon, authenticated
  USING (true);

-- Drop existing policies for template_attachments
DROP POLICY IF EXISTS "Users can view own template attachments" ON template_attachments;
DROP POLICY IF EXISTS "Users can insert own template attachments" ON template_attachments;
DROP POLICY IF EXISTS "Users can delete own template attachments" ON template_attachments;

-- Create new policies allowing anonymous access
CREATE POLICY "Anyone can view template attachments"
  ON template_attachments FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert template attachments"
  ON template_attachments FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can delete template attachments"
  ON template_attachments FOR DELETE
  TO anon, authenticated
  USING (true);

-- Drop existing policies for user_settings
DROP POLICY IF EXISTS "Users can view own settings" ON user_settings;
DROP POLICY IF EXISTS "Users can insert own settings" ON user_settings;
DROP POLICY IF EXISTS "Users can update own settings" ON user_settings;

-- Create new policies allowing anonymous access
CREATE POLICY "Anyone can view settings"
  ON user_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert settings"
  ON user_settings FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update settings"
  ON user_settings FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Update storage policies for template attachments
DROP POLICY IF EXISTS "Users can view own template attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload own template attachments" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own template attachments" ON storage.objects;

CREATE POLICY "Anyone can view template attachments"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'template-attachments');

CREATE POLICY "Anyone can upload template attachments"
  ON storage.objects FOR INSERT
  TO anon, authenticated
  WITH CHECK (bucket_id = 'template-attachments');

CREATE POLICY "Anyone can delete template attachments"
  ON storage.objects FOR DELETE
  TO anon, authenticated
  USING (bucket_id = 'template-attachments');