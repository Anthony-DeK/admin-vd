/*
  # Fix storage policies for apartment image uploads

  1. Storage Policy Updates
    - Drop all existing restrictive storage policies
    - Create comprehensive policies that allow anon access for apartment images
    - Ensure both authenticated and anonymous users can upload, view, update, and delete images

  2. Changes
    - Remove authentication requirements for storage operations
    - Allow anon access to apartments bucket for all operations
    - Fix RLS policy conflicts that prevent uploads
*/

-- Drop all existing storage policies to start fresh
DROP POLICY IF EXISTS "Public can view apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Public can upload apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete apartment images" ON storage.objects;

-- Create comprehensive anon policies for apartments bucket
CREATE POLICY "Anon can view apartment images"
ON storage.objects FOR SELECT
TO anon
USING (bucket_id = 'apartments');

CREATE POLICY "Anon can insert apartment images"
ON storage.objects FOR INSERT
TO anon
WITH CHECK (bucket_id = 'apartments');

CREATE POLICY "Anon can update apartment images"
ON storage.objects FOR UPDATE
TO anon
USING (bucket_id = 'apartments')
WITH CHECK (bucket_id = 'apartments');

CREATE POLICY "Anon can delete apartment images"
ON storage.objects FOR DELETE
TO anon
USING (bucket_id = 'apartments');

-- Ensure the apartments bucket exists and is public
INSERT INTO storage.buckets (id, name, public)
VALUES ('apartments', 'apartments', true)
ON CONFLICT (id) DO UPDATE SET public = true;