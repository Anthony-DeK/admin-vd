/*
  # Fix RLS policies for apartment_images table

  1. Security Updates
    - Drop existing conflicting policies on apartment_images table
    - Create new comprehensive policies that allow public access for all operations
    - Ensure image uploads work properly without authentication barriers

  2. Changes
    - Remove all existing policies on apartment_images
    - Add new policies that allow public INSERT, SELECT, UPDATE, DELETE operations
    - Maintain RLS enabled for security while allowing necessary operations
*/

-- Drop all existing policies on apartment_images table
DROP POLICY IF EXISTS "apartment_images_delete_policy" ON apartment_images;
DROP POLICY IF EXISTS "apartment_images_insert_policy" ON apartment_images;
DROP POLICY IF EXISTS "apartment_images_select_policy" ON apartment_images;
DROP POLICY IF EXISTS "apartment_images_update_policy" ON apartment_images;

-- Create new comprehensive policies for apartment_images
CREATE POLICY "Enable all operations for apartment_images"
  ON apartment_images
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Ensure RLS is enabled
ALTER TABLE apartment_images ENABLE ROW LEVEL SECURITY;