/*
  # Enable pg_net Extension and Fix Email Trigger

  1. Changes
    - Enable pg_net extension for async HTTP requests
    - Update trigger function to properly call edge function
    - Add proper error handling and logging
  
  2. How it Works
    - pg_net allows making async HTTP requests from database triggers
    - Trigger fires when booking status changes
    - Edge function is called with booking data
    - Emails are sent based on active message templates
*/

-- Enable pg_net extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Drop and recreate the function with proper implementation
DROP FUNCTION IF EXISTS send_booking_email_notification() CASCADE;

CREATE OR REPLACE FUNCTION send_booking_email_notification()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  event_type text;
  booking_info jsonb;
  apartment_name text;
  function_url text;
  request_id bigint;
BEGIN
  -- Determine the event type
  IF (TG_OP = 'INSERT' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'confirmed' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'cancelled' AND NEW.status = 'cancelled') THEN
    event_type := 'booking_cancelled';
  ELSE
    -- No email needed for this change
    RETURN NEW;
  END IF;

  -- Get apartment name
  SELECT name INTO apartment_name
  FROM apartments
  WHERE id = NEW.apartment_id;

  -- Build function URL from Supabase project reference
  -- This assumes the standard Supabase URL format
  function_url := current_setting('request.headers', true)::json->>'x-forwarded-host';
  
  IF function_url IS NULL OR function_url = '' THEN
    -- Fallback: try to construct from JWT
    function_url := 'https://' || split_part(current_setting('request.jwt.claims', true)::json->>'iss', '://', 2);
  END IF;
  
  -- If we still don't have a URL, we can't proceed
  IF function_url IS NULL OR function_url = '' THEN
    RAISE WARNING 'Could not determine Supabase URL for edge function call';
    RETURN NEW;
  END IF;
  
  -- Ensure https:// prefix
  IF NOT function_url LIKE 'http%' THEN
    function_url := 'https://' || function_url;
  END IF;
  
  function_url := function_url || '/functions/v1/send-booking-email';

  -- Prepare booking data
  booking_info := jsonb_build_object(
    'id', NEW.id,
    'guest_name', NEW.guest_name,
    'guest_email', NEW.guest_email,
    'check_in', NEW.check_in,
    'check_out', NEW.check_out,
    'apartment_name', COALESCE(apartment_name, 'Unknown Property'),
    'status', NEW.status,
    'total_amount', NEW.total_amount,
    'guests', NEW.guests
  );

  -- Make async HTTP request using pg_net
  SELECT extensions.http_post(
    url := function_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object(
      'bookingData', booking_info,
      'event', event_type,
      'supabaseUrl', regexp_replace(function_url, '/functions/v1/.*', ''),
      'supabaseKey', current_setting('app.settings.jwt_secret', true)
    )
  ) INTO request_id;

  -- Log the request
  RAISE NOTICE 'Email notification request sent: booking_id=%, event=%, request_id=%', NEW.id, event_type, request_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the booking operation
    RAISE WARNING 'Failed to send email notification for booking %: %', NEW.id, SQLERRM;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new bookings and status changes
DROP TRIGGER IF EXISTS booking_email_notification_trigger ON bookings;
CREATE TRIGGER booking_email_notification_trigger
  AFTER INSERT OR UPDATE OF status
  ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION send_booking_email_notification();