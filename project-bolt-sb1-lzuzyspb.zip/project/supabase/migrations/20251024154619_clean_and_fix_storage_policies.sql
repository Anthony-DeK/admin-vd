/*
  # Clean and Fix Storage Policies

  1. Changes
    - Drop ALL existing storage policies for apartments bucket
    - Create simple, working policies for public read and authenticated write access
  
  2. Security
    - Public SELECT access (anyone can view files)
    - Authenticated INSERT, UPDATE, DELETE (logged-in users can manage files)
*/

-- Drop ALL existing policies on storage.objects for apartments bucket
DROP POLICY IF EXISTS "Allow authenticated users to delete" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to update" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to upload" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read access" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read apartment files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete apartment files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update apartment files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload apartment files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload apartment images" ON storage.objects;
DROP POLICY IF EXISTS "Public can view apartment images" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_select_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_insert_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_update_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_delete_policy" ON storage.objects;

-- Public can view all files in apartments bucket
CREATE POLICY "Public read apartments"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'apartments');

-- Authenticated users can insert files
CREATE POLICY "Authenticated insert apartments"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'apartments');

-- Authenticated users can update files
CREATE POLICY "Authenticated update apartments"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'apartments')
  WITH CHECK (bucket_id = 'apartments');

-- Authenticated users can delete files
CREATE POLICY "Authenticated delete apartments"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'apartments');
