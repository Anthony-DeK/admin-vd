/*
  # Setup Scheduled Email Reminders
  
  1. Enable pg_cron Extension
    - pg_cron for scheduling jobs
    - pg_net for making HTTP requests
  
  2. Create Scheduled Jobs
    - Check-in reminder: runs daily at 9 AM UTC
    - Check-out reminder: runs daily at 9 AM UTC
  
  3. Jobs Configuration
    - Both jobs call their respective edge functions
    - Jobs run once per day to check for bookings
    - Edge functions handle the logic of finding bookings 24 hours away
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Grant usage on extensions to postgres role
GRANT USAGE ON SCHEMA cron TO postgres;

-- Remove existing jobs if they exist (to avoid duplicates)
DO $$
BEGIN
  -- Delete existing check-in reminder job
  PERFORM cron.unschedule('send-check-in-reminders-daily');
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
  -- Delete existing check-out reminder job
  PERFORM cron.unschedule('send-check-out-reminders-daily');
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Schedule check-in reminder job to run daily at 9 AM UTC
-- This will send reminders to guests checking in tomorrow
SELECT cron.schedule(
  'send-check-in-reminders-daily',
  '0 9 * * *', -- Run at 9:00 AM UTC every day
  $$
  SELECT net.http_post(
    url := current_setting('app.supabase_url') || '/functions/v1/send-check-in-reminders',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key')
    ),
    body := '{}'::jsonb
  );
  $$
);

-- Schedule check-out reminder job to run daily at 9 AM UTC
-- This will send reminders to guests checking out tomorrow
SELECT cron.schedule(
  'send-check-out-reminders-daily',
  '0 9 * * *', -- Run at 9:00 AM UTC every day
  $$
  SELECT net.http_post(
    url := current_setting('app.supabase_url') || '/functions/v1/send-check-out-reminders',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.supabase_service_role_key')
    ),
    body := '{}'::jsonb
  );
  $$
);

-- Set the Supabase URL and service role key (these should be available in Supabase environment)
-- Note: In Supabase, these settings are typically available automatically
-- If running locally, you may need to set these manually