/*
  # Add Pool Settings

  1. Changes
    - Add pool_opening_season column to apartment_details
      - Stores the months when pool is open (e.g., "May-September")
    - Add pool_opening_hours column to apartment_details
      - Stores the daily operating hours (e.g., "8:00 AM - 8:00 PM")
  
  2. Notes
    - These fields are optional and only relevant for properties with private outdoor swimming pool
    - Stored as text fields for maximum flexibility in formatting
*/

DO $$
BEGIN
  -- Add pool_opening_season column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'pool_opening_season'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN pool_opening_season TEXT;
  END IF;

  -- Add pool_opening_hours column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'pool_opening_hours'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN pool_opening_hours TEXT;
  END IF;
END $$;
