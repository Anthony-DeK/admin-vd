/*
  # Add Structured House Rules Fields

  1. New Columns in apartment_details
    - `pets_allowed` (boolean) - Whether pets are allowed
    - `parties_allowed` (boolean) - Whether parties/events are allowed
    - `smoking_allowed` (boolean) - Whether smoking/vaping is allowed
    - `photoshoots_allowed` (boolean) - Whether photoshoots/filming is allowed
    - `quiet_hours_start` (time) - Start of quiet hours (e.g., 22:00)
    - `quiet_hours_end` (time) - End of quiet hours (e.g., 08:00)
    - `check_in_time` (time) - Standard check-in time
    - `check_out_time` (time) - Standard check-out time
    - `custom_house_rules` (text) - Additional custom rules as free text

  2. Notes
    - Existing `house_rules` array field is retained for backward compatibility
    - New structured fields provide better query and display capabilities
    - Default values set to false for safety (restrictive by default)
*/

-- Add structured house rules fields to apartment_details
DO $$
BEGIN
  -- Pets allowed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'pets_allowed'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN pets_allowed BOOLEAN DEFAULT false;
  END IF;

  -- Parties allowed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'parties_allowed'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN parties_allowed BOOLEAN DEFAULT false;
  END IF;

  -- Smoking allowed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'smoking_allowed'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN smoking_allowed BOOLEAN DEFAULT false;
  END IF;

  -- Photoshoots allowed
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'photoshoots_allowed'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN photoshoots_allowed BOOLEAN DEFAULT false;
  END IF;

  -- Quiet hours start
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'quiet_hours_start'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN quiet_hours_start TIME;
  END IF;

  -- Quiet hours end
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'quiet_hours_end'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN quiet_hours_end TIME;
  END IF;

  -- Check-in time
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'check_in_time'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN check_in_time TIME;
  END IF;

  -- Check-out time
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'check_out_time'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN check_out_time TIME;
  END IF;

  -- Custom house rules (free text)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'apartment_details' AND column_name = 'custom_house_rules'
  ) THEN
    ALTER TABLE apartment_details ADD COLUMN custom_house_rules TEXT;
  END IF;
END $$;
