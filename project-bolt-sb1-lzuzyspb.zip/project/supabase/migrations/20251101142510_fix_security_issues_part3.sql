/*
  # Fix Security Issues - Part 3: Fix Function Security
  
  1. Fix Function Search Paths
    - Set immutable search_path on all trigger functions
    - This prevents search_path injection attacks
  
  2. Recreate Functions with Security Settings
    - update_updated_at_column
    - handle_updated_at
    - update_check_in_attachments_updated_at
*/

-- Drop and recreate update_updated_at_column with secure search_path
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Drop and recreate handle_updated_at with secure search_path
DROP FUNCTION IF EXISTS handle_updated_at() CASCADE;

CREATE OR REPLACE FUNCTION handle_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Drop and recreate update_check_in_attachments_updated_at with secure search_path
DROP FUNCTION IF EXISTS update_check_in_attachments_updated_at() CASCADE;

CREATE OR REPLACE FUNCTION update_check_in_attachments_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Recreate all triggers that use these functions
DO $$
DECLARE
  tbl RECORD;
BEGIN
  -- For all tables with updated_at column, recreate the trigger
  FOR tbl IN 
    SELECT table_name 
    FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND column_name = 'updated_at'
  LOOP
    -- Drop existing trigger if it exists
    EXECUTE format('DROP TRIGGER IF EXISTS update_%I_updated_at ON %I', tbl.table_name, tbl.table_name);
    EXECUTE format('DROP TRIGGER IF EXISTS handle_%I_updated_at ON %I', tbl.table_name, tbl.table_name);
    
    -- Create new trigger with the secure function
    EXECUTE format(
      'CREATE TRIGGER update_%I_updated_at
       BEFORE UPDATE ON %I
       FOR EACH ROW
       EXECUTE FUNCTION update_updated_at_column()',
      tbl.table_name, tbl.table_name
    );
  END LOOP;
END $$;