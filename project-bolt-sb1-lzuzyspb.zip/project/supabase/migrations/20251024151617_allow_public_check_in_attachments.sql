/*
  # Allow Public Access to Check-in Attachments

  1. Changes
    - Drop existing anon-only policies
    - Create public policies matching apartment_details pattern
    - Allow all operations without authentication requirement

  2. Security
    - Matches existing pattern in the app where apartment_details is public
    - No auth required for CRUD operations
*/

-- Drop existing policies
DROP POLICY IF EXISTS "check_in_attachments_select_policy" ON check_in_attachments;
DROP POLICY IF EXISTS "check_in_attachments_insert_policy" ON check_in_attachments;
DROP POLICY IF EXISTS "check_in_attachments_update_policy" ON check_in_attachments;
DROP POLICY IF EXISTS "check_in_attachments_delete_policy" ON check_in_attachments;

-- Create public policies
CREATE POLICY "allow_all_select_check_in_attachments"
  ON check_in_attachments
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_all_insert_check_in_attachments"
  ON check_in_attachments
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "allow_all_update_check_in_attachments"
  ON check_in_attachments
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "allow_all_delete_check_in_attachments"
  ON check_in_attachments
  FOR DELETE
  TO public
  USING (true);