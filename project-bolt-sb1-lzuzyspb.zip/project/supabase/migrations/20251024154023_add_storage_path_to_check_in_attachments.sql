/*
  # Add storage_path to check_in_attachments

  1. Changes
    - Add `storage_path` column to `check_in_attachments` table to store Supabase Storage file paths
    - Delete existing attachments with placeholder URLs (they need to be re-uploaded)
  
  2. Notes
    - Existing attachments with invalid URLs will be removed
    - Users will need to re-upload their files
*/

-- Add storage_path column
ALTER TABLE check_in_attachments 
ADD COLUMN IF NOT EXISTS storage_path text;

-- Delete attachments with placeholder URLs or data URLs (invalid legacy data)
DELETE FROM check_in_attachments 
WHERE file_url LIKE '%placeholder.com%' 
   OR file_url LIKE 'data:%';
