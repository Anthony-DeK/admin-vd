/*
  # Fix Security Issues - Part 1: Indexes and RLS
  
  1. Add Missing Indexes
    - Add index for apartment_pricing.apartment_id
    - Add index for message_templates.user_id
    - Add index for template_attachments.template_id
  
  2. Remove Duplicate Indexes
    - Drop duplicate booking date indexes
    - Drop duplicate availability date indexes
    - Drop duplicate pricing date indexes
  
  3. Enable RLS on Tables
    - Enable RLS on apartments
    - Enable RLS on bookings
    - Enable RLS on date_specific_availability
    - Enable RLS on date_specific_pricing
    - Enable RLS on apartment_pricing
*/

-- Add missing indexes for foreign keys
CREATE INDEX IF NOT EXISTS idx_apartment_pricing_apartment_id 
  ON apartment_pricing(apartment_id);

CREATE INDEX IF NOT EXISTS idx_message_templates_user_id 
  ON message_templates(user_id);

CREATE INDEX IF NOT EXISTS idx_template_attachments_template_id 
  ON template_attachments(template_id);

-- Remove duplicate indexes (keep the more descriptive ones)
DROP INDEX IF EXISTS idx_bookings_dates;
DROP INDEX IF EXISTS idx_date_specific_availability_dates;
DROP INDEX IF EXISTS idx_date_specific_pricing_dates;

-- Enable RLS on all public tables
ALTER TABLE apartments ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_pricing ENABLE ROW LEVEL SECURITY;

-- Enable RLS on apartment_pricing if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'apartment_pricing'
  ) THEN
    ALTER TABLE apartment_pricing ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;