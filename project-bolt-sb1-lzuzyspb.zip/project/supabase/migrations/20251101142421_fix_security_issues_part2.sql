/*
  # Fix Security Issues - Part 2: Clean Up Duplicate Policies
  
  1. Remove Duplicate Policies
    - Clean up apartment_details policies
    - Clean up apartments policies
    - Clean up bookings policies
    - Clean up date_specific_availability policies
    - Clean up date_specific_pricing policies
    - Clean up reviews policies
  
  2. Create Clean Policy Set
    - Separate SELECT policies for anon and authenticated
    - Separate write policies for authenticated only
*/

-- Drop all existing policies on apartment_details
DROP POLICY IF EXISTS "allow_all_delete_apartment_details" ON apartment_details;
DROP POLICY IF EXISTS "allow_all_insert_apartment_details" ON apartment_details;
DROP POLICY IF EXISTS "allow_all_select_apartment_details" ON apartment_details;
DROP POLICY IF EXISTS "allow_all_update_apartment_details" ON apartment_details;
DROP POLICY IF EXISTS "apartment_details_delete_policy" ON apartment_details;
DROP POLICY IF EXISTS "apartment_details_insert_policy" ON apartment_details;
DROP POLICY IF EXISTS "apartment_details_select_policy" ON apartment_details;
DROP POLICY IF EXISTS "apartment_details_update_policy" ON apartment_details;
DROP POLICY IF EXISTS "authenticated_users_can_view_apartment_details" ON apartment_details;
DROP POLICY IF EXISTS "Public can view apartment details" ON apartment_details;
DROP POLICY IF EXISTS "Authenticated users can manage apartment details" ON apartment_details;

-- Create clean policies for apartment_details
CREATE POLICY "apartment_details_select_for_all" ON apartment_details
  FOR SELECT USING (true);

CREATE POLICY "apartment_details_write_for_authenticated" ON apartment_details
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up apartments policies
DROP POLICY IF EXISTS "Public can view available apartments" ON apartments;
DROP POLICY IF EXISTS "Authenticated users can manage apartments" ON apartments;

-- Create clean policies for apartments
CREATE POLICY "apartments_select_for_all" ON apartments
  FOR SELECT USING (true);

CREATE POLICY "apartments_write_for_authenticated" ON apartments
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up bookings policies
DROP POLICY IF EXISTS "Anonymous users can view bookings" ON bookings;
DROP POLICY IF EXISTS "Authenticated users can manage bookings" ON bookings;

-- Create clean policies for bookings
CREATE POLICY "bookings_select_for_all" ON bookings
  FOR SELECT USING (true);

CREATE POLICY "bookings_write_for_authenticated" ON bookings
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up date_specific_availability policies
DROP POLICY IF EXISTS "Public can view availability" ON date_specific_availability;
DROP POLICY IF EXISTS "Authenticated users can manage availability" ON date_specific_availability;

-- Create clean policies for date_specific_availability
CREATE POLICY "availability_select_for_all" ON date_specific_availability
  FOR SELECT USING (true);

CREATE POLICY "availability_write_for_authenticated" ON date_specific_availability
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up date_specific_pricing policies
DROP POLICY IF EXISTS "Public can view pricing" ON date_specific_pricing;
DROP POLICY IF EXISTS "Authenticated users can manage pricing" ON date_specific_pricing;

-- Create clean policies for date_specific_pricing
CREATE POLICY "pricing_select_for_all" ON date_specific_pricing
  FOR SELECT USING (true);

CREATE POLICY "pricing_write_for_authenticated" ON date_specific_pricing
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Clean up reviews policies
DROP POLICY IF EXISTS "Public can view public reviews" ON reviews;
DROP POLICY IF EXISTS "Authenticated users can manage reviews" ON reviews;

-- Create clean policies for reviews
CREATE POLICY "reviews_select_for_all" ON reviews
  FOR SELECT USING (is_public = true);

CREATE POLICY "reviews_write_for_authenticated" ON reviews
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- Add policy for apartment_pricing if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'apartment_pricing'
  ) THEN
    EXECUTE 'DROP POLICY IF EXISTS "apartment_pricing_select_for_all" ON apartment_pricing';
    EXECUTE 'DROP POLICY IF EXISTS "apartment_pricing_write_for_authenticated" ON apartment_pricing';
    
    EXECUTE 'CREATE POLICY "apartment_pricing_select_for_all" ON apartment_pricing
      FOR SELECT USING (true)';
    
    EXECUTE 'CREATE POLICY "apartment_pricing_write_for_authenticated" ON apartment_pricing
      FOR ALL TO authenticated USING (true) WITH CHECK (true)';
  END IF;
END $$;