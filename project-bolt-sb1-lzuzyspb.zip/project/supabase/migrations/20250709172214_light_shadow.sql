/*
  # Secure RLS Policies Implementation

  1. Security Configuration
    - Remove all existing permissive policies that allow unauthenticated access
    - Implement strict RLS policies for authenticated users only
    - Set all policies to target 'anon' role with proper authentication checks
    - Ensure unauthenticated users cannot insert, update, or delete records

  2. Policy Structure
    - SELECT: Allow public read access for apartments, apartment_details, apartment_images
    - INSERT/UPDATE/DELETE: Require authentication for all tables
    - Use 'TO anon' with auth.uid() checks for authenticated operations

  3. Tables Covered
    - apartments
    - apartment_details  
    - apartment_images
    - bookings
    - date_specific_pricing
    - date_specific_availability
    - booking_payments
    - reviews

  4. Storage Policies
    - View: Public access for apartment images
    - Upload/Update/Delete: Authenticated users only
*/

-- Drop all existing permissive policies that allow unauthenticated modifications
DO $$
BEGIN
  -- Apartments table
  DROP POLICY IF EXISTS "Public can view available apartments" ON apartments;
  DROP POLICY IF EXISTS "Authenticated users can manage apartments" ON apartments;
  DROP POLICY IF EXISTS "Allow all operations for apartments" ON apartments;

  -- Apartment details table
  DROP POLICY IF EXISTS "allow_all_select_apartment_details" ON apartment_details;
  DROP POLICY IF EXISTS "allow_all_insert_apartment_details" ON apartment_details;
  DROP POLICY IF EXISTS "allow_all_update_apartment_details" ON apartment_details;
  DROP POLICY IF EXISTS "allow_all_delete_apartment_details" ON apartment_details;

  -- Apartment images table
  DROP POLICY IF EXISTS "Allow public SELECT on apartment_images" ON apartment_images;
  DROP POLICY IF EXISTS "Allow public INSERT on apartment_images" ON apartment_images;
  DROP POLICY IF EXISTS "Allow public UPDATE on apartment_images" ON apartment_images;
  DROP POLICY IF EXISTS "Allow public DELETE on apartment_images" ON apartment_images;
  DROP POLICY IF EXISTS "Enable all operations for apartment_images" ON apartment_images;

  -- Bookings table
  DROP POLICY IF EXISTS "Authenticated users can manage bookings" ON bookings;

  -- Date specific pricing table
  DROP POLICY IF EXISTS "Public can view pricing" ON date_specific_pricing;
  DROP POLICY IF EXISTS "Authenticated users can manage pricing" ON date_specific_pricing;

  -- Date specific availability table
  DROP POLICY IF EXISTS "Public can view availability" ON date_specific_availability;
  DROP POLICY IF EXISTS "Authenticated users can manage availability" ON date_specific_availability;

  -- Booking payments table
  DROP POLICY IF EXISTS "Authenticated users can manage payments" ON booking_payments;

  -- Reviews table
  DROP POLICY IF EXISTS "Public can view public reviews" ON reviews;
  DROP POLICY IF EXISTS "Authenticated users can manage reviews" ON reviews;

EXCEPTION
  WHEN undefined_object THEN
    NULL; -- Ignore if policies don't exist
END $$;

-- APARTMENTS TABLE POLICIES
-- Public can view available apartments
CREATE POLICY "apartments_select_policy"
  ON apartments
  FOR SELECT
  TO anon
  USING (is_available = true AND is_active = true);

-- Only authenticated users can insert apartments
CREATE POLICY "apartments_insert_policy"
  ON apartments
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update apartments
CREATE POLICY "apartments_update_policy"
  ON apartments
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete apartments
CREATE POLICY "apartments_delete_policy"
  ON apartments
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- APARTMENT DETAILS TABLE POLICIES
-- Public can view apartment details
CREATE POLICY "apartment_details_select_policy"
  ON apartment_details
  FOR SELECT
  TO anon
  USING (true);

-- Only authenticated users can insert apartment details
CREATE POLICY "apartment_details_insert_policy"
  ON apartment_details
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update apartment details
CREATE POLICY "apartment_details_update_policy"
  ON apartment_details
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete apartment details
CREATE POLICY "apartment_details_delete_policy"
  ON apartment_details
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- APARTMENT IMAGES TABLE POLICIES
-- Public can view apartment images
CREATE POLICY "apartment_images_select_policy"
  ON apartment_images
  FOR SELECT
  TO anon
  USING (true);

-- Only authenticated users can insert apartment images
CREATE POLICY "apartment_images_insert_policy"
  ON apartment_images
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update apartment images
CREATE POLICY "apartment_images_update_policy"
  ON apartment_images
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete apartment images
CREATE POLICY "apartment_images_delete_policy"
  ON apartment_images
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- BOOKINGS TABLE POLICIES
-- Only authenticated users can view bookings
CREATE POLICY "bookings_select_policy"
  ON bookings
  FOR SELECT
  TO anon
  USING (auth.uid() IS NOT NULL);

-- Only authenticated users can insert bookings
CREATE POLICY "bookings_insert_policy"
  ON bookings
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update bookings
CREATE POLICY "bookings_update_policy"
  ON bookings
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete bookings
CREATE POLICY "bookings_delete_policy"
  ON bookings
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- DATE SPECIFIC PRICING TABLE POLICIES
-- Public can view pricing
CREATE POLICY "date_pricing_select_policy"
  ON date_specific_pricing
  FOR SELECT
  TO anon
  USING (true);

-- Only authenticated users can insert pricing
CREATE POLICY "date_pricing_insert_policy"
  ON date_specific_pricing
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update pricing
CREATE POLICY "date_pricing_update_policy"
  ON date_specific_pricing
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete pricing
CREATE POLICY "date_pricing_delete_policy"
  ON date_specific_pricing
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- DATE SPECIFIC AVAILABILITY TABLE POLICIES
-- Public can view availability
CREATE POLICY "date_availability_select_policy"
  ON date_specific_availability
  FOR SELECT
  TO anon
  USING (true);

-- Only authenticated users can insert availability
CREATE POLICY "date_availability_insert_policy"
  ON date_specific_availability
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update availability
CREATE POLICY "date_availability_update_policy"
  ON date_specific_availability
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete availability
CREATE POLICY "date_availability_delete_policy"
  ON date_specific_availability
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- BOOKING PAYMENTS TABLE POLICIES
-- Only authenticated users can view payments
CREATE POLICY "booking_payments_select_policy"
  ON booking_payments
  FOR SELECT
  TO anon
  USING (auth.uid() IS NOT NULL);

-- Only authenticated users can insert payments
CREATE POLICY "booking_payments_insert_policy"
  ON booking_payments
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update payments
CREATE POLICY "booking_payments_update_policy"
  ON booking_payments
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete payments
CREATE POLICY "booking_payments_delete_policy"
  ON booking_payments
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- REVIEWS TABLE POLICIES
-- Public can view public reviews
CREATE POLICY "reviews_select_policy"
  ON reviews
  FOR SELECT
  TO anon
  USING (is_public = true OR auth.uid() IS NOT NULL);

-- Only authenticated users can insert reviews
CREATE POLICY "reviews_insert_policy"
  ON reviews
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can update reviews
CREATE POLICY "reviews_update_policy"
  ON reviews
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Only authenticated users can delete reviews
CREATE POLICY "reviews_delete_policy"
  ON reviews
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);

-- STORAGE POLICIES FOR APARTMENT IMAGES
-- Drop all existing storage policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Allow public SELECT on apartments bucket" ON storage.objects;
  DROP POLICY IF EXISTS "Allow public INSERT on apartments bucket" ON storage.objects;
  DROP POLICY IF EXISTS "Allow public UPDATE on apartments bucket" ON storage.objects;
  DROP POLICY IF EXISTS "Allow public DELETE on apartments bucket" ON storage.objects;
  DROP POLICY IF EXISTS "Public can view apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can insert apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can update apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can delete apartment images" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN
    NULL; -- Ignore if policies don't exist
END $$;

-- Create secure storage policies
-- Public can view apartment images
CREATE POLICY "storage_apartments_select_policy"
  ON storage.objects
  FOR SELECT
  TO anon
  USING (bucket_id = 'apartments');

-- Only authenticated users can upload apartment images
CREATE POLICY "storage_apartments_insert_policy"
  ON storage.objects
  FOR INSERT
  TO anon
  WITH CHECK (bucket_id = 'apartments' AND auth.uid() IS NOT NULL);

-- Only authenticated users can update apartment images
CREATE POLICY "storage_apartments_update_policy"
  ON storage.objects
  FOR UPDATE
  TO anon
  USING (bucket_id = 'apartments' AND auth.uid() IS NOT NULL)
  WITH CHECK (bucket_id = 'apartments' AND auth.uid() IS NOT NULL);

-- Only authenticated users can delete apartment images
CREATE POLICY "storage_apartments_delete_policy"
  ON storage.objects
  FOR DELETE
  TO anon
  USING (bucket_id = 'apartments' AND auth.uid() IS NOT NULL);

-- Ensure RLS is enabled on all tables
ALTER TABLE apartments ENABLE ROW LEVEL SECURITY;
ALTER TABLE apartment_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE apartment_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE booking_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions to anon role (this represents both authenticated and unauthenticated users)
GRANT SELECT ON apartments TO anon;
GRANT SELECT ON apartment_details TO anon;
GRANT SELECT ON apartment_images TO anon;
GRANT SELECT ON date_specific_pricing TO anon;
GRANT SELECT ON date_specific_availability TO anon;

-- Grant full permissions to authenticated users (they will pass the auth.uid() IS NOT NULL check)
GRANT ALL ON apartments TO anon;
GRANT ALL ON apartment_details TO anon;
GRANT ALL ON apartment_images TO anon;
GRANT ALL ON bookings TO anon;
GRANT ALL ON date_specific_pricing TO anon;
GRANT ALL ON date_specific_availability TO anon;
GRANT ALL ON booking_payments TO anon;
GRANT ALL ON reviews TO anon;

-- Grant storage permissions
GRANT ALL ON storage.objects TO anon;
GRANT USAGE ON SCHEMA storage TO anon;