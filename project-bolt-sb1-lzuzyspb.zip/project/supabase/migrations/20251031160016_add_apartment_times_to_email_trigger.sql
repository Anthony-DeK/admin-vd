/*
  # Add Apartment Check-in/Check-out Times to Email Trigger

  1. Changes
    - Update trigger function to fetch check-in and check-out times from apartment_details
    - Include these times in the booking data sent to edge function
  
  2. New Variables Available
    - check_in_time: The property's check-in time (e.g., "3:00 PM")
    - check_out_time: The property's check-out time (e.g., "11:00 AM")
*/

DROP FUNCTION IF EXISTS send_booking_email_notification() CASCADE;

CREATE OR REPLACE FUNCTION send_booking_email_notification()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, extensions, net
AS $$
DECLARE
  event_type text;
  booking_info jsonb;
  apartment_name text;
  apartment_check_in_time text;
  apartment_check_out_time text;
  function_url text;
  request_id bigint;
  anon_key text;
BEGIN
  -- Determine the event type
  IF (TG_OP = 'INSERT' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'confirmed' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'cancelled' AND NEW.status = 'cancelled') THEN
    event_type := 'booking_cancelled';
  ELSE
    -- No email needed for this change
    RETURN NEW;
  END IF;

  -- Get apartment name and times
  SELECT 
    a.name,
    ad.check_in_time,
    ad.check_out_time
  INTO 
    apartment_name,
    apartment_check_in_time,
    apartment_check_out_time
  FROM apartments a
  LEFT JOIN apartment_details ad ON ad.apartment_id = a.id
  WHERE a.id = NEW.apartment_id;

  -- Hardcoded values for this project
  function_url := 'https://hbszokfkhrodyilydqlv.supabase.co/functions/v1/send-booking-email';
  anon_key := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhic3pva2ZraHJvZHlpbHlkcWx2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk2NTkxNzIsImV4cCI6MjA2NTIzNTE3Mn0.ff9bEGQGyRzZXEOCB5wLReH_q7qpCtxVMKWPUnBz1zE';

  -- Prepare booking data with all available information
  booking_info := jsonb_build_object(
    'id', NEW.id,
    'guest_name', NEW.guest_name,
    'guest_email', NEW.guest_email,
    'check_in', NEW.check_in,
    'check_out', NEW.check_out,
    'check_in_time', apartment_check_in_time,
    'check_out_time', apartment_check_out_time,
    'apartment_name', COALESCE(apartment_name, 'Unknown Property'),
    'status', NEW.status,
    'total_amount', NEW.total_amount,
    'guests', NEW.guests
  );

  -- Make async HTTP request with both Authorization and apikey headers
  SELECT net.http_post(
    url := function_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || anon_key,
      'apikey', anon_key
    ),
    body := jsonb_build_object(
      'bookingData', booking_info,
      'event', event_type
    )
  ) INTO request_id;

  -- Log success
  RAISE NOTICE 'Email notification queued: booking_id=%, event=%, request_id=%', NEW.id, event_type, request_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log detailed error
    RAISE WARNING 'Failed to queue email notification for booking %: % (SQLSTATE: %)', NEW.id, SQLERRM, SQLSTATE;
    -- Don't fail the booking operation
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate trigger
DROP TRIGGER IF EXISTS booking_email_notification_trigger ON bookings;
CREATE TRIGGER booking_email_notification_trigger
  AFTER INSERT OR UPDATE OF status
  ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION send_booking_email_notification();