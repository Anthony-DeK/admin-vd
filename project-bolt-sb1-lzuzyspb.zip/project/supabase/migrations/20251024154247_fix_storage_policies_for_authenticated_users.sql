/*
  # Fix Storage Policies for Authenticated Users

  1. Changes
    - Drop existing storage policies for apartments bucket
    - Recreate policies that properly allow authenticated users to upload/manage files
    - Allow public read access to all files in apartments bucket
  
  2. Security
    - Authenticated users can upload, update, and delete files
    - Anonymous users can only read files
    - Policies apply to both anon and authenticated roles
*/

-- Drop existing policies
DROP POLICY IF EXISTS "storage_apartments_select_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_insert_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_update_policy" ON storage.objects;
DROP POLICY IF EXISTS "storage_apartments_delete_policy" ON storage.objects;

-- Allow anyone to read apartment files (public access)
CREATE POLICY "Anyone can read apartment files"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'apartments');

-- Allow authenticated users to upload apartment files
CREATE POLICY "Authenticated users can upload apartment files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'apartments');

-- Allow authenticated users to update apartment files
CREATE POLICY "Authenticated users can update apartment files"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'apartments')
  WITH CHECK (bucket_id = 'apartments');

-- Allow authenticated users to delete apartment files
CREATE POLICY "Authenticated users can delete apartment files"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'apartments');
