/*
  # Add Check-in Instruction Attachments Table

  1. New Tables
    - `check_in_attachments`
      - `id` (uuid, primary key)
      - `apartment_id` (uuid, foreign key to apartments)
      - `file_name` (text, original file name)
      - `file_url` (text, URL to the file)
      - `file_type` (varchar, MIME type)
      - `file_size` (integer, size in bytes)
      - `display_order` (integer, for ordering attachments)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `check_in_attachments` table
    - Add policy for authenticated users to read attachments
    - Add policy for authenticated users to insert attachments
    - Add policy for authenticated users to delete their attachments
    - Add policy for authenticated users to update attachments

  3. Indexes
    - Add index on apartment_id for faster queries
*/

-- Create the check_in_attachments table
CREATE TABLE IF NOT EXISTS check_in_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  apartment_id uuid NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_url text NOT NULL,
  file_type varchar(100),
  file_size integer DEFAULT 0,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE check_in_attachments ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Authenticated users can view check-in attachments"
  ON check_in_attachments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert check-in attachments"
  ON check_in_attachments
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update check-in attachments"
  ON check_in_attachments
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete check-in attachments"
  ON check_in_attachments
  FOR DELETE
  TO authenticated
  USING (true);

-- Create index on apartment_id for faster queries
CREATE INDEX IF NOT EXISTS idx_check_in_attachments_apartment_id 
  ON check_in_attachments(apartment_id);

-- Create index on display_order for ordering
CREATE INDEX IF NOT EXISTS idx_check_in_attachments_display_order 
  ON check_in_attachments(apartment_id, display_order);

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_check_in_attachments_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_check_in_attachments_updated_at
  BEFORE UPDATE ON check_in_attachments
  FOR EACH ROW
  EXECUTE FUNCTION update_check_in_attachments_updated_at();