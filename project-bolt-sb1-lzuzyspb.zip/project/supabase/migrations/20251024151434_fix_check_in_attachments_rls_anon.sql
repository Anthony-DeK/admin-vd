/*
  # Fix Check-in Attachments RLS for Anon Role

  1. Changes
    - Drop existing policies
    - Recreate policies for anon role (like other tables in the app)
    - Use auth.uid() check for authentication

  2. Security
    - All operations require authenticated session (auth.uid() IS NOT NULL)
    - Follows same pattern as apartments and other tables
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can view check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can insert check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can update check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Authenticated users can delete check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated users to view check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated users to insert check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated users to update check-in attachments" ON check_in_attachments;
DROP POLICY IF EXISTS "Allow authenticated users to delete check-in attachments" ON check_in_attachments;

-- Create policies for anon role with auth check
CREATE POLICY "check_in_attachments_select_policy"
  ON check_in_attachments
  FOR SELECT
  TO anon
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "check_in_attachments_insert_policy"
  ON check_in_attachments
  FOR INSERT
  TO anon
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "check_in_attachments_update_policy"
  ON check_in_attachments
  FOR UPDATE
  TO anon
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "check_in_attachments_delete_policy"
  ON check_in_attachments
  FOR DELETE
  TO anon
  USING (auth.uid() IS NOT NULL);