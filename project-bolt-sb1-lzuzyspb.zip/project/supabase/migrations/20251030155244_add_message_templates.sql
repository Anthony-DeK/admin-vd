/*
  # Add Message Templates System

  1. New Tables
    - `message_templates`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text) - Display name for the template
      - `type` (text) - booking_confirmation, booking_cancellation, check_in_reminder, check_out_reminder, post_checkout, custom
      - `subject` (text) - Email subject line
      - `body` (text) - Email body with dynamic placeholders
      - `schedule_type` (text) - immediate, before, after
      - `schedule_value` (integer) - Number of hours/days
      - `schedule_unit` (text) - hours, days
      - `schedule_event` (text) - booking_confirmed, booking_cancelled, check_in, check_out
      - `is_active` (boolean) - Whether template is enabled
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `template_attachments`
      - `id` (uuid, primary key)
      - `template_id` (uuid, foreign key to message_templates)
      - `file_name` (text)
      - `storage_path` (text)
      - `file_size` (integer)
      - `mime_type` (text)
      - `created_at` (timestamptz)
    
    - `user_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users, unique)
      - `sender_email` (text) - Email address used for sending messages
      - `sender_name` (text) - Display name for sender
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users to manage their own templates
    - Add policies for authenticated users to manage their own settings

  3. Storage
    - Create bucket for template attachments
*/

-- Create message_templates table
CREATE TABLE IF NOT EXISTS message_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('booking_confirmation', 'booking_cancellation', 'check_in_reminder', 'check_out_reminder', 'post_checkout', 'custom')),
  subject text NOT NULL,
  body text NOT NULL,
  schedule_type text NOT NULL DEFAULT 'immediate' CHECK (schedule_type IN ('immediate', 'before', 'after')),
  schedule_value integer DEFAULT 0,
  schedule_unit text DEFAULT 'hours' CHECK (schedule_unit IN ('hours', 'days')),
  schedule_event text CHECK (schedule_event IN ('booking_confirmed', 'booking_cancelled', 'check_in', 'check_out')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create template_attachments table
CREATE TABLE IF NOT EXISTS template_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES message_templates(id) ON DELETE CASCADE NOT NULL,
  file_name text NOT NULL,
  storage_path text NOT NULL,
  file_size integer NOT NULL,
  mime_type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create user_settings table
CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  sender_email text NOT NULL,
  sender_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE message_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE template_attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for message_templates
CREATE POLICY "Users can view own templates"
  ON message_templates FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own templates"
  ON message_templates FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own templates"
  ON message_templates FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own templates"
  ON message_templates FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for template_attachments
CREATE POLICY "Users can view own template attachments"
  ON template_attachments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM message_templates
      WHERE message_templates.id = template_attachments.template_id
      AND message_templates.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own template attachments"
  ON template_attachments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM message_templates
      WHERE message_templates.id = template_attachments.template_id
      AND message_templates.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own template attachments"
  ON template_attachments FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM message_templates
      WHERE message_templates.id = template_attachments.template_id
      AND message_templates.user_id = auth.uid()
    )
  );

-- RLS Policies for user_settings
CREATE POLICY "Users can view own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own settings"
  ON user_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create storage bucket for template attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('template-attachments', 'template-attachments', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for template attachments
CREATE POLICY "Users can view own template attachments"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'template-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can upload own template attachments"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'template-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can delete own template attachments"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'template-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);