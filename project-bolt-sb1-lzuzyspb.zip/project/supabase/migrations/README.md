# Database Migrations

## Applying Migrations

To apply the migrations to your Supabase database:

### Option 1: Supabase Dashboard (Recommended)

1. Go to your Supabase project dashboard: https://hbszokfkhrodyilydqlv.supabase.co
2. Click on "SQL Editor" in the left sidebar
3. Open the migration file: `20250710120000_add_structured_house_rules.sql`
4. Copy the entire SQL content
5. Paste it into the SQL Editor
6. Click "Run" to execute the migration

### Option 2: Supabase CLI (If available)

```bash
supabase db push
```

## Latest Migration

**File:** `20250710120000_add_structured_house_rules.sql`

**Description:** Adds structured house rules fields to the `apartment_details` table:
- Boolean fields for permissions (pets, parties, smoking, photoshoots)
- Time fields for quiet hours and check-in/out times
- Text field for additional custom rules

**Status:** ⚠️ **NOT YET APPLIED** - The UI is visible but saving is disabled until this migration is applied.

### After Applying the Migration

1. Apply the SQL migration through Supabase Dashboard (see instructions above)
2. Update the code in `src/hooks/useApartments.ts`:
   - Find the section around line 261 with commented-out field updates
   - Uncomment all the fields (remove the `//` from lines 263-289)
   - Save the file
3. Rebuild the application: `npm run build`
4. Refresh your browser

The structured house rules functionality will then be fully operational.
