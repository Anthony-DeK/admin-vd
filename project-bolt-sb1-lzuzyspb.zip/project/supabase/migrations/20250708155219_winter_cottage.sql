/*
  # Fix Storage Upload Policy for Public Access

  1. Changes
    - Update storage policy to allow public uploads to apartments bucket
    - Remove authentication requirement for image uploads
    - Maintain security for other operations (update/delete still require auth)

  2. Security
    - Public can upload images to apartments bucket
    - Public can view images (existing policy)
    - Only authenticated users can update/delete images
*/

-- Drop the existing restrictive upload policy
DROP POLICY IF EXISTS "Authenticated users can upload apartment images" ON storage.objects;

-- Create new policy that allows public uploads to apartments bucket
CREATE POLICY "Public can upload apartment images"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'apartments');