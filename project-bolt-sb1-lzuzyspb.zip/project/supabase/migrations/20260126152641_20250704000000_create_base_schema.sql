/*
  # Create Base Schema for Accommodation Rental System

  1. New Tables
    - `apartments` - Core property information
    - `apartment_details` - Extended property details and amenities
    - `apartment_images` - Property images with ordering
    - `bookings` - Guest reservations and booking management
    - `date_specific_pricing` - Custom pricing for specific date ranges
    - `date_specific_availability` - Custom availability windows

  2. Security
    - Enable RLS on all tables
    - Public read access for property listings
    - Authenticated users can manage all data

  3. Features
    - Property management with types and capacities
    - Booking system with status tracking
    - Dynamic pricing with date-specific overrides
    - Image management with ordering and categories
    - Amenities and house rules storage
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create apartments table
CREATE TABLE IF NOT EXISTS apartments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('studio', '1bed', '2bed', '3bed')),
  location VARCHAR(255),
  bedrooms INTEGER DEFAULT 0 CHECK (bedrooms >= 0),
  bathrooms DECIMAL(3,1) DEFAULT 1 CHECK (bathrooms > 0),
  max_guests INTEGER NOT NULL CHECK (max_guests > 0),
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create apartment_details table
CREATE TABLE IF NOT EXISTS apartment_details (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  short_description TEXT,
  long_description TEXT,
  amenities TEXT[], -- Array of amenity strings
  house_rules TEXT[], -- Array of house rules
  cover_image TEXT,
  images TEXT[], -- Array of image URLs
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create apartment_images table
CREATE TABLE IF NOT EXISTS apartment_images (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  guest_name VARCHAR(255) NOT NULL,
  guest_email VARCHAR(255) NOT NULL,
  guest_phone VARCHAR(50),
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  guests INTEGER NOT NULL CHECK (guests > 0),
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  total_amount DECIMAL(10,2) NOT NULL CHECK (total_amount >= 0),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Ensure check-out is after check-in
  CONSTRAINT valid_booking_dates CHECK (check_out > check_in)
);

-- Create date_specific_pricing table
CREATE TABLE IF NOT EXISTS date_specific_pricing (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  price_multiplier DECIMAL(4,2) CHECK (price_multiplier > 0),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Ensure end_date is after start_date
  CONSTRAINT valid_pricing_dates CHECK (end_date >= start_date)
);

-- Create date_specific_availability table
CREATE TABLE IF NOT EXISTS date_specific_availability (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Ensure end_date is after start_date
  CONSTRAINT valid_availability_dates CHECK (end_date >= start_date)
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_apartments_updated_at
    BEFORE UPDATE ON apartments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_apartment_details_updated_at
    BEFORE UPDATE ON apartment_details
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_apartment_images_updated_at
    BEFORE UPDATE ON apartment_images
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at
    BEFORE UPDATE ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_date_specific_pricing_updated_at
    BEFORE UPDATE ON date_specific_pricing
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_date_specific_availability_updated_at
    BEFORE UPDATE ON date_specific_availability
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE apartments ENABLE ROW LEVEL SECURITY;
ALTER TABLE apartment_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE apartment_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_specific_availability ENABLE ROW LEVEL SECURITY;

-- RLS Policies for apartments
CREATE POLICY "Public can view available apartments"
  ON apartments FOR SELECT
  USING (is_available = true);

CREATE POLICY "Authenticated users can manage apartments"
  ON apartments FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for apartment_details
CREATE POLICY "Public can view apartment details"
  ON apartment_details FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage apartment details"
  ON apartment_details FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for apartment_images
CREATE POLICY "Public can view apartment images"
  ON apartment_images FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage apartment images"
  ON apartment_images FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for bookings
CREATE POLICY "Authenticated users can manage bookings"
  ON bookings FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for date_specific_pricing
CREATE POLICY "Public can view pricing"
  ON date_specific_pricing FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage pricing"
  ON date_specific_pricing FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- RLS Policies for date_specific_availability
CREATE POLICY "Public can view availability"
  ON date_specific_availability FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage availability"
  ON date_specific_availability FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_apartments_available ON apartments(is_available);
CREATE INDEX IF NOT EXISTS idx_apartments_type ON apartments(type);
CREATE INDEX IF NOT EXISTS idx_apartment_details_apartment ON apartment_details(apartment_id);
CREATE INDEX IF NOT EXISTS idx_apartment_images_apartment ON apartment_images(apartment_id);
CREATE INDEX IF NOT EXISTS idx_bookings_apartment ON bookings(apartment_id);
CREATE INDEX IF NOT EXISTS idx_bookings_dates ON bookings(check_in, check_out);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_date_pricing_apartment ON date_specific_pricing(apartment_id);
CREATE INDEX IF NOT EXISTS idx_date_availability_apartment ON date_specific_availability(apartment_id);