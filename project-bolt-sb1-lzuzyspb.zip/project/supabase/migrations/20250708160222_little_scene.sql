/*
  # Fix RLS policies for image uploads

  1. Storage Policy Updates
    - Drop all existing storage policies to prevent conflicts
    - Create comprehensive policies allowing public access to apartments bucket
    - Ensure both authenticated and anonymous users can perform all operations

  2. Database Policy Updates
    - Drop all existing policies on apartment_images table
    - Create new policies allowing public access for all operations
    - Ensure RLS is properly configured

  3. Bucket Configuration
    - Ensure apartments bucket exists and is public
    - Set proper bucket configuration for file uploads
*/

-- First, ensure the apartments bucket exists and is public
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'apartments', 
  'apartments', 
  true, 
  52428800, -- 50MB limit
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET 
  public = true,
  file_size_limit = 52428800,
  allowed_mime_types = ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

-- Drop all existing storage policies to prevent conflicts
DO $$
BEGIN
  -- Drop storage policies if they exist
  DROP POLICY IF EXISTS "Public can view apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can insert apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can update apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Public can delete apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can update apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can delete apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can upload apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can view apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can update apartment images" ON storage.objects;
  DROP POLICY IF EXISTS "Anyone can delete apartment images" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN
    NULL; -- Ignore if policies don't exist
END $$;

-- Create comprehensive storage policies for apartments bucket
CREATE POLICY "Allow public SELECT on apartments bucket"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'apartments');

CREATE POLICY "Allow public INSERT on apartments bucket"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'apartments');

CREATE POLICY "Allow public UPDATE on apartments bucket"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'apartments')
WITH CHECK (bucket_id = 'apartments');

CREATE POLICY "Allow public DELETE on apartments bucket"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'apartments');

-- Drop all existing policies on apartment_images table
DO $$
BEGIN
  DROP POLICY IF EXISTS "apartment_images_delete_policy" ON apartment_images;
  DROP POLICY IF EXISTS "apartment_images_insert_policy" ON apartment_images;
  DROP POLICY IF EXISTS "apartment_images_select_policy" ON apartment_images;
  DROP POLICY IF EXISTS "apartment_images_update_policy" ON apartment_images;
  DROP POLICY IF EXISTS "Enable all operations for apartment_images" ON apartment_images;
  DROP POLICY IF EXISTS "Public can view apartment images" ON apartment_images;
  DROP POLICY IF EXISTS "Public can insert apartment images" ON apartment_images;
  DROP POLICY IF EXISTS "Public can update apartment images" ON apartment_images;
  DROP POLICY IF EXISTS "Public can delete apartment images" ON apartment_images;
EXCEPTION
  WHEN undefined_object THEN
    NULL; -- Ignore if policies don't exist
END $$;

-- Create comprehensive policies for apartment_images table
CREATE POLICY "Allow public SELECT on apartment_images"
ON apartment_images FOR SELECT
TO public
USING (true);

CREATE POLICY "Allow public INSERT on apartment_images"
ON apartment_images FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Allow public UPDATE on apartment_images"
ON apartment_images FOR UPDATE
TO public
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow public DELETE on apartment_images"
ON apartment_images FOR DELETE
TO public
USING (true);

-- Ensure RLS is enabled on apartment_images table
ALTER TABLE apartment_images ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions to anon and authenticated roles
GRANT ALL ON apartment_images TO anon;
GRANT ALL ON apartment_images TO authenticated;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;