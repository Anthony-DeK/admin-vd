/*
  # Add Authorization Header to Email Trigger

  1. Changes
    - Add anon key to HTTP request headers
    - This allows the edge function to be called from the database trigger
  
  2. Security
    - Uses anon key which is safe for public access
    - Edge function has verify_jwt set to false
*/

-- Drop and recreate the function with auth header
DROP FUNCTION IF EXISTS send_booking_email_notification() CASCADE;

CREATE OR REPLACE FUNCTION send_booking_email_notification()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public, extensions, net
AS $$
DECLARE
  event_type text;
  booking_info jsonb;
  apartment_name text;
  function_url text;
  request_id bigint;
BEGIN
  -- Determine the event type
  IF (TG_OP = 'INSERT' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'confirmed' AND NEW.status = 'confirmed') THEN
    event_type := 'booking_confirmed';
  ELSIF (TG_OP = 'UPDATE' AND OLD.status != 'cancelled' AND NEW.status = 'cancelled') THEN
    event_type := 'booking_cancelled';
  ELSE
    -- No email needed for this change
    RETURN NEW;
  END IF;

  -- Get apartment name
  SELECT name INTO apartment_name
  FROM apartments
  WHERE id = NEW.apartment_id;

  -- Use hardcoded Supabase URL for this project
  function_url := 'https://hbszokfkhrodyilydqlv.supabase.co/functions/v1/send-booking-email';

  -- Prepare booking data
  booking_info := jsonb_build_object(
    'id', NEW.id,
    'guest_name', NEW.guest_name,
    'guest_email', NEW.guest_email,
    'check_in', NEW.check_in,
    'check_out', NEW.check_out,
    'apartment_name', COALESCE(apartment_name, 'Unknown Property'),
    'status', NEW.status,
    'total_amount', NEW.total_amount,
    'guests', NEW.guests
  );

  -- Make async HTTP request using net.http_post with authorization header
  SELECT net.http_post(
    url := function_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhic3pva2ZraHJvZHlpbHlkcWx2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk2NTkxNzIsImV4cCI6MjA2NTIzNTE3Mn0.ff9bEGQGyRzZXEOCB5wLReH_q7qpCtxVMKWPUnBz1zE'
    ),
    body := jsonb_build_object(
      'bookingData', booking_info,
      'event', event_type
    )
  ) INTO request_id;

  -- Log success
  RAISE NOTICE 'Email notification queued: booking_id=%, event=%, request_id=%', NEW.id, event_type, request_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log detailed error
    RAISE WARNING 'Failed to queue email notification for booking %: % (SQLSTATE: %)', NEW.id, SQLERRM, SQLSTATE;
    -- Don't fail the booking operation
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate trigger
DROP TRIGGER IF EXISTS booking_email_notification_trigger ON bookings;
CREATE TRIGGER booking_email_notification_trigger
  AFTER INSERT OR UPDATE OF status
  ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION send_booking_email_notification();