import React, { useState, useEffect } from 'react';
import { X, Check, DollarSign, Calendar } from 'lucide-react';

interface CustomPricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: CustomPricingData) => void;
  selectedDates: Date[];
  basePrice: number;
  baseMinStay: number;
  existingData?: CustomPricingData | null;
  isLoading?: boolean;
}

export interface CustomPricingData {
  fixedPrice: string;
  minimumStay: string;
  priceRange?: { min: number; max: number };
  stayRange?: { min: number; max: number };
}

export const CustomPricingModal: React.FC<CustomPricingModalProps> = ({
  isOpen,
  onClose,
  onSave,
  selectedDates,
  basePrice,
  baseMinStay,
  existingData,
  isLoading = false
}) => {
  const [fixedPrice, setFixedPrice] = useState('');
  const [minimumStay, setMinimumStay] = useState('');

  useEffect(() => {
    console.log('CustomPricingModal - existingData:', existingData);
    if (existingData) {
      // Only set values if there's no range (empty string means range exists)
      setFixedPrice(existingData.fixedPrice || '');
      setMinimumStay(existingData.minimumStay || '');
    } else {
      setFixedPrice('');
      setMinimumStay('');
    }
  }, [existingData, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      fixedPrice,
      minimumStay
    });
  };

  const formatDateRange = () => {
    if (selectedDates.length === 0) return '';
    if (selectedDates.length === 1) {
      return selectedDates[0].toLocaleDateString();
    }

    const sortedDates = [...selectedDates].sort((a, b) => a.getTime() - b.getTime());
    return `${sortedDates[0].toLocaleDateString()} - ${sortedDates[sortedDates.length - 1].toLocaleDateString()}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-md bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Custom Pricing</h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="px-6 py-6 space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-blue-800 mb-1">
                <Calendar className="w-4 h-4" />
                <span className="text-sm font-medium">Selected Dates</span>
              </div>
              <p className="text-sm text-blue-700">{formatDateRange()}</p>
              <p className="text-xs text-blue-600 mt-1">{selectedDates.length} date{selectedDates.length !== 1 ? 's' : ''} selected</p>
            </div>

            <div>
              <label htmlFor="fixedPrice" className="block text-sm font-medium text-gray-700 mb-2">
                Price per Night
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <DollarSign className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="fixedPrice"
                  value={fixedPrice}
                  onChange={(e) => setFixedPrice(e.target.value)}
                  min="0"
                  step="0.01"
                  placeholder={basePrice.toString()}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                />
              </div>
              {existingData?.priceRange ? (
                <p className="text-xs text-amber-600 mt-1 font-medium">
                  Current range: ${existingData.priceRange.min} - ${existingData.priceRange.max}/night
                </p>
              ) : (
                <p className="text-xs text-gray-500 mt-1">Base price: ${basePrice}/night</p>
              )}
            </div>

            <div>
              <label htmlFor="minimumStay" className="block text-sm font-medium text-gray-700 mb-2">
                Minimum Stay (nights)
              </label>
              <input
                type="number"
                id="minimumStay"
                value={minimumStay}
                onChange={(e) => setMinimumStay(e.target.value.replace(/\D/g, ''))}
                min="1"
                placeholder={baseMinStay.toString()}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
              {existingData?.stayRange ? (
                <p className="text-xs text-amber-600 mt-1 font-medium">
                  Current range: {existingData.stayRange.min} - {existingData.stayRange.max} night{existingData.stayRange.max !== 1 ? 's' : ''}
                </p>
              ) : (
                <p className="text-xs text-gray-500 mt-1">Base minimum stay: {baseMinStay} night{baseMinStay !== 1 ? 's' : ''}</p>
              )}
            </div>
          </div>

          <div className="px-6 py-4 border-t border-gray-200 bg-white flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={isLoading}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isLoading ? 'Saving...' : 'Save Custom Pricing'}
            </button>
            <button
              onClick={onClose}
              disabled={isLoading}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
      </div>
    </div>
  );
};
