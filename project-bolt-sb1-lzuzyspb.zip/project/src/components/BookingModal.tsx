import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Booking, Apartment } from '../types';
import { supabase } from '../lib/supabase';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (booking: Partial<Booking>) => void;
  booking?: Booking;
  apartments: Apartment[];
}

interface DatePricing {
  date: string;
  price: number;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  onSave,
  booking,
  apartments
}) => {
  const [formData, setFormData] = useState({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    checkIn: '',
    checkOut: '',
    apartment: '',
    status: 'pending' as Booking['status'],
    totalAmount: 0,
    guests: 1,
    notes: ''
  });
  const [isCalculating, setIsCalculating] = useState(false);

  useEffect(() => {
    if (booking) {
      setFormData({
        guestName: booking.guestName,
        guestEmail: booking.guestEmail,
        guestPhone: booking.guestPhone,
        checkIn: booking.checkIn,
        checkOut: booking.checkOut,
        apartment: booking.apartment,
        status: booking.status,
        totalAmount: booking.totalAmount,
        guests: booking.guests,
        notes: booking.notes || ''
      });
    } else {
      setFormData({
        guestName: '',
        guestEmail: '',
        guestPhone: '',
        checkIn: '',
        checkOut: '',
        apartment: apartments[0]?.name || '',
        status: 'pending',
        totalAmount: 0,
        guests: 1,
        notes: ''
      });
    }
  }, [booking, apartments, isOpen]);

  const formatDate = (year: number, month: number, day: number) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const calculateTotalAmount = async () => {
    if (!formData.apartment || !formData.checkIn || !formData.checkOut) {
      return;
    }

    const selectedApartment = apartments.find(apt => apt.name === formData.apartment);
    if (!selectedApartment) {
      return;
    }

    setIsCalculating(true);

    try {
      const checkInDate = new Date(formData.checkIn + 'T00:00:00');
      const checkOutDate = new Date(formData.checkOut + 'T00:00:00');

      if (checkOutDate <= checkInDate) {
        setIsCalculating(false);
        return;
      }

      const { data: customPricingData, error: pricingError } = await supabase
        .from('date_specific_pricing')
        .select('*')
        .eq('apartment_id', selectedApartment.id);

      if (pricingError) {
        console.error('Error fetching pricing:', pricingError);
        setIsCalculating(false);
        return;
      }

      const pricingMap = new Map<string, number>();

      if (customPricingData) {
        customPricingData.forEach((entry) => {
          const start = new Date(entry.start_date + 'T00:00:00');
          const end = new Date(entry.end_date + 'T00:00:00');

          const currentDate = new Date(start);
          while (currentDate <= end) {
            const dateStr = formatDate(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
            if (entry.fixed_price) {
              pricingMap.set(dateStr, entry.fixed_price);
            }
            currentDate.setDate(currentDate.getDate() + 1);
          }
        });
      }

      let totalNightlyRate = 0;
      const currentDate = new Date(checkInDate);

      while (currentDate < checkOutDate) {
        const dateStr = formatDate(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
        const nightlyPrice = pricingMap.get(dateStr) || selectedApartment.basePrice || 0;
        totalNightlyRate += nightlyPrice;
        currentDate.setDate(currentDate.getDate() + 1);
      }

      const cleaningFee = selectedApartment.cleaningFee || 0;
      const serviceFee = selectedApartment.serviceFee || 0;
      const totalAmount = totalNightlyRate + cleaningFee + serviceFee;

      setFormData(prev => ({
        ...prev,
        totalAmount: Math.round(totalAmount * 100) / 100
      }));
    } catch (error) {
      console.error('Error calculating total:', error);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    if (!booking) {
      calculateTotalAmount();
    }
  }, [formData.apartment, formData.checkIn, formData.checkOut]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      id: booking?.id,
      createdAt: booking?.createdAt || new Date().toISOString()
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            {booking ? 'Edit Booking' : 'Add New Booking'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="guestName" className="block text-sm font-medium text-gray-700 mb-2">
                Guest Name *
              </label>
              <input
                type="text"
                id="guestName"
                name="guestName"
                value={formData.guestName}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="guestEmail" className="block text-sm font-medium text-gray-700 mb-2">
                Email *
              </label>
              <input
                type="email"
                id="guestEmail"
                name="guestEmail"
                value={formData.guestEmail}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="guestPhone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone
              </label>
              <input
                type="tel"
                id="guestPhone"
                name="guestPhone"
                value={formData.guestPhone}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="apartment" className="block text-sm font-medium text-gray-700 mb-2">
                Property *
              </label>
              <select
                id="apartment"
                name="apartment"
                value={formData.apartment}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              >
                {apartments.map(apt => (
                  <option key={apt.id} value={apt.name}>{apt.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="checkIn" className="block text-sm font-medium text-gray-700 mb-2">
                Check-in Date *
              </label>
              <input
                type="date"
                id="checkIn"
                name="checkIn"
                value={formData.checkIn}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="checkOut" className="block text-sm font-medium text-gray-700 mb-2">
                Check-out Date *
              </label>
              <input
                type="date"
                id="checkOut"
                name="checkOut"
                value={formData.checkOut}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="guests" className="block text-sm font-medium text-gray-700 mb-2">
                Number of Guests *
              </label>
              <input
                type="number"
                id="guests"
                name="guests"
                value={formData.guests}
                onChange={handleChange}
                min="1"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>

            <div>
              <label htmlFor="totalAmount" className="block text-sm font-medium text-gray-700 mb-2">
                Total Amount ($) *
              </label>
              <div className="relative">
                <input
                  type="number"
                  id="totalAmount"
                  name="totalAmount"
                  value={formData.totalAmount}
                  onChange={handleChange}
                  min="0"
                  step="0.01"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                  disabled={isCalculating}
                />
                {isCalculating && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <div className="w-4 h-4 border-2 border-coral-500 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                )}
              </div>
              {!booking && formData.apartment && formData.checkIn && formData.checkOut && (
                <p className="text-xs text-gray-500 mt-1">Auto-calculated based on nightly rates + fees</p>
              )}
            </div>

            <div>
              <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              >
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-2">
              Notes
            </label>
            <textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              placeholder="Any special requests or notes..."
            />
          </div>

          <div className="flex items-center justify-end gap-4 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-coral-500 hover:bg-coral-600 text-white rounded-lg transition-colors"
            >
              {booking ? 'Update Booking' : 'Create Booking'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};