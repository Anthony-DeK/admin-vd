import React, { useState } from 'react';
import { Upload, X, FileText, Loader, File, Plus } from 'lucide-react';

export interface Attachment {
  id: string;
  fileName: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: number;
  displayOrder: number;
  storagePath?: string;
}

const isImageFile = (fileName: string, fileType?: string): boolean => {
  if (fileType?.startsWith('image/')) return true;
  const ext = fileName.toLowerCase().split('.').pop();
  return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext || '');
};

const isDocumentFile = (fileName: string, fileType?: string): boolean => {
  if (fileType === 'application/pdf') return true;
  if (fileType?.includes('document') || fileType?.includes('msword')) return true;
  const ext = fileName.toLowerCase().split('.').pop();
  return ['pdf', 'doc', 'docx'].includes(ext || '');
};

interface AttachmentManagerProps {
  attachments: Attachment[];
  onUpload: (files: FileList) => Promise<void>;
  onDelete: (attachmentId: string) => Promise<void>;
  isUploading?: boolean;
  maxFileSizeMB?: number;
}

export const AttachmentManager: React.FC<AttachmentManagerProps> = ({
  attachments,
  onUpload,
  onDelete,
  isUploading = false,
  maxFileSizeMB = 10
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'Unknown size';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };

  const handleFiles = async (files: FileList) => {
    const maxSizeBytes = maxFileSizeMB * 1024 * 1024;
    const oversizedFiles = Array.from(files).filter(f => f.size > maxSizeBytes);

    if (oversizedFiles.length > 0) {
      alert(`Some files exceed the maximum size of ${maxFileSizeMB}MB and will not be uploaded.`);
      return;
    }

    await onUpload(files);
  };

  const handleDelete = async (attachmentId: string) => {
    if (!confirm('Are you sure you want to delete this attachment?')) {
      return;
    }

    try {
      setDeletingId(attachmentId);
      await onDelete(attachmentId);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div
      className={`${
        dragActive ? 'ring-2 ring-coral-500 ring-offset-2' : ''
      }`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      <input
        type="file"
        id="attachment-upload"
        className="hidden"
        multiple
        accept="image/*,.pdf,.doc,.docx"
        onChange={handleFileInput}
        disabled={isUploading}
      />

      {/* Upload Button and Attachments Grid */}
      <div className="flex flex-wrap gap-3">
        {/* Upload Button */}
        <label
          htmlFor="attachment-upload"
          className={`flex items-center justify-center w-20 h-20 border-2 border-dashed rounded-lg transition-colors cursor-pointer border-gray-300 hover:border-gray-400 bg-gray-50 hover:bg-gray-100 ${
            isUploading ? 'opacity-50 pointer-events-none' : ''
          }`}
        >
          {isUploading ? (
            <Loader className="w-8 h-8 text-gray-400 animate-spin" />
          ) : (
            <Plus className="w-8 h-8 text-gray-400" />
          )}
        </label>

        {/* Attachments */}
        {attachments.map((attachment) => {
          const isImage = isImageFile(attachment.fileName, attachment.fileType);
          const isDocument = isDocumentFile(attachment.fileName, attachment.fileType);

          return (
            <div
              key={attachment.id}
              className="relative group w-20"
            >
              {/* Preview/Icon */}
              {isImage ? (
                <div className="w-20 h-20 rounded overflow-hidden bg-gray-200 border border-gray-200">
                  <img
                    src={attachment.fileUrl}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : isDocument ? (
                <div className="w-20 h-20 rounded bg-gray-200 flex flex-col items-center justify-center border border-gray-200">
                  <FileText className="w-8 h-8 text-gray-600" />
                </div>
              ) : (
                <div className="w-20 h-20 rounded bg-gray-200 flex flex-col items-center justify-center border border-gray-200">
                  <File className="w-8 h-8 text-gray-600" />
                </div>
              )}

              {/* File size below */}
              <p className="text-xs text-gray-500 text-center mt-1">
                {formatFileSize(attachment.fileSize)}
              </p>

              {/* Delete button */}
              <button
                onClick={() => handleDelete(attachment.id)}
                disabled={deletingId === attachment.id}
                className="absolute -top-2 -right-2 p-1.5 bg-white rounded-full shadow-md text-gray-600 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50 border border-gray-200"
                title="Delete"
              >
                {deletingId === attachment.id ? (
                  <Loader className="w-3 h-3 animate-spin" />
                ) : (
                  <X className="w-3 h-3" />
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
