import React from 'react';
import { X } from 'lucide-react';

interface HouseRulesData {
  petsAllowed?: boolean;
  partiesAllowed?: boolean;
  smokingAllowed?: boolean;
  photoshootsAllowed?: boolean;
  quietHoursStart?: string;
  quietHoursEnd?: string;
  checkInTime?: string;
  checkOutTime?: string;
  customHouseRules?: string;
  maxGuests?: number;
}

interface HouseRulesEditorProps {
  data: HouseRulesData;
  onChange: (data: Partial<HouseRulesData>) => void;
}

export const HouseRulesEditor: React.FC<HouseRulesEditorProps> = ({
  data,
  onChange
}) => {
  if (!data) {
    return <div className="text-red-600">Error: No data provided to editor</div>;
  }

  return (
    <div className="space-y-6">
      {/* Permissions */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Permissions</h3>
        <div className="space-y-3">
          <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
            <span className="text-gray-700">Pets Allowed</span>
            <input
              type="checkbox"
              checked={data.petsAllowed ?? false}
              onChange={(e) => onChange({ petsAllowed: e.target.checked })}
              className="w-5 h-5 text-coral-500 rounded focus:ring-2 focus:ring-coral-500"
            />
          </label>

          <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
            <span className="text-gray-700">Parties / Events Allowed</span>
            <input
              type="checkbox"
              checked={data.partiesAllowed ?? false}
              onChange={(e) => onChange({ partiesAllowed: e.target.checked })}
              className="w-5 h-5 text-coral-500 rounded focus:ring-2 focus:ring-coral-500"
            />
          </label>

          <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
            <span className="text-gray-700">Smoking / Vaping Allowed</span>
            <input
              type="checkbox"
              checked={data.smokingAllowed ?? false}
              onChange={(e) => onChange({ smokingAllowed: e.target.checked })}
              className="w-5 h-5 text-coral-500 rounded focus:ring-2 focus:ring-coral-500"
            />
          </label>

          <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
            <span className="text-gray-700">Photoshoots / Filmmaking Allowed</span>
            <input
              type="checkbox"
              checked={data.photoshootsAllowed ?? false}
              onChange={(e) => onChange({ photoshootsAllowed: e.target.checked })}
              className="w-5 h-5 text-coral-500 rounded focus:ring-2 focus:ring-coral-500"
            />
          </label>
        </div>
      </div>

      {/* Guest Capacity */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Guest Capacity</h3>
        <div>
          <label htmlFor="maxGuests" className="block text-sm font-medium text-gray-700 mb-2">
            Maximum Guests
          </label>
          <input
            type="number"
            id="maxGuests"
            min="1"
            value={data.maxGuests || 1}
            onChange={(e) => onChange({ maxGuests: parseInt(e.target.value) || 1 })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
          />
        </div>
      </div>

      {/* Quiet Hours */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Quiet Hours</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="quietHoursStart" className="block text-sm font-medium text-gray-700 mb-2">
              Start Time
            </label>
            <input
              type="time"
              id="quietHoursStart"
              value={data.quietHoursStart || ''}
              onChange={(e) => onChange({ quietHoursStart: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
          <div>
            <label htmlFor="quietHoursEnd" className="block text-sm font-medium text-gray-700 mb-2">
              End Time
            </label>
            <input
              type="time"
              id="quietHoursEnd"
              value={data.quietHoursEnd || ''}
              onChange={(e) => onChange({ quietHoursEnd: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
        </div>
      </div>

      {/* Check-in and Check-out Times */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Arrival & Departure</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="checkInTime" className="block text-sm font-medium text-gray-700 mb-2">
              Check-in Time
            </label>
            <input
              type="time"
              id="checkInTime"
              value={data.checkInTime || ''}
              onChange={(e) => onChange({ checkInTime: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
          <div>
            <label htmlFor="checkOutTime" className="block text-sm font-medium text-gray-700 mb-2">
              Check-out Time
            </label>
            <input
              type="time"
              id="checkOutTime"
              value={data.checkOutTime || ''}
              onChange={(e) => onChange({ checkOutTime: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
        </div>
      </div>

      {/* Additional Custom Rules */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Additional Rules</h3>
        <textarea
          value={data.customHouseRules || ''}
          onChange={(e) => onChange({ customHouseRules: e.target.value })}
          placeholder="Enter any additional house rules or special instructions..."
          rows={4}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
        />
      </div>

    </div>
  );
};
