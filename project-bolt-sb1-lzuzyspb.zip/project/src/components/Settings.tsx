import React, { useState, useEffect } from 'react';
import { Mail, Save, User, Info } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { UserSettings } from '../types';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';

export const Settings: React.FC = () => {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [formData, setFormData] = useState({
    senderEmail: '',
    senderName: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string>('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  useEffect(() => {
    loadSettings();
    loadUserEmail();
  }, []);

  const loadUserEmail = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.email) {
        setUserEmail(user.email);
        setIsAnonymous(false);
      } else {
        setUserEmail('guest@example.com (Preview Mode)');
        setIsAnonymous(true);
      }
    } catch (err) {
      console.error('Error loading user email:', err);
    }
  };

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      const userId = user?.id || 'anonymous';

      const { data, error: fetchError } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (data) {
        const mappedSettings: UserSettings = {
          id: data.id,
          userId: data.user_id,
          senderEmail: data.sender_email,
          senderName: data.sender_name,
          createdAt: data.created_at,
          updatedAt: data.updated_at
        };

        setSettings(mappedSettings);
        setFormData({
          senderEmail: mappedSettings.senderEmail,
          senderName: mappedSettings.senderName
        });
      } else {
        // Set default values if no settings exist yet
        setFormData({
          senderEmail: user?.email || 'guest@example.com',
          senderName: user?.user_metadata?.full_name || 'Guest User'
        });
      }
    } catch (err) {
      console.error('Error loading settings:', err);
      setError('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setSuccessMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const userId = user?.id || 'anonymous';

      const settingsData = {
        user_id: userId,
        sender_email: formData.senderEmail,
        sender_name: formData.senderName,
        updated_at: new Date().toISOString()
      };

      if (settings) {
        // Update existing settings
        const { error: updateError } = await supabase
          .from('user_settings')
          .update(settingsData)
          .eq('id', settings.id);

        if (updateError) throw updateError;
      } else {
        // Create new settings
        const { error: insertError } = await supabase
          .from('user_settings')
          .insert(settingsData);

        if (insertError) throw insertError;
      }

      setSuccessMessage('Settings saved successfully');
      await loadSettings();
    } catch (err) {
      console.error('Error saving settings:', err);
      setError('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="max-w-4xl">
      {isAnonymous && (
        <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="text-sm font-semibold text-blue-900 mb-1">Preview Mode</h3>
            <p className="text-sm text-blue-800">
              You're viewing settings in preview mode. Changes made here are for testing purposes only.
              Sign in to save your actual email configuration.
            </p>
          </div>
        </div>
      )}

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-2">Manage your account and email preferences</p>
      </div>

      {error && (
        <div className="mb-6">
          <ErrorMessage message={error} />
        </div>
      )}

      {successMessage && (
        <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
          {successMessage}
        </div>
      )}

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        {/* Account Information Section */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <User className="w-6 h-6 text-coral-500" />
            <h2 className="text-xl font-semibold text-gray-900">Account Information</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Account Email
              </label>
              <input
                type="email"
                value={userEmail}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
              />
              <p className="text-xs text-gray-500 mt-1">
                This is your login email and cannot be changed here
              </p>
            </div>
          </div>
        </div>

        {/* Email Settings Section */}
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Mail className="w-6 h-6 text-coral-500" />
            <h2 className="text-xl font-semibold text-gray-900">Email Configuration</h2>
          </div>

          <p className="text-sm text-gray-600 mb-6">
            Configure the sender information for automated emails sent to your guests
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="senderName" className="block text-sm font-medium text-gray-700 mb-2">
                Sender Name *
              </label>
              <input
                type="text"
                id="senderName"
                name="senderName"
                value={formData.senderName}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                placeholder="Your name or business name"
              />
              <p className="text-xs text-gray-500 mt-1">
                This name will appear in the "From" field of emails sent to guests
              </p>
            </div>

            <div>
              <label htmlFor="senderEmail" className="block text-sm font-medium text-gray-700 mb-2">
                Sender Email Address *
              </label>
              <input
                type="email"
                id="senderEmail"
                name="senderEmail"
                value={formData.senderEmail}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                placeholder="noreply@yourdomain.com"
              />
              <p className="text-xs text-gray-500 mt-1">
                This email address will be used as the sender for all automated messages
              </p>
            </div>

            <div className="flex justify-end pt-4">
              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 px-6 py-2 bg-coral-500 text-white rounded-lg hover:bg-coral-600 transition-colors disabled:opacity-50"
              >
                <Save className="w-5 h-5" />
                {saving ? 'Saving...' : 'Save Settings'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Information Box */}
      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-blue-900 mb-2">About Email Settings</h3>
        <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
          <li>Configure these settings to personalize emails sent to your guests</li>
          <li>Message templates use these settings as the default sender information</li>
          <li>Make sure to use a valid email address that you have access to</li>
        </ul>
      </div>
    </div>
  );
};
