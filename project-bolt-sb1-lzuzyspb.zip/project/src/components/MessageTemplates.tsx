import React, { useState, useEffect } from 'react';
import { Plus, Mail, Clock, Edit, Trash2, Power, PowerOff, Info } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { MessageTemplate } from '../types';
import { TemplateEditorModal } from './TemplateEditorModal';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';
import { useAuth } from '../contexts/AuthContext';

export const MessageTemplates: React.FC = () => {
  const { isGuestMode } = useAuth();
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);
  const [isAnonymous, setIsAnonymous] = useState(false);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      setError(null);
      const { data: { user } } = await supabase.auth.getUser();

      const userId = user?.id || 'anonymous';
      setIsAnonymous(!user);

      const { data, error: fetchError } = await supabase
        .from('message_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Database error:', fetchError);
        throw fetchError;
      }

      const mappedTemplates: MessageTemplate[] = (data || []).map(item => ({
        id: item.id,
        userId: item.user_id,
        name: item.name,
        type: item.type,
        subject: item.subject,
        body: item.body,
        scheduleType: item.schedule_type,
        scheduleValue: item.schedule_value,
        scheduleUnit: item.schedule_unit,
        scheduleEvent: item.schedule_event,
        isActive: item.is_active,
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));

      setTemplates(mappedTemplates);
    } catch (err) {
      console.error('Error loading templates:', err);
      setError('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTemplate = () => {
    setEditingTemplate(null);
    setIsEditorOpen(true);
  };

  const handleEditTemplate = (template: MessageTemplate) => {
    setEditingTemplate(template);
    setIsEditorOpen(true);
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      const { error: deleteError } = await supabase
        .from('message_templates')
        .delete()
        .eq('id', templateId);

      if (deleteError) throw deleteError;

      await loadTemplates();
    } catch (err) {
      console.error('Error deleting template:', err);
      setError('Failed to delete template');
    }
  };

  const handleToggleActive = async (template: MessageTemplate) => {
    try {
      const { error: updateError } = await supabase
        .from('message_templates')
        .update({ is_active: !template.isActive })
        .eq('id', template.id);

      if (updateError) throw updateError;

      await loadTemplates();
    } catch (err) {
      console.error('Error updating template:', err);
      setError('Failed to update template');
    }
  };

  const getTemplateTypeName = (type: MessageTemplate['type']): string => {
    const typeMap: Record<MessageTemplate['type'], string> = {
      booking_confirmation: 'Booking Confirmation',
      booking_cancellation: 'Booking Cancellation',
      check_in_reminder: 'Check-In Reminder',
      check_out_reminder: 'Check-Out Reminder',
      post_checkout: 'Post Check-Out',
      custom: 'Custom'
    };
    return typeMap[type];
  };

  const getScheduleDescription = (template: MessageTemplate): string => {
    if (template.scheduleType === 'immediate') {
      return 'Sent immediately';
    }

    const timing = template.scheduleType === 'before' ? 'before' : 'after';
    const value = template.scheduleValue;
    const unit = template.scheduleUnit;
    const event = template.scheduleEvent.replace('_', ' ');

    return `${value} ${unit} ${timing} ${event}`;
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        {isAnonymous && (
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="text-sm font-semibold text-blue-900 mb-1">Preview Mode</h3>
              <p className="text-sm text-blue-800">
                You're viewing the messaging section in preview mode. Templates created here are for testing purposes only.
                Sign in to save and manage your actual message templates.
              </p>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Message Templates</h1>
            <p className="text-gray-600 mt-2">Configure automated email messages for your guests</p>
          </div>
          {!isGuestMode && (
            <button
              onClick={handleCreateTemplate}
              className="flex items-center gap-2 px-4 py-2 bg-coral-500 text-white rounded-lg hover:bg-coral-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
              New Template
            </button>
          )}
        </div>

        {templates.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
            <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No templates yet</h3>
            <p className="text-gray-600 mb-6">{isGuestMode ? 'No message templates have been created yet' : 'Create your first message template to automate guest communications'}</p>
            {!isGuestMode && (
              <button
                onClick={handleCreateTemplate}
                className="inline-flex items-center gap-2 px-4 py-2 bg-coral-500 text-white rounded-lg hover:bg-coral-600 transition-colors"
              >
                <Plus className="w-5 h-5" />
                Create Template
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {templates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">{template.name}</h3>
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                        {getTemplateTypeName(template.type)}
                      </span>
                      {template.isActive ? (
                        <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full flex items-center gap-1">
                          <Power className="w-3 h-3" />
                          Active
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-full flex items-center gap-1">
                          <PowerOff className="w-3 h-3" />
                          Inactive
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                      <Clock className="w-4 h-4" />
                      <span>{getScheduleDescription(template)}</span>
                    </div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Subject: {template.subject}</p>
                    <p className="text-sm text-gray-600 line-clamp-2">{template.body}</p>
                  </div>
                  {!isGuestMode && (
                    <div className="flex items-center gap-2 ml-4">
                      <button
                        onClick={() => handleToggleActive(template)}
                        className={`p-2 rounded-lg transition-colors ${
                          template.isActive
                            ? 'bg-green-100 text-green-700 hover:bg-green-200'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                        title={template.isActive ? 'Disable template' : 'Enable template'}
                      >
                        {template.isActive ? <Power className="w-5 h-5" /> : <PowerOff className="w-5 h-5" />}
                      </button>
                      <button
                        onClick={() => handleEditTemplate(template)}
                        className="p-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                        title="Edit template"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTemplate(template.id)}
                        className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                        title="Delete template"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {isEditorOpen && (
          <TemplateEditorModal
            template={editingTemplate}
            onClose={() => {
              setIsEditorOpen(false);
              setEditingTemplate(null);
            }}
            onSave={async () => {
              setIsEditorOpen(false);
              setEditingTemplate(null);
              await loadTemplates();
            }}
          />
        )}
      </div>
    </div>
  );
};
