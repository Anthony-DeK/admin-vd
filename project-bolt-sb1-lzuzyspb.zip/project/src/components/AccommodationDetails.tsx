import React, { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, Users, Bed, Bath, DollarSign, Wifi, Car, Coffee, Tv, Wind, Utensils, Calendar, CreditCard as Edit, Star, Pencil, Upload, X, GripVertical, Trash2, Check, MoreVertical, ChevronLeft, ChevronRight, Minus, Plus, FileText, File, BookOpen, Home, ClipboardList, DoorOpen, Banknote, Building2 } from 'lucide-react';
import { Apartment, Booking, CheckInAttachment } from '../types';
import { BookingCalendar } from './BookingCalendar';
import { HouseRulesEditor } from './HouseRulesEditor';
import { HouseRulesDisplay } from './HouseRulesDisplay';
import { AttachmentManager, Attachment } from './AttachmentManager';
import { SectionTile } from './SectionTile';
import { SectionModal } from './SectionModal';
import { supabase } from '../lib/supabase';
import { AMENITY_CATEGORIES } from '../constants/amenities';
import { useAuth } from '../contexts/AuthContext';

interface AccommodationDetailsProps {
  apartment: Apartment;
  bookings: Booking[];
  onBack: () => void;
  onUpdateApartment?: (apartmentId: string, updates: any) => Promise<void>;
  onDeleteApartment?: (apartmentId: string) => Promise<void>;
}

export const AccommodationDetails: React.FC<AccommodationDetailsProps> = ({
  apartment,
  bookings,
  onBack,
  onUpdateApartment,
  onDeleteApartment
}) => {
  const { isGuestMode } = useAuth();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showCalendar, setShowCalendar] = useState(false);
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [openModal, setOpenModal] = useState<string | null>(null);
  const [imageEditMode, setImageEditMode] = useState(false);
  const [images, setImages] = useState(apartment.images || [apartment.coverImage].filter(Boolean));
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isUploadingImages, setIsUploadingImages] = useState(false);
  const [pendingImages, setPendingImages] = useState<string[]>([]);
  const [hasUnsavedImageChanges, setHasUnsavedImageChanges] = useState(false);
  const [showDeleteMenu, setShowDeleteMenu] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Edit form states - initialize with current values or empty strings
  const [editedShortDescription, setEditedShortDescription] = useState(apartment.shortDescription || '');
  const [editedLongDescription, setEditedLongDescription] = useState(apartment.longDescription || '');
  
  // Additional edit form states
  const [editedAmenities, setEditedAmenities] = useState<string[]>(apartment.amenities || []);
  const [editedHouseRules, setEditedHouseRules] = useState<string[]>(apartment.houseRules || []);
  const [editedBasePrice, setEditedBasePrice] = useState(apartment.basePrice?.toString() || '');
  const [editedCleaningFee, setEditedCleaningFee] = useState(apartment.cleaningFee?.toString() || '');
  const [editedServiceFee, setEditedServiceFee] = useState(apartment.serviceFee?.toString() || '');
  const [editedCheckInInstructions, setEditedCheckInInstructions] = useState(apartment.checkInInstructions || '');
  const [editedMinStay, setEditedMinStay] = useState(apartment.minimumStay?.toString() || '1');
  const [editedMaxStay, setEditedMaxStay] = useState(apartment.maximumStay?.toString() || '');
  const [editedPoolOpeningSeason, setEditedPoolOpeningSeason] = useState(apartment.poolOpeningSeason || '');
  const [editedPoolOpeningHours, setEditedPoolOpeningHours] = useState(apartment.poolOpeningHours || '');
  
  // New amenity/rule input states
  const [newAmenity, setNewAmenity] = useState('');
  const [newHouseRule, setNewHouseRule] = useState('');
  
  // Apartment details edit states
  const [editedName, setEditedName] = useState(apartment.name || '');
  const [editedLocation, setEditedLocation] = useState(apartment.location || '');
  const [editedBedrooms, setEditedBedrooms] = useState(apartment.bedrooms || 0);
  const [editedBathrooms, setEditedBathrooms] = useState(apartment.bathrooms || 1);
  const [editedMaxGuests, setEditedMaxGuests] = useState(apartment.maxGuests || 1);
  const [editedIsAvailable, setEditedIsAvailable] = useState(apartment.isAvailable ?? true);

  // Structured house rules states
  const [editedPetsAllowed, setEditedPetsAllowed] = useState(apartment.petsAllowed ?? false);
  const [editedPartiesAllowed, setEditedPartiesAllowed] = useState(apartment.partiesAllowed ?? false);
  const [editedSmokingAllowed, setEditedSmokingAllowed] = useState(apartment.smokingAllowed ?? false);
  const [editedPhotoshootsAllowed, setEditedPhotoshootsAllowed] = useState(apartment.photoshootsAllowed ?? false);
  const [editedQuietHoursStart, setEditedQuietHoursStart] = useState(apartment.quietHoursStart || '');
  const [editedQuietHoursEnd, setEditedQuietHoursEnd] = useState(apartment.quietHoursEnd || '');
  const [editedCheckInTime, setEditedCheckInTime] = useState(apartment.checkInTime || '');
  const [editedCheckOutTime, setEditedCheckOutTime] = useState(apartment.checkOutTime || '');
  const [editedCustomHouseRules, setEditedCustomHouseRules] = useState(apartment.customHouseRules || '');

  // Attachment states
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false);

  // Update form states when apartment prop changes (after successful save)
  useEffect(() => {
    console.log('Apartment prop changed:', {
      name: apartment.name,
      shortDescription: apartment.shortDescription,
      longDescription: apartment.longDescription
    });

    setEditedShortDescription(apartment.shortDescription || '');
    setEditedLongDescription(apartment.longDescription || '');
    setEditedBasePrice(apartment.basePrice?.toString() || '');
    setEditedCleaningFee(apartment.cleaningFee?.toString() || '');
    setEditedServiceFee(apartment.serviceFee?.toString() || '');
    setEditedCheckInInstructions(apartment.checkInInstructions || '');
    setEditedMinStay(apartment.minimumStay?.toString() || '1');
    setEditedMaxStay(apartment.maximumStay?.toString() || '');
    setEditedAmenities(apartment.amenities || []);
    setEditedHouseRules(apartment.houseRules || []);
    setImages(apartment.images || [apartment.coverImage].filter(Boolean));
    setEditedBedrooms(apartment.bedrooms || 0);
    setEditedBathrooms(apartment.bathrooms || 1);
    setEditedMaxGuests(apartment.maxGuests || 1);
    setEditedIsAvailable(apartment.isAvailable ?? true);
    setEditedPetsAllowed(apartment.petsAllowed ?? false);
    setEditedPartiesAllowed(apartment.partiesAllowed ?? false);
    setEditedSmokingAllowed(apartment.smokingAllowed ?? false);
    setEditedPhotoshootsAllowed(apartment.photoshootsAllowed ?? false);
    setEditedQuietHoursStart(apartment.quietHoursStart || '');
    setEditedQuietHoursEnd(apartment.quietHoursEnd || '');
    setEditedCheckInTime(apartment.checkInTime || '');
    setEditedCheckOutTime(apartment.checkOutTime || '');
    setEditedCustomHouseRules(apartment.customHouseRules || '');
    setEditedPoolOpeningSeason(apartment.poolOpeningSeason || '');
    setEditedPoolOpeningHours(apartment.poolOpeningHours || '');
  }, [
    apartment.shortDescription,
    apartment.longDescription,
    apartment.basePrice,
    apartment.cleaningFee,
    apartment.serviceFee,
    apartment.checkInInstructions,
    apartment.minimumStay,
    apartment.maximumStay,
    apartment.amenities,
    apartment.houseRules,
    apartment.images,
    apartment.coverImage,
    apartment.bedrooms,
    apartment.bathrooms,
    apartment.maxGuests,
    apartment.isAvailable,
    apartment.petsAllowed,
    apartment.partiesAllowed,
    apartment.smokingAllowed,
    apartment.photoshootsAllowed,
    apartment.quietHoursStart,
    apartment.quietHoursEnd,
    apartment.checkInTime,
    apartment.checkOutTime,
    apartment.customHouseRules
  ]);

  // Fetch attachments when apartment changes
  useEffect(() => {
    fetchAttachments();
  }, [apartment.id]);

  // Reset pending images when apartment changes or when exiting edit mode
  useEffect(() => {
    if (!imageEditMode) {
      setPendingImages([]);
      setHasUnsavedImageChanges(false);
    }
  }, [imageEditMode]);

  const apartmentBookings = bookings.filter(booking => booking.apartment === apartment.name);

  const getTypeLabel = (type: string) => {
    const typeLabels = {
      studio: 'Studio',
      '1bed': '1 Bedroom',
      '2bed': '2 Bedrooms',
      '3bed': '3+ Bedrooms'
    };
    return typeLabels[type as keyof typeof typeLabels] || type;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const getAmenityIcon = (amenity: string) => {
    const amenityIcons: { [key: string]: React.ComponentType<any> } = {
      'WiFi': Wifi,
      'Air Conditioning': Wind,
      'Kitchen': Utensils,
      'TV': Tv,
      'Parking': Car,
      'Coffee': Coffee,
    };
    
    const IconComponent = amenityIcons[amenity];
    return IconComponent ? <IconComponent className="w-4 h-4" /> : <Star className="w-4 h-4" />;
  };

  const handleSaveDescription = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);
      
      console.log('Saving description updates:', {
        shortDescription: editedShortDescription,
        longDescription: editedLongDescription
      });
      
      await onUpdateApartment(apartment.id, {
        shortDescription: editedShortDescription,
        longDescription: editedLongDescription,
        basePrice: parseFloat(editedBasePrice) || 0,
        cleaningFee: parseFloat(editedCleaningFee) || 0,
        serviceFee: parseFloat(editedServiceFee) || 0,
        checkInInstructions: editedCheckInInstructions,
        minimumStay: parseInt(editedMinStay) || 1,
        maximumStay: editedMaxStay ? parseInt(editedMaxStay) : null
      });
      
      setEditingSection(null);
    } catch (error) {
      console.error('Failed to save description:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSaveAmenities = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);

      await onUpdateApartment(apartment.id, {
        amenities: editedAmenities,
        poolOpeningSeason: editedPoolOpeningSeason,
        poolOpeningHours: editedPoolOpeningHours
      });

      setEditingSection(null);
    } catch (error) {
      console.error('Failed to save amenities:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSaveHouseRules = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);

      await onUpdateApartment(apartment.id, {
        petsAllowed: editedPetsAllowed,
        partiesAllowed: editedPartiesAllowed,
        smokingAllowed: editedSmokingAllowed,
        photoshootsAllowed: editedPhotoshootsAllowed,
        quietHoursStart: editedQuietHoursStart || undefined,
        quietHoursEnd: editedQuietHoursEnd || undefined,
        checkInTime: editedCheckInTime || undefined,
        checkOutTime: editedCheckOutTime || undefined,
        customHouseRules: editedCustomHouseRules || undefined,
        maxGuests: editedMaxGuests
      });

      setEditingSection(null);
    } catch (error: any) {
      console.error('Failed to save house rules:', error);
      const errorMessage = error?.message || 'Unknown error occurred';
      alert(`Failed to save changes: ${errorMessage}\n\nIf you see a column error, you need to run the SQL migration in Supabase. Check SETUP_HOUSE_RULES.sql in the project root.`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSavePricing = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);
      
      await onUpdateApartment(apartment.id, {
        basePrice: parseFloat(editedBasePrice) || 0,
        cleaningFee: parseFloat(editedCleaningFee) || 0,
        serviceFee: parseFloat(editedServiceFee) || 0,
        minimumStay: parseInt(editedMinStay) || 1,
        maximumStay: editedMaxStay ? parseInt(editedMaxStay) : null,
      });
      
      setEditingSection(null);
    } catch (error) {
      console.error('Failed to save pricing:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSaveCheckInInstructions = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);
      
      await onUpdateApartment(apartment.id, {
        checkInInstructions: editedCheckInInstructions
      });
      
      setEditingSection(null);
    } catch (error) {
      console.error('Failed to save check-in instructions:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleCancelEdit = () => {
    // Reset to original values from the apartment prop
    setEditedShortDescription(apartment.shortDescription || '');
    setEditedLongDescription(apartment.longDescription || '');
    setEditedBasePrice(apartment.basePrice?.toString() || '');
    setEditedCleaningFee(apartment.cleaningFee?.toString() || '');
    setEditedServiceFee(apartment.serviceFee?.toString() || '');
    setEditedMinStay(apartment.minimumStay?.toString() || '1');
    setEditedMaxStay(apartment.maximumStay?.toString() || '');
    setEditedAmenities(apartment.amenities || []);
    setEditedHouseRules(apartment.houseRules || []);
    setNewAmenity('');
    setNewHouseRule('');

    // Reset structured house rules
    setEditedPetsAllowed(apartment.petsAllowed ?? false);
    setEditedPartiesAllowed(apartment.partiesAllowed ?? false);
    setEditedSmokingAllowed(apartment.smokingAllowed ?? false);
    setEditedPhotoshootsAllowed(apartment.photoshootsAllowed ?? false);
    setEditedQuietHoursStart(apartment.quietHoursStart || '');
    setEditedQuietHoursEnd(apartment.quietHoursEnd || '');
    setEditedCheckInTime(apartment.checkInTime || '');
    setEditedCheckOutTime(apartment.checkOutTime || '');
    setEditedCustomHouseRules(apartment.customHouseRules || '');
    setEditedCheckInInstructions(apartment.checkInInstructions || '');
    setEditedPoolOpeningSeason(apartment.poolOpeningSeason || '');
    setEditedPoolOpeningHours(apartment.poolOpeningHours || '');

    setEditingSection(null);
  };

  // Fetch attachments
  const fetchAttachments = async () => {
    try {
      const { data, error } = await supabase
        .from('check_in_attachments')
        .select('*')
        .eq('apartment_id', apartment.id)
        .order('display_order', { ascending: true });

      if (error) throw error;

      const formattedAttachments: Attachment[] = (data || []).map(att => ({
        id: att.id,
        fileName: att.file_name,
        fileUrl: att.file_url,
        fileType: att.file_type || undefined,
        fileSize: att.file_size || undefined,
        displayOrder: att.display_order || 0,
        storagePath: att.storage_path
      }));

      setAttachments(formattedAttachments);
    } catch (error) {
      console.error('Error fetching attachments:', error);
    }
  };

  // Convert file to data URL
  const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Upload attachments
  const handleUploadAttachments = async (files: FileList) => {
    setIsUploadingAttachment(true);
    try {
      const fileArray = Array.from(files);
      const currentMaxOrder = attachments.length > 0
        ? Math.max(...attachments.map(a => a.displayOrder))
        : -1;

      for (let i = 0; i < fileArray.length; i++) {
        const file = fileArray[i];

        // Generate unique file name
        const timestamp = Date.now();
        const randomString = Math.random().toString(36).substring(2, 15);
        const fileExtension = file.name.split('.').pop();
        const uniqueFileName = `${apartment.id}/${timestamp}_${randomString}.${fileExtension}`;

        // Upload to Supabase Storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('apartments')
          .upload(uniqueFileName, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          throw uploadError;
        }

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('apartments')
          .getPublicUrl(uniqueFileName);

        // Insert into database
        const { error } = await supabase
          .from('check_in_attachments')
          .insert({
            apartment_id: apartment.id,
            file_name: file.name,
            file_url: publicUrl,
            file_type: file.type,
            file_size: file.size,
            display_order: currentMaxOrder + i + 1,
            storage_path: uniqueFileName
          });

        if (error) throw error;
      }

      // Refresh attachments list
      await fetchAttachments();
    } catch (error) {
      console.error('Error uploading attachments:', error);
      alert('Failed to upload attachments. Please try again.');
    } finally {
      setIsUploadingAttachment(false);
    }
  };

  // Delete attachment
  const handleDeleteAttachment = async (attachmentId: string) => {
    try {
      // Get the attachment to find the storage path
      const attachment = attachments.find(a => a.id === attachmentId);

      // Delete from database
      const { error } = await supabase
        .from('check_in_attachments')
        .delete()
        .eq('id', attachmentId);

      if (error) throw error;

      // Delete from storage if storage_path exists
      if (attachment && 'storagePath' in attachment) {
        const storagePath = (attachment as any).storagePath;
        if (storagePath) {
          await supabase.storage
            .from('apartments')
            .remove([storagePath]);
        }
      }

      // Refresh attachments list
      await fetchAttachments();
    } catch (error) {
      console.error('Error deleting attachment:', error);
      alert('Failed to delete attachment. Please try again.');
    }
  };

  const handleAddAmenity = () => {
    if (newAmenity.trim()) {
      setEditedAmenities([...editedAmenities, newAmenity.trim()]);
      setNewAmenity('');
    }
  };

  const handleRemoveAmenity = (index: number) => {
    setEditedAmenities(editedAmenities.filter((_, i) => i !== index));
  };

  const handleAddHouseRule = () => {
    if (newHouseRule.trim()) {
      setEditedHouseRules([...editedHouseRules, newHouseRule.trim()]);
      setNewHouseRule('');
    }
  };

  const handleRemoveHouseRule = (index: number) => {
    setEditedHouseRules(editedHouseRules.filter((_, i) => i !== index));
  };

  const handleSaveApartmentDetails = async () => {
    if (!onUpdateApartment) {
      console.warn('onUpdateApartment function not provided');
      setEditingSection(null);
      return;
    }

    try {
      setIsUpdating(true);

      // Determine apartment type based on bedrooms
      let apartmentType: 'studio' | '1bed' | '2bed' | '3bed' = 'studio';
      if (editedBedrooms === 0) apartmentType = 'studio';
      else if (editedBedrooms === 1) apartmentType = '1bed';
      else if (editedBedrooms === 2) apartmentType = '2bed';
      else if (editedBedrooms >= 3) apartmentType = '3bed';

      console.log('Saving apartment details updates:', {
        name: editedName,
        location: editedLocation,
        bedrooms: editedBedrooms,
        bathrooms: editedBathrooms,
        maxGuests: editedMaxGuests,
        isAvailable: editedIsAvailable,
        type: apartmentType
      });

      // Update the apartments table directly
      const { error } = await supabase
        .from('apartments')
        .update({
          name: editedName,
          location: editedLocation,
          bedrooms: editedBedrooms,
          bathrooms: editedBathrooms,
          max_guests: editedMaxGuests,
          is_available: editedIsAvailable,
          type: apartmentType
        })
        .eq('id', apartment.id);

      if (error) {
        console.error('Error updating apartment:', error);
        throw error;
      }
      
      // Refresh apartment data
      if (onUpdateApartment) {
        await onUpdateApartment(apartment.id, {});
      }
      
      setEditingSection(null);
    } catch (error) {
      console.error('Failed to save apartment details:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleCancelApartmentDetailsEdit = () => {
    // Reset to original values from the apartment prop
    setEditedName(apartment.name || '');
    setEditedLocation(apartment.location || '');
    setEditedBedrooms(apartment.bedrooms || 0);
    setEditedBathrooms(apartment.bathrooms || 1);
    setEditedMaxGuests(apartment.maxGuests || 1);
    setEditedIsAvailable(apartment.isAvailable ?? true);
    setEditingSection(null);
  };

  const handleDeleteApartment = async () => {
    if (!onDeleteApartment) {
      console.warn('onDeleteApartment function not provided');
      return;
    }

    try {
      setIsDeleting(true);
      
      // Delete all related data from the database
      console.log('Deleting apartment and all related data:', apartment.id);
      
      // Delete apartment images from storage and database
      const { data: imageData } = await supabase
        .from('apartment_images')
        .select('storage_path')
        .eq('apartment_id', apartment.id);

      if (imageData && imageData.length > 0) {
        // Delete from storage
        const storagePaths = imageData
          .map(img => img.storage_path)
          .filter(Boolean);
        
        if (storagePaths.length > 0) {
          await supabase.storage
            .from('apartments')
            .remove(storagePaths);
        }
      }

      // Delete from apartment_images table
      await supabase
        .from('apartment_images')
        .delete()
        .eq('apartment_id', apartment.id);

      // Delete from apartment_details table
      await supabase
        .from('apartment_details')
        .delete()
        .eq('apartment_id', apartment.id);

      // Delete from bookings table
      await supabase
        .from('bookings')
        .delete()
        .eq('apartment_id', apartment.id);

      // Delete from date_specific_pricing table
      await supabase
        .from('date_specific_pricing')
        .delete()
        .eq('apartment_id', apartment.id);

      // Delete from date_specific_availability table
      await supabase
        .from('date_specific_availability')
        .delete()
        .eq('apartment_id', apartment.id);

      // Delete from reviews table
      await supabase
        .from('reviews')
        .delete()
        .eq('apartment_id', apartment.id);

      // Finally, delete the apartment itself
      await supabase
        .from('apartments')
        .delete()
        .eq('id', apartment.id);

      // Call the parent callback to handle the deletion
      await onDeleteApartment(apartment.id);
      
      // Navigate back to accommodations list
      onBack();
      
    } catch (error) {
      console.error('Failed to delete apartment:', error);
      alert('Failed to delete accommodation. Please try again.');
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setShowDeleteMenu(false);
    }
  };

  const handleSaveImages = async () => {
    if (!hasUnsavedImageChanges) {
      setImageEditMode(false);
      return;
    }

    try {
      setIsUpdating(true);
      
      // The images are already uploaded to storage and database during handleImageUpload
      // We just need to refresh the apartment data and exit edit mode
      if (onUpdateApartment) {
        await onUpdateApartment(apartment.id, {});
      }
      
      setImageEditMode(false);
      setPendingImages([]);
      setHasUnsavedImageChanges(false);
    } catch (error) {
      console.error('Failed to save image changes:', error);
      alert('Failed to save image changes. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleCancelImageEdit = () => {
    // Reset to original images from apartment prop
    setImages(apartment.images || [apartment.coverImage].filter(Boolean));
    setActiveImageIndex(0);
    setImageEditMode(false);
    setPendingImages([]);
    setHasUnsavedImageChanges(false);
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    // Check current image count and validate total doesn't exceed 12
    const currentImageCount = images.length;
    const newImageCount = files.length;
    const totalImages = currentImageCount + newImageCount;
    
    if (totalImages > 12) {
      alert(`You can only have a maximum of 12 images. You currently have ${currentImageCount} images. You can add ${12 - currentImageCount} more.`);
      return;
    }

    // Validate file types and convert to array
    const validFiles: File[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type === 'image/jpeg' || file.type === 'image/jpg') {
        validFiles.push(file);
      } else {
        alert(`File "${file.name}" is not a valid JPEG image. Only JPG and JPEG formats are allowed.`);
        return;
      }
    }

    if (validFiles.length === 0) return;

    // Sort files alphanumerically by filename
    validFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));

    try {
      setIsUploadingImages(true);

      // Upload files to Supabase Storage and save to database
      const uploadedImages: string[] = [];
      const newImages = [...images]; // Start with current images
      
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${apartment.id}/${Date.now()}-${i}-${file.name}`;

        // Upload to Supabase Storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('apartments')
          .upload(fileName, file);

        if (uploadError) {
          console.error('Error uploading file:', uploadError);
          throw uploadError;
        }

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('apartments')
          .getPublicUrl(fileName);

        uploadedImages.push(publicUrl);

        // Save to apartment_images table with correct display order
        const { error: dbError } = await supabase
          .from('apartment_images')
          .insert({
            apartment_id: apartment.id,
            image_url: publicUrl,
            storage_path: fileName,
            is_primary: newImages.length === 0 && i === 0, // Only first image of first batch is primary if no existing images
            display_order: newImages.length + i,
            alt_text: `${apartment.name} - Image ${i + 1}`,
            image_type: 'general'
          });

        if (dbError) {
          console.error('Error saving image to database:', dbError);
          throw dbError;
        }
        
        // Add to current images array
        newImages.push(publicUrl);
      }

      // Update local state
      setImages(newImages);
      setPendingImages(prev => [...prev, ...uploadedImages]);
      setHasUnsavedImageChanges(true);
      
      // Don't exit edit mode, keep it active
      // Don't show success alert
      // Don't refresh apartment data automatically
      
    } catch (error) {
      console.error('Error uploading images:', error);
      alert('Failed to upload images. Please try again.');
    } finally {
      setIsUploadingImages(false);
      // Reset the input
      event.target.value = '';
    }
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.preventDefault = () => {}; // Prevent default preventDefault
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
    
    // Create a custom drag image from the actual image element
    const imageElement = e.currentTarget.querySelector('img') as HTMLImageElement;
    if (imageElement) {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 100;
      canvas.height = 100;
      
      if (ctx) {
        ctx.globalAlpha = 0.8;
        ctx.drawImage(imageElement, 0, 0, 100, 100);
        
        const dragImage = new Image();
        dragImage.src = canvas.toDataURL();
        e.dataTransfer.setDragImage(dragImage, 50, 50);
      }
    }
  };

  const handleDragEnd = (e: React.DragEvent) => {
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDragEnter = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex !== null && draggedIndex !== index) {
      setDragOverIndex(index);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    
    // Only clear if we're actually leaving the element
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;
    
    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
      setDragOverIndex(null);
    }
  };

  const handleDrop = async (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    
    if (draggedIndex === null || draggedIndex === dropIndex) {
      setDraggedIndex(null);
      setDragOverIndex(null);
      return;
    }

    const newImages = [...images];
    const draggedImage = newImages[draggedIndex];
    
    // Remove the dragged image
    newImages.splice(draggedIndex, 1);
    
    // Insert at the new position
    const actualDropIndex = draggedIndex < dropIndex ? dropIndex - 1 : dropIndex;
    newImages.splice(actualDropIndex, 0, draggedImage);
    
    setImages(newImages);
    
    // Update active image index if needed
    if (activeImageIndex === draggedIndex) {
      setActiveImageIndex(actualDropIndex);
    } else if (draggedIndex < activeImageIndex && actualDropIndex >= activeImageIndex) {
      setActiveImageIndex(activeImageIndex - 1);
    } else if (draggedIndex > activeImageIndex && actualDropIndex <= activeImageIndex) {
      setActiveImageIndex(activeImageIndex + 1);
    }

    // Update display order in database
    try {
      for (let i = 0; i < newImages.length; i++) {
        await supabase
          .from('apartment_images')
          .update({ 
            display_order: i,
            is_primary: i === 0 // First image is always primary
          })
          .eq('apartment_id', apartment.id)
          .eq('image_url', newImages[i]);
      }
    } catch (error) {
      console.error('Error updating image order:', error);
    }

    // Reset drag state
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const handleDeleteImage = async (index: number) => {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
      const imageUrl = images[index];
      
      // Delete from database
      const { error: dbError } = await supabase
        .from('apartment_images')
        .delete()
        .eq('apartment_id', apartment.id)
        .eq('image_url', imageUrl);

      if (dbError) {
        console.error('Error deleting image from database:', dbError);
        throw dbError;
      }

      // Get storage path to delete from storage
      const { data: imageData } = await supabase
        .from('apartment_images')
        .select('storage_path')
        .eq('image_url', imageUrl)
        .single();

      if (imageData?.storage_path) {
        await supabase.storage
          .from('apartments')
          .remove([imageData.storage_path]);
      }

      // Update local state
      const newImages = images.filter((_, i) => i !== index);
      setImages(newImages);
      
      // Adjust active image index
      if (activeImageIndex >= newImages.length) {
        setActiveImageIndex(Math.max(0, newImages.length - 1));
      } else if (activeImageIndex > index) {
        setActiveImageIndex(activeImageIndex - 1);
      }

      // Update display order for remaining images
      for (let i = 0; i < newImages.length; i++) {
        await supabase
          .from('apartment_images')
          .update({ 
            display_order: i,
            is_primary: i === 0
          })
          .eq('apartment_id', apartment.id)
          .eq('image_url', newImages[i]);
      }

    } catch (error) {
      console.error('Error deleting image:', error);
      alert('Failed to delete image. Please try again.');
    }
  };

  const handleSetCover = async (index: number) => {
    if (index === 0) return; // Already cover image
    
    const newImages = [...images];
    const coverImage = newImages[index];
    
    // Remove from current position
    newImages.splice(index, 1);
    // Add to beginning
    newImages.unshift(coverImage);
    
    setImages(newImages);
    setActiveImageIndex(0);

    // Update database
    try {
      for (let i = 0; i < newImages.length; i++) {
        await supabase
          .from('apartment_images')
          .update({ 
            display_order: i,
            is_primary: i === 0
          })
          .eq('apartment_id', apartment.id)
          .eq('image_url', newImages[i]);
      }
    } catch (error) {
      console.error('Error updating cover image:', error);
    }
  };

  const ImageCarousel: React.FC = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const thumbnailWidth = 96; // Fixed width for each thumbnail
    const gap = 8; // Gap between thumbnails
    const [containerWidth, setContainerWidth] = useState(0);
    const containerRef = React.useRef<HTMLDivElement>(null);

    React.useEffect(() => {
      const updateWidth = () => {
        if (containerRef.current) {
          setContainerWidth(containerRef.current.offsetWidth);
        }
      };
      updateWidth();
      window.addEventListener('resize', updateWidth);
      return () => window.removeEventListener('resize', updateWidth);
    }, []);

    const imagesPerSlide = Math.max(1, Math.floor((containerWidth + gap) / (thumbnailWidth + gap)));
    const totalSlides = Math.ceil(images.length / imagesPerSlide);

    const nextSlide = () => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    };

    const prevSlide = () => {
      setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
    };

    const goToSlide = (slideIndex: number) => {
      setCurrentSlide(slideIndex);
    };

    if (images.length <= 1) return null;

    return (
      <div className="mt-4">
        <div className="relative" ref={containerRef}>
          {/* Carousel Container */}
          <div className="overflow-hidden rounded-lg">
            <div
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {Array.from({ length: totalSlides }).map((_, slideIndex) => (
                <div key={slideIndex} className="w-full flex-shrink-0">
                  <div className="flex gap-2 justify-center">
                    {images
                      .slice(slideIndex * imagesPerSlide, (slideIndex + 1) * imagesPerSlide)
                      .map((image, imageIndex) => {
                        const globalIndex = slideIndex * imagesPerSlide + imageIndex;
                        return (
                          <button
                            key={globalIndex}
                            onClick={() => setActiveImageIndex(globalIndex)}
                            className={`relative flex-shrink-0 bg-gray-200 rounded-lg overflow-hidden transition-all ${
                              activeImageIndex === globalIndex
                                ? 'ring-2 ring-coral-500 scale-105'
                                : 'hover:ring-2 hover:ring-gray-300'
                            }`}
                            style={{ width: `${thumbnailWidth}px`, height: `${thumbnailWidth}px` }}
                          >
                            <img
                              src={image}
                              alt={`${apartment.name} ${globalIndex + 1}`}
                              className="w-full h-full object-cover"
                            />
                            {globalIndex === 0 && (
                              <div className="absolute top-1 right-1 bg-coral-500 text-white px-1 py-0.5 rounded text-xs font-medium">
                                Cover
                              </div>
                            )}
                          </button>
                        );
                      })}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Navigation Arrows */}
          {totalSlides > 1 && (
            <>
              <button
                onClick={prevSlide}
                className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-2 shadow-md transition-all"
              >
                <ChevronLeft className="w-4 h-4 text-gray-600" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full p-2 shadow-md transition-all"
              >
                <ChevronRight className="w-4 h-4 text-gray-600" />
              </button>
            </>
          )}
        </div>
        
        {/* Slide Indicators */}
        {totalSlides > 1 && (
          <div className="flex justify-center mt-3 space-x-2">
            {Array.from({ length: totalSlides }).map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  currentSlide === index ? 'bg-coral-500' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        )}
        
        {/* Image Counter */}
        <div className="text-center mt-2">
          <span className="text-sm text-gray-500">
            {images.length} of 12 images
          </span>
        </div>
      </div>
    );
  };

  const EditButton: React.FC<{ section: string; className?: string }> = ({ section, className = "" }) => {
    if (isGuestMode) return null;

    return (
      <button
        onClick={() => {
          console.log('Edit button clicked for section:', section);
          console.log('House rules data before edit:', {
            petsAllowed: editedPetsAllowed,
            partiesAllowed: editedPartiesAllowed,
            smokingAllowed: editedSmokingAllowed,
            photoshootsAllowed: editedPhotoshootsAllowed,
            quietHoursStart: editedQuietHoursStart,
            quietHoursEnd: editedQuietHoursEnd,
            checkInTime: editedCheckInTime,
            checkOutTime: editedCheckOutTime,
            customHouseRules: editedCustomHouseRules,
            maxGuests: editedMaxGuests
          });
          setEditingSection(section);
        }}
        className={`p-1.5 text-gray-400 hover:text-coral-600 hover:bg-gray-100 rounded-md transition-colors ${className}`}
        title={`Edit ${section}`}
      >
        <Pencil className="w-3.5 h-3.5" />
      </button>
    );
  };

  const CounterInput: React.FC<{
    label: string;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
  }> = ({ label, value, onChange, min = 0, max = 20 }) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label}
      </label>
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => onChange(Math.max(min, value - 1))}
          disabled={value <= min}
          className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          -
        </button>
        <span className="w-12 text-center font-medium text-gray-900">
          {value}
        </span>
        <button
          type="button"
          onClick={() => onChange(Math.min(max, value + 1))}
          disabled={value >= max}
          className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          +
        </button>
      </div>
    </div>
  );

  const ImageManagement: React.FC = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {images.map((image, index) => (
          <div 
            key={`${image}-${index}`}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragEnd={handleDragEnd}
            onDragOver={handleDragOver}
            onDragEnter={(e) => handleDragEnter(e, index)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, index)}
            className={`relative group bg-gray-100 rounded-lg overflow-hidden aspect-square transition-all duration-200 ${
              draggedIndex === index ? 'opacity-50 scale-95' : ''
            } ${
              dragOverIndex === index && draggedIndex !== index ? 'ring-2 ring-coral-500 scale-105' : ''
            } cursor-move`}
          >
            {/* Drag handle indicator */}
            <div
              className="absolute top-2 left-2 z-10 p-1.5 bg-white bg-opacity-90 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-sm pointer-events-none"
              title="Drag to reorder"
            >
              <GripVertical className="w-4 h-4 text-gray-600" />
            </div>

            <img
              src={image}
              alt={`${apartment.name} ${index + 1}`}
              className="w-full h-full object-cover"
              draggable={false}
            />
            
            {/* Controls overlay */}
            <div 
              className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-200 flex items-center justify-center"
              onMouseDown={(e) => e.stopPropagation()} // Prevent drag when clicking buttons
            >
              <div className="opacity-0 group-hover:opacity-100 flex items-center gap-2">
                {index !== 0 && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      handleSetCover(index);
                    }}
                    className="p-2 bg-white rounded-full text-gray-600 hover:text-coral-600 transition-colors"
                    title="Set as cover"
                  >
                    <Star className="w-4 h-4" />
                  </button>
                )}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    handleDeleteImage(index);
                  }}
                  className="p-2 bg-white rounded-full text-gray-600 hover:text-red-600 transition-colors"
                  title="Delete image"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            {index === 0 && (
              <div className="absolute top-2 right-2 bg-coral-500 text-white px-2 py-1 rounded text-xs font-medium">
                Cover
              </div>
            )}
            
            {/* Drop indicator */}
            {dragOverIndex === index && draggedIndex !== index && (
              <div className="absolute inset-0 border-2 border-dashed border-coral-500 bg-coral-50 bg-opacity-75 rounded-lg flex items-center justify-center z-20">
                <div className="text-coral-600 font-medium text-sm bg-white px-3 py-1 rounded-full shadow-sm">
                  Drop here
                </div>
              </div>
            )}
          </div>
        ))}
        
        {/* Add new image placeholder */}
        {images.length < 12 && (
          <div className="border-2 border-dashed border-gray-300 rounded-lg aspect-square flex items-center justify-center hover:border-coral-500 hover:bg-coral-50 transition-colors cursor-pointer relative">
            <input
              type="file"
              multiple
              accept=".jpg,.jpeg"
              onChange={handleImageUpload}
              disabled={isUploadingImages}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
            />
            <div className="text-center pointer-events-none">
              {isUploadingImages ? (
                <>
                  <div className="w-8 h-8 border-2 border-coral-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  <span className="text-sm text-coral-600">Uploading...</span>
                </>
              ) : (
                <>
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <span className="text-sm text-gray-500">Add Images</span>
                  <span className="text-xs text-gray-400 block mt-1">
                    JPG/JPEG only ({12 - images.length} slots left)
                  </span>
                </>
              )}
            </div>
          </div>
        )}
      </div>
      
      {/* Image limit warning */}
      {images.length >= 10 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <p className="text-sm text-yellow-800">
            {images.length === 12 
              ? 'Maximum of 12 images reached. Delete some images to add new ones.'
              : `You have ${images.length} images. You can add ${12 - images.length} more.`
            }
          </p>
        </div>
      )}
    </div>
  );

  // Debug logging
  console.log('AccommodationDetails render:', {
    apartmentName: apartment.name,
    shortDescription: apartment.shortDescription,
    longDescription: apartment.longDescription,
    editedShortDescription,
    editedLongDescription
  });

  return showCalendar ? (
    <div className="max-w-3xl mx-auto">
      {/* Property Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 min-w-0 flex-1">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl font-bold text-gray-900 truncate">{apartment.name}</h1>
              {apartment.location && (
                <div className="flex items-center gap-1 text-gray-600 mt-1 min-w-0">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate text-sm sm:text-base">{apartment.location}</span>
                </div>
              )}
            </div>
          </div>
          {!isGuestMode && (
            <div className="relative flex-shrink-0 ml-4">
              <button
                onClick={() => setShowDeleteMenu(!showDeleteMenu)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title="More options"
              >
                <MoreVertical className="w-5 h-5 text-gray-600" />
              </button>

              {showDeleteMenu && (
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                <button
                  onClick={() => {
                    setShowDeleteMenu(false);
                    setShowDeleteConfirm(true);
                  }}
                  disabled={isUpdating}
                  className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete Accommodation
                </button>
              </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Calendar */}
      <BookingCalendar
        bookings={apartmentBookings}
        apartmentId={apartment.id}
        basePrice={apartment.basePrice || 0}
        baseMinStay={apartment.minimumStay || 1}
      />
    </div>
  ) : (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 min-w-0 flex-1">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl font-bold text-gray-900 truncate">{apartment.name}</h1>
              {apartment.location && (
                <div className="flex items-center gap-1 text-gray-600 mt-1 min-w-0">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate text-sm sm:text-base">{apartment.location}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3 flex-shrink-0 ml-4">
            <button
              onClick={() => setShowCalendar(!showCalendar)}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg flex items-center gap-2 transition-colors text-sm"
            >
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">{showCalendar ? 'Hide Calendar' : 'View Calendar'}</span>
              <span className="sm:hidden">{showCalendar ? 'Hide' : 'Calendar'}</span>
            </button>

            {/* More Options Menu */}
            <div className="relative">
              <button
                onClick={() => setShowDeleteMenu(!showDeleteMenu)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title="More options"
              >
                <MoreVertical className="w-5 h-5 text-gray-600" />
              </button>

              {showDeleteMenu && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                  <button
                    onClick={() => {
                      setShowDeleteMenu(false);
                      setShowDeleteConfirm(true);
                    }}
                    disabled={isUpdating}
                    className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete Accommodation
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        {(
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Images */}
            <div className="lg:col-span-3">
              <div className="space-y-6">
                {/* Images Section */}
                <div className="group relative">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900">Photos</h2>
                    <div className="flex items-center gap-2">
                      {!isGuestMode && (
                        <button
                          onClick={() => setImageEditMode(!imageEditMode)}
                          className="p-1.5 text-gray-400 hover:text-coral-600 hover:bg-gray-100 rounded-md transition-colors"
                          title="Manage images"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {imageEditMode ? (
                    <div className="space-y-4">
                      <ImageManagement />
                      
                      {/* Save/Cancel Buttons */}
                      <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
                        <button
                          onClick={handleSaveImages}
                          disabled={isUpdating}
                          className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
                        >
                          {isUpdating ? (
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          ) : (
                            <Check className="w-4 h-4" />
                          )}
                          {isUpdating ? 'Saving...' : 'Save Changes'}
                        </button>
                        <button
                          onClick={handleCancelImageEdit}
                          disabled={isUpdating}
                          className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Main Image */}
                      <div className="relative h-96 bg-gray-200 rounded-lg overflow-hidden">
                        {images.length > 0 ? (
                          <img
                            src={images[activeImageIndex]}
                            alt={apartment.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-400">
                            <Bed className="w-16 h-16" />
                          </div>
                        )}
                      </div>

                      {/* Image Thumbnails */}
                      <ImageCarousel />
                    </>
                  )}
                </div>

                {/* Section Tiles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <SectionTile
                    title="Property Details"
                    icon={Building2}
                    onClick={() => setOpenModal('property-details')}
                    hasContent={true}
                  />
                  <SectionTile
                    title="About this place"
                    icon={BookOpen}
                    onClick={() => setOpenModal('description')}
                    hasContent={!!(apartment.shortDescription || apartment.longDescription)}
                  />
                  <SectionTile
                    title="Amenities"
                    icon={Home}
                    onClick={() => setOpenModal('amenities')}
                    hasContent={!!(apartment.amenities && apartment.amenities.length > 0)}
                  />
                  <SectionTile
                    title="House Rules"
                    icon={ClipboardList}
                    onClick={() => setOpenModal('house-rules')}
                    hasContent={!!(
                      apartment.petsAllowed !== undefined ||
                      apartment.partiesAllowed !== undefined ||
                      apartment.smokingAllowed !== undefined ||
                      apartment.photoshootsAllowed !== undefined ||
                      apartment.quietHoursStart ||
                      apartment.quietHoursEnd ||
                      apartment.checkInTime ||
                      apartment.checkOutTime ||
                      apartment.customHouseRules ||
                      apartment.maxGuests
                    )}
                  />
                  <SectionTile
                    title="Base Price & Duration"
                    icon={Banknote}
                    onClick={() => setOpenModal('pricing')}
                    hasContent={!!(apartment.basePrice)}
                  />
                  <SectionTile
                    title="Check-in Instructions"
                    icon={DoorOpen}
                    onClick={() => setOpenModal('checkin')}
                    hasContent={!!(apartment.checkInInstructions || attachments.length > 0)}
                  />
                </div>

              </div>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Trash2 className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Delete Accommodation</h3>
                  <p className="text-sm text-gray-600">This action cannot be undone</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-6">
                Are you sure you want to permanently delete <strong>"{apartment.name}"</strong>? 
                This will remove all associated data including bookings, images, and reviews.
              </p>
              
              <div className="flex items-center justify-end gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  disabled={isDeleting}
                  className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteApartment}
                  disabled={isDeleting}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
                >
                  {isDeleting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Deleting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4" />
                      Delete Permanently
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <SectionModal
        isOpen={openModal === 'description'}
        onClose={() => setOpenModal(null)}
        title="About this place"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSaveDescription();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="shortDescription" className="block text-sm font-medium text-gray-700 mb-2">
              Short Description
            </label>
            <input
              type="text"
              id="shortDescription"
              value={editedShortDescription}
              onChange={(e) => setEditedShortDescription(e.target.value)}
              placeholder="Brief description of the property..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>

          <div>
            <label htmlFor="longDescription" className="block text-sm font-medium text-gray-700 mb-2">
              Detailed Description
            </label>
            <textarea
              id="longDescription"
              value={editedLongDescription}
              onChange={(e) => setEditedLongDescription(e.target.value)}
              placeholder="Detailed description of the property, amenities, location, and what makes it special..."
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
        </div>
      </SectionModal>

      <SectionModal
        isOpen={openModal === 'amenities'}
        onClose={() => setOpenModal(null)}
        title="Amenities"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSaveAmenities();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <div className="space-y-6">
          {AMENITY_CATEGORIES.map((category) => (
            <div key={category.name}>
              <h3 className="text-sm font-semibold text-gray-900 mb-3">{category.name}</h3>
              <div className="grid grid-cols-1 gap-2">
                {category.amenities.map((amenity) => (
                  <label key={amenity} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                    <input
                      type="checkbox"
                      checked={editedAmenities.includes(amenity)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setEditedAmenities([...editedAmenities, amenity]);
                        } else {
                          setEditedAmenities(editedAmenities.filter(a => a !== amenity));
                        }
                      }}
                      className="w-4 h-4 text-coral-500 rounded focus:ring-coral-500 flex-shrink-0"
                    />
                    <span className="text-sm text-gray-700">{amenity}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}

          {editedAmenities.includes('Private outdoor swimming pool') && (
            <div className="border-t pt-6 space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Pool Settings</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Opening Season
                </label>
                <input
                  type="text"
                  value={editedPoolOpeningSeason}
                  onChange={(e) => setEditedPoolOpeningSeason(e.target.value)}
                  placeholder="e.g., May - September"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Opening Hours
                </label>
                <input
                  type="text"
                  value={editedPoolOpeningHours}
                  onChange={(e) => setEditedPoolOpeningHours(e.target.value)}
                  placeholder="e.g., 8:00 AM - 8:00 PM"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-transparent"
                />
              </div>
            </div>
          )}
        </div>
      </SectionModal>

      <SectionModal
        isOpen={openModal === 'house-rules'}
        onClose={() => setOpenModal(null)}
        title="House Rules"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSaveHouseRules();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <React.Suspense fallback={<div>Loading editor...</div>}>
          <HouseRulesEditor
            data={{
              petsAllowed: editedPetsAllowed,
              partiesAllowed: editedPartiesAllowed,
              smokingAllowed: editedSmokingAllowed,
              photoshootsAllowed: editedPhotoshootsAllowed,
              quietHoursStart: editedQuietHoursStart,
              quietHoursEnd: editedQuietHoursEnd,
              checkInTime: editedCheckInTime,
              checkOutTime: editedCheckOutTime,
              customHouseRules: editedCustomHouseRules,
              maxGuests: editedMaxGuests
            }}
            onChange={(updates) => {
              if (updates.petsAllowed !== undefined) setEditedPetsAllowed(updates.petsAllowed);
              if (updates.partiesAllowed !== undefined) setEditedPartiesAllowed(updates.partiesAllowed);
              if (updates.smokingAllowed !== undefined) setEditedSmokingAllowed(updates.smokingAllowed);
              if (updates.photoshootsAllowed !== undefined) setEditedPhotoshootsAllowed(updates.photoshootsAllowed);
              if (updates.quietHoursStart !== undefined) setEditedQuietHoursStart(updates.quietHoursStart);
              if (updates.quietHoursEnd !== undefined) setEditedQuietHoursEnd(updates.quietHoursEnd);
              if (updates.checkInTime !== undefined) setEditedCheckInTime(updates.checkInTime);
              if (updates.checkOutTime !== undefined) setEditedCheckOutTime(updates.checkOutTime);
              if (updates.customHouseRules !== undefined) setEditedCustomHouseRules(updates.customHouseRules);
              if (updates.maxGuests !== undefined) setEditedMaxGuests(updates.maxGuests);
            }}
          />
        </React.Suspense>
      </SectionModal>

      <SectionModal
        isOpen={openModal === 'checkin'}
        onClose={() => setOpenModal(null)}
        title="Check-in Instructions"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSaveCheckInInstructions();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="checkInInstructions" className="block text-sm font-medium text-gray-700 mb-2">
              Check-in Instructions
            </label>
            <textarea
              id="checkInInstructions"
              value={editedCheckInInstructions}
              onChange={(e) => setEditedCheckInInstructions(e.target.value)}
              placeholder="Provide detailed check-in instructions for guests..."
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Attachments
            </label>
            <AttachmentManager
              attachments={attachments}
              onUpload={handleUploadAttachments}
              onDelete={handleDeleteAttachment}
              isUploading={isUploadingAttachment}
            />
          </div>
        </div>
      </SectionModal>

      <SectionModal
        isOpen={openModal === 'pricing'}
        onClose={() => setOpenModal(null)}
        title="Base Price & Duration"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSavePricing();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="basePrice" className="block text-sm font-medium text-gray-700 mb-2">
              Base Price (per night)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <input
                type="number"
                id="basePrice"
                value={editedBasePrice}
                onChange={(e) => setEditedBasePrice(e.target.value)}
                min="0"
                step="0.01"
                className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>
          </div>

          <div>
            <label htmlFor="cleaningFee" className="block text-sm font-medium text-gray-700 mb-2">
              Cleaning Fee
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <input
                type="number"
                id="cleaningFee"
                value={editedCleaningFee}
                onChange={(e) => setEditedCleaningFee(e.target.value)}
                min="0"
                step="0.01"
                className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>
          </div>

          <div>
            <label htmlFor="serviceFee" className="block text-sm font-medium text-gray-700 mb-2">
              Service Fee
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <input
                type="number"
                id="serviceFee"
                value={editedServiceFee}
                onChange={(e) => setEditedServiceFee(e.target.value)}
                min="0"
                step="0.01"
                className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              />
            </div>
          </div>

          <div>
            <label htmlFor="minimumStay" className="block text-sm font-medium text-gray-700 mb-2">
              Minimum Stay (nights)
            </label>
            <input
              type="number"
              id="minimumStay"
              value={editedMinStay}
              onChange={(e) => setEditedMinStay(e.target.value.replace(/\D/g, ''))}
              min="1"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>

          <div>
            <label htmlFor="maximumStay" className="block text-sm font-medium text-gray-700 mb-2">
              Maximum Stay (nights)
            </label>
            <input
              type="number"
              id="maximumStay"
              value={editedMaxStay}
              onChange={(e) => setEditedMaxStay(e.target.value.replace(/\D/g, ''))}
              min="1"
              placeholder="No limit"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
            <p className="text-xs text-gray-500 mt-1">Leave empty for no maximum limit</p>
          </div>
        </div>
      </SectionModal>

      <SectionModal
        isOpen={openModal === 'property-details'}
        onClose={() => setOpenModal(null)}
        title="Property Details"
        footer={
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleSaveApartmentDetails();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isUpdating ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Check className="w-4 h-4" />
              )}
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
            <button
              onClick={() => {
                handleCancelApartmentDetailsEdit();
                setOpenModal(null);
              }}
              disabled={isUpdating}
              className="bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        }
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="propertyName" className="block text-sm font-medium text-gray-700 mb-2">
              Property Name
            </label>
            <input
              type="text"
              id="propertyName"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              placeholder="Enter property name..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>

          <div>
            <label htmlFor="propertyLocation" className="block text-sm font-medium text-gray-700 mb-2">
              Location
            </label>
            <input
              type="text"
              id="propertyLocation"
              value={editedLocation}
              onChange={(e) => setEditedLocation(e.target.value)}
              placeholder="Enter property location..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-700 font-medium">Bedrooms</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setEditedBedrooms(Math.max(0, editedBedrooms - 1))}
                disabled={editedBedrooms <= 0 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-8 text-center font-medium">{editedBedrooms}</span>
              <button
                onClick={() => setEditedBedrooms(Math.min(10, editedBedrooms + 1))}
                disabled={editedBedrooms >= 10 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-700 font-medium">Bathrooms</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setEditedBathrooms(Math.max(1, editedBathrooms - 1))}
                disabled={editedBathrooms <= 1 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-8 text-center font-medium">{editedBathrooms}</span>
              <button
                onClick={() => setEditedBathrooms(Math.min(10, editedBathrooms + 1))}
                disabled={editedBathrooms >= 10 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-700 font-medium">Max Guests</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setEditedMaxGuests(Math.max(1, editedMaxGuests - 1))}
                disabled={editedMaxGuests <= 1 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-8 text-center font-medium">{editedMaxGuests}</span>
              <button
                onClick={() => setEditedMaxGuests(Math.min(20, editedMaxGuests + 1))}
                disabled={editedMaxGuests >= 20 || isUpdating}
                className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Property Type
            </label>
            <div className="px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
              {getTypeLabel(editedBedrooms === 0 ? 'studio' : editedBedrooms === 1 ? '1bed' : editedBedrooms === 2 ? '2bed' : '3bed')}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Automatically determined based on number of bedrooms
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              value={editedIsAvailable ? 'available' : 'closed'}
              onChange={(e) => setEditedIsAvailable(e.target.value === 'available')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            >
              <option value="available">Available</option>
              <option value="closed">Closed</option>
            </select>
          </div>
        </div>
      </SectionModal>
    </div>
  );
};