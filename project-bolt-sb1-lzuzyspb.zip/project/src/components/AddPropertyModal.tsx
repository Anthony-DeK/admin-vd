import React, { useState } from 'react';
import { X } from 'lucide-react';

interface AddApartmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (apartmentData: ApartmentFormData) => Promise<void>;
}

export interface ApartmentFormData {
  name: string;
  location: string;
  bedrooms: number;
  bathrooms: number;
  maxGuests: number;
  type: 'studio' | '1bed' | '2bed' | '3bed';
}

export const AddApartmentModal: React.FC<AddApartmentModalProps> = ({
  isOpen,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState<ApartmentFormData>({
    name: '',
    location: '',
    bedrooms: 0,
    bathrooms: 1,
    maxGuests: 1,
    type: 'studio'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseInt(value) || 0 : value
    }));
  };

  // Auto-determine apartment type based on bedrooms
  React.useEffect(() => {
    const { bedrooms } = formData;
    let newType: ApartmentFormData['type'] = 'studio';
    
    if (bedrooms === 0) newType = 'studio';
    else if (bedrooms === 1) newType = '1bed';
    else if (bedrooms === 2) newType = '2bed';
    else if (bedrooms >= 3) newType = '3bed';
    
    if (newType !== formData.type) {
      setFormData(prev => ({ ...prev, type: newType }));
    }
  }, [formData.bedrooms, formData.type]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.location.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave(formData);
      // Reset form
      setFormData({
        name: '',
        location: '',
        bedrooms: 0,
        bathrooms: 1,
        maxGuests: 1,
        type: 'studio'
      });
      onClose();
    } catch (error) {
      console.error('Error saving apartment:', error);
      alert('Failed to save apartment. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getTypeLabel = (type: string) => {
    const typeLabels = {
      studio: 'Studio',
      '1bed': '1 Bedroom',
      '2bed': '2 Bedrooms',
      '3bed': '3 Bedrooms'
    };
    return typeLabels[type as keyof typeof typeLabels] || type;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Add New Property</h2>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
              Accommodation Name *
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              disabled={isSubmitting}
              placeholder="e.g., Downtown Studio Apartment"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 disabled:opacity-50"
            />
          </div>

          <div>
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
              Location *
            </label>
            <input
              type="text"
              id="location"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
              disabled={isSubmitting}
              placeholder="e.g., Downtown Manhattan, New York"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 disabled:opacity-50"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700 mb-2">
                Bedrooms *
              </label>
              <input
                type="number"
                id="bedrooms"
                name="bedrooms"
                value={formData.bedrooms}
                onChange={handleChange}
                min="0"
                max="10"
                required
                disabled={isSubmitting}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 disabled:opacity-50"
              />
              <p className="text-xs text-gray-500 mt-1">0 for studio</p>
            </div>

            <div>
              <label htmlFor="bathrooms" className="block text-sm font-medium text-gray-700 mb-2">
                Bathrooms *
              </label>
              <input
                type="number"
                id="bathrooms"
                name="bathrooms"
                value={formData.bathrooms}
                onChange={handleChange}
                min="1"
                max="10"
                required
                disabled={isSubmitting}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label htmlFor="maxGuests" className="block text-sm font-medium text-gray-700 mb-2">
              Maximum Occupancy *
            </label>
            <input
              type="number"
              id="maxGuests"
              name="maxGuests"
              value={formData.maxGuests}
              onChange={handleChange}
              min="1"
              max="20"
              required
              disabled={isSubmitting}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 disabled:opacity-50"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Property Type
            </label>
            <div className="px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg text-gray-700">
              {getTypeLabel(formData.type)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Automatically determined based on number of bedrooms
            </p>
          </div>

          <div className="flex items-center justify-end gap-4 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 bg-coral-500 hover:bg-coral-600 text-white rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Creating...
                </>
              ) : (
                'Create Property'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};