import React from 'react';
import { LucideIcon } from 'lucide-react';

interface SectionTileProps {
  title: string;
  icon: LucideIcon;
  onClick: () => void;
  hasContent?: boolean;
}

export const SectionTile: React.FC<SectionTileProps> = ({
  title,
  icon: Icon,
  onClick,
  hasContent = true
}) => {
  return (
    <button
      onClick={onClick}
      className="group relative p-6 bg-white border-2 border-gray-200 rounded-lg hover:border-coral-500 hover:shadow-md transition-all text-left w-full"
    >
      <div className="flex items-center gap-4">
        <div className="p-3 bg-gray-50 rounded-lg group-hover:bg-coral-50 transition-colors">
          <Icon className="w-6 h-6 text-gray-600 group-hover:text-coral-600 transition-colors" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-coral-600 transition-colors">
            {title}
          </h3>
          {!hasContent && (
            <p className="text-sm text-gray-400 mt-1">Click to add</p>
          )}
        </div>
      </div>
    </button>
  );
};
