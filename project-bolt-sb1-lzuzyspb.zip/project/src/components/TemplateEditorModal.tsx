import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, Trash2, Info } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { MessageTemplate, TemplateAttachment } from '../types';

interface TemplateEditorModalProps {
  template: MessageTemplate | null;
  onClose: () => void;
  onSave: () => void;
}

export const TemplateEditorModal: React.FC<TemplateEditorModalProps> = ({
  template,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'booking_confirmation' as MessageTemplate['type'],
    subject: '',
    body: '',
    scheduleType: 'immediate' as MessageTemplate['scheduleType'],
    scheduleValue: 24,
    scheduleUnit: 'hours' as MessageTemplate['scheduleUnit'],
    scheduleEvent: 'booking_confirmed' as MessageTemplate['scheduleEvent'],
    isActive: true
  });

  const [attachments, setAttachments] = useState<TemplateAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bodyEditorRef = useRef<HTMLDivElement>(null);
  const subjectEditorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (template) {
      setFormData({
        name: template.name,
        type: template.type,
        subject: template.subject,
        body: template.body,
        scheduleType: template.scheduleType,
        scheduleValue: template.scheduleValue,
        scheduleUnit: template.scheduleUnit,
        scheduleEvent: template.scheduleEvent,
        isActive: template.isActive
      });
      loadAttachments(template.id);
    }
  }, [template]);

  const loadAttachments = async (templateId: string) => {
    try {
      const { data, error: fetchError } = await supabase
        .from('template_attachments')
        .select('*')
        .eq('template_id', templateId);

      if (fetchError) throw fetchError;

      const mappedAttachments: TemplateAttachment[] = (data || []).map(item => ({
        id: item.id,
        templateId: item.template_id,
        fileName: item.file_name,
        storagePath: item.storage_path,
        fileSize: item.file_size,
        mimeType: item.mime_type,
        createdAt: item.created_at
      }));

      setAttachments(mappedAttachments);
    } catch (err) {
      console.error('Error loading attachments:', err);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const parseTextWithPills = (text: string): (string | { type: 'pill'; value: string; label: string })[] => {
    const parts: (string | { type: 'pill'; value: string; label: string })[] = [];
    const regex = /\{\{([^}]+)\}\}/g;
    let lastIndex = 0;
    let match;

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(text.substring(lastIndex, match.index));
      }

      const varValue = match[0];
      const varName = match[1];
      const variable = dynamicVariables.find(v => v.value === varValue);
      const label = variable ? variable.label : varName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

      parts.push({ type: 'pill', value: varValue, label });
      lastIndex = regex.lastIndex;
    }

    if (lastIndex < text.length) {
      parts.push(text.substring(lastIndex));
    }

    return parts;
  };

  const renderEditorContent = (text: string) => {
    const parts = parseTextWithPills(text);
    return parts.map((part, index) => {
      if (typeof part === 'string') {
        return <span key={index}>{part || '\u200B'}</span>;
      } else {
        return (
          <span
            key={index}
            contentEditable={false}
            className="inline-flex items-center px-2 py-0.5 mx-0.5 bg-blue-100 text-blue-800 text-sm font-medium rounded-full cursor-default select-none"
            data-variable={part.value}
          >
            {part.label}
          </span>
        );
      }
    });
  };

  const handleEditorInput = (e: React.FormEvent<HTMLDivElement>, field: 'subject' | 'body') => {
    const element = e.currentTarget;
    const text = extractTextFromEditor(element);
    setFormData(prev => ({ ...prev, [field]: text }));

    const hasBraces = text.includes('{{') && text.includes('}}');
    if (hasBraces) {
      const caretPos = getCaretPosition(element);
      setTimeout(() => {
        updateEditorDisplay(field === 'body' ? bodyEditorRef : subjectEditorRef, text);
        restoreCaretPosition(element, caretPos);
      }, 0);
    }
  };

  const restoreCaretPosition = (element: HTMLDivElement, position: number) => {
    const selection = window.getSelection();
    if (!selection) return;

    let currentPos = 0;
    let targetNode: Node | null = null;
    let targetOffset = 0;

    const traverse = (node: Node): boolean => {
      if (node.nodeType === Node.TEXT_NODE) {
        const length = node.textContent?.length || 0;
        if (currentPos + length >= position) {
          targetNode = node;
          targetOffset = position - currentPos;
          return true;
        }
        currentPos += length;
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as HTMLElement;
        if (el.hasAttribute('data-variable')) {
          const varLength = (el.getAttribute('data-variable') || '').length;
          if (currentPos + varLength >= position) {
            targetNode = node;
            targetOffset = 0;
            return true;
          }
          currentPos += varLength;
        } else {
          for (const child of Array.from(node.childNodes)) {
            if (traverse(child)) return true;
          }
        }
      }
      return false;
    };

    traverse(element);

    if (targetNode) {
      try {
        const range = document.createRange();
        if (targetNode.nodeType === Node.TEXT_NODE) {
          range.setStart(targetNode, Math.min(targetOffset, targetNode.textContent?.length || 0));
        } else {
          range.setStartAfter(targetNode);
        }
        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);
      } catch (err) {
        console.error('Error restoring caret:', err);
      }
    }
  };

  const extractTextFromEditor = (element: HTMLDivElement): string => {
    let text = '';
    const traverse = (node: Node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        text += node.textContent || '';
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as HTMLElement;
        if (el.hasAttribute('data-variable')) {
          text += el.getAttribute('data-variable') || '';
        } else {
          node.childNodes.forEach(traverse);
        }
      }
    };
    element.childNodes.forEach(traverse);
    return text;
  };

  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLDivElement>, field: 'subject' | 'body') => {
    if (e.key === 'Enter' && field === 'subject') {
      e.preventDefault();
    }
  };

  const insertVariableIntoEditor = (variable: string, editorRef: React.RefObject<HTMLDivElement>, field: 'subject' | 'body') => {
    const editor = editorRef.current;
    if (!editor) return;

    editor.focus();

    const selection = window.getSelection();
    if (!selection || !selection.rangeCount) {
      setFormData(prev => ({ ...prev, [field]: prev[field] + variable }));
      setTimeout(() => updateEditorDisplay(editorRef, formData[field] + variable), 0);
      return;
    }

    const range = selection.getRangeAt(0);
    range.deleteContents();

    const textBefore = extractTextFromEditor(editor).substring(0, getCaretPosition(editor));
    const textAfter = extractTextFromEditor(editor).substring(getCaretPosition(editor));
    const newText = textBefore + variable + textAfter;

    setFormData(prev => ({ ...prev, [field]: newText }));
    setTimeout(() => {
      updateEditorDisplay(editorRef, newText);
      setCaretAfterVariable(editor);
    }, 0);
  };

  const getCaretPosition = (element: HTMLDivElement): number => {
    const selection = window.getSelection();
    if (!selection || !selection.rangeCount) return 0;

    const range = selection.getRangeAt(0);
    const preCaretRange = range.cloneRange();
    preCaretRange.selectNodeContents(element);
    preCaretRange.setEnd(range.endContainer, range.endOffset);

    return extractTextFromEditor(preCaretRange.cloneContents() as unknown as HTMLDivElement).length;
  };

  const setCaretAfterVariable = (element: HTMLDivElement) => {
    const selection = window.getSelection();
    if (!selection) return;

    const range = document.createRange();
    const lastChild = element.lastChild;
    if (lastChild) {
      range.setStartAfter(lastChild);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  };

  const updateEditorDisplay = (editorRef: React.RefObject<HTMLDivElement>, text: string) => {
    const editor = editorRef.current;
    if (!editor) return;

    const currentText = extractTextFromEditor(editor);
    if (currentText !== text) {
      editor.innerHTML = '';
      const parts = parseTextWithPills(text);
      parts.forEach(part => {
        if (typeof part === 'string') {
          editor.appendChild(document.createTextNode(part || '\u200B'));
        } else {
          const pill = document.createElement('span');
          pill.contentEditable = 'false';
          pill.className = 'inline-flex items-center px-2 py-0.5 mx-0.5 bg-blue-100 text-blue-800 text-sm font-medium rounded-full cursor-default select-none';
          pill.setAttribute('data-variable', part.value);
          pill.textContent = part.label;
          editor.appendChild(pill);
        }
      });
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    const file = e.target.files[0];
    setUploading(true);
    setError(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const userId = user?.id || 'anonymous';

      if (!template) {
        setError('Please save the template first before adding attachments');
        setUploading(false);
        return;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${userId}/${template.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('template-attachments')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { error: insertError } = await supabase
        .from('template_attachments')
        .insert({
          template_id: template.id,
          file_name: file.name,
          storage_path: fileName,
          file_size: file.size,
          mime_type: file.type
        });

      if (insertError) throw insertError;

      await loadAttachments(template.id);
    } catch (err) {
      console.error('Error uploading file:', err);
      setError('Failed to upload attachment');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteAttachment = async (attachment: TemplateAttachment) => {
    if (!confirm('Are you sure you want to delete this attachment?')) return;

    try {
      const { error: deleteFileError } = await supabase.storage
        .from('template-attachments')
        .remove([attachment.storagePath]);

      if (deleteFileError) throw deleteFileError;

      const { error: deleteRecordError } = await supabase
        .from('template_attachments')
        .delete()
        .eq('id', attachment.id);

      if (deleteRecordError) throw deleteRecordError;

      setAttachments(prev => prev.filter(a => a.id !== attachment.id));
    } catch (err) {
      console.error('Error deleting attachment:', err);
      setError('Failed to delete attachment');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    if (!formData.subject.trim()) {
      setError('Email subject is required');
      setSaving(false);
      return;
    }

    if (!formData.body.trim()) {
      setError('Message body is required');
      setSaving(false);
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const userId = user?.id || 'anonymous';

      const templateData = {
        user_id: userId,
        name: formData.name,
        type: formData.type,
        subject: formData.subject,
        body: formData.body,
        schedule_type: formData.scheduleType,
        schedule_value: formData.scheduleValue,
        schedule_unit: formData.scheduleUnit,
        schedule_event: formData.scheduleEvent,
        is_active: formData.isActive,
        updated_at: new Date().toISOString()
      };

      if (template) {
        const { error: updateError } = await supabase
          .from('message_templates')
          .update(templateData)
          .eq('id', template.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('message_templates')
          .insert(templateData);

        if (insertError) throw insertError;
      }

      onSave();
    } catch (err) {
      console.error('Error saving template:', err);
      setError('Failed to save template');
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    if (bodyEditorRef.current) {
      updateEditorDisplay(bodyEditorRef, formData.body);
    }
    if (subjectEditorRef.current) {
      updateEditorDisplay(subjectEditorRef, formData.subject);
    }
  }, [formData.subject, formData.body]);

  const dynamicVariables = [
    { label: 'Guest Name', value: '{{guest_name}}' },
    { label: 'Guest Email', value: '{{guest_email}}' },
    { label: 'Property Name', value: '{{property_name}}' },
    { label: 'Check-In Date', value: '{{check_in_date}}' },
    { label: 'Check-Out Date', value: '{{check_out_date}}' },
    { label: 'Check-In Time', value: '{{check_in_time}}' },
    { label: 'Check-Out Time', value: '{{check_out_time}}' },
    { label: 'Number of Guests', value: '{{num_guests}}' },
    { label: 'Total Amount', value: '{{total_amount}}' },
    { label: 'House Rules', value: '{{house_rules}}' }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">
            {template ? 'Edit Template' : 'New Template'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Template Name *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                placeholder="e.g., Welcome Message"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Template Type *
              </label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
              >
                <option value="booking_confirmation">Booking Confirmation</option>
                <option value="booking_cancellation">Booking Cancellation</option>
                <option value="check_in_reminder">Check-In Reminder</option>
                <option value="check_out_reminder">Check-Out Reminder</option>
                <option value="post_checkout">Post Check-Out</option>
                <option value="custom">Custom</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Email Subject *
              </label>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Info className="w-4 h-4" />
                <span>Click variables to insert</span>
              </div>
            </div>
            <div
              ref={subjectEditorRef}
              contentEditable
              onInput={(e) => handleEditorInput(e, 'subject')}
              onKeyDown={(e) => handleEditorKeyDown(e, 'subject')}
              className="w-full min-h-[42px] px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 focus:outline-none overflow-x-auto"
              style={{ lineHeight: '26px', whiteSpace: 'nowrap' }}
              data-placeholder="e.g., Your booking at {{property_name}} is confirmed!"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {dynamicVariables.slice(0, 5).map((variable) => (
                <button
                  key={variable.value}
                  type="button"
                  onClick={() => insertVariableIntoEditor(variable.value, subjectEditorRef, 'subject')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-md transition-colors"
                >
                  {variable.label}
                </button>
              ))}
            </div>
            <style>{`
              [data-placeholder]:empty:before {
                content: attr(data-placeholder);
                color: #9ca3af;
                pointer-events: none;
              }
            `}</style>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Message Body *
              </label>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Info className="w-4 h-4" />
                <span>Click variables below to insert</span>
              </div>
            </div>
            <div
              ref={bodyEditorRef}
              contentEditable
              onInput={(e) => handleEditorInput(e, 'body')}
              className="w-full min-h-[240px] px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500 focus:outline-none text-sm whitespace-pre-wrap"
              style={{ lineHeight: '1.5' }}
              data-placeholder="Dear {{guest_name}},

Your booking at {{property_name}} has been confirmed!

Check-in: {{check_in_date}} at {{check_in_time}}
Check-out: {{check_out_date}} at {{check_out_time}}"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {dynamicVariables.map((variable) => (
                <button
                  key={variable.value}
                  type="button"
                  onClick={() => insertVariableIntoEditor(variable.value, bodyEditorRef, 'body')}
                  className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-md transition-colors"
                >
                  {variable.label}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Scheduling</h3>

            <div className="grid grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  When to Send
                </label>
                <select
                  name="scheduleType"
                  value={formData.scheduleType}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                >
                  <option value="immediate">Immediately</option>
                  <option value="before">Before</option>
                  <option value="after">After</option>
                </select>
              </div>

              {formData.scheduleType !== 'immediate' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Time Value
                    </label>
                    <input
                      type="number"
                      name="scheduleValue"
                      value={formData.scheduleValue}
                      onChange={handleChange}
                      min="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Unit
                    </label>
                    <select
                      name="scheduleUnit"
                      value={formData.scheduleUnit}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                    >
                      <option value="hours">Hours</option>
                      <option value="days">Days</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Event
                    </label>
                    <select
                      name="scheduleEvent"
                      value={formData.scheduleEvent}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                    >
                      <option value="booking_confirmed">Booking Confirmed</option>
                      <option value="booking_cancelled">Booking Cancelled</option>
                      <option value="check_in">Check-In</option>
                      <option value="check_out">Check-Out</option>
                    </select>
                  </div>
                </>
              )}
            </div>
          </div>

          {template && (
            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Attachments</h3>

              {attachments.length > 0 && (
                <div className="space-y-2 mb-4">
                  {attachments.map((attachment) => (
                    <div
                      key={attachment.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-sm">
                          <p className="font-medium text-gray-900">{attachment.fileName}</p>
                          <p className="text-gray-500">
                            {(attachment.fileSize / 1024).toFixed(2)} KB
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteAttachment(attachment)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <label className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg hover:border-coral-500 hover:bg-coral-50 transition-colors cursor-pointer">
                <Upload className="w-5 h-5 text-gray-600" />
                <span className="text-sm text-gray-600">
                  {uploading ? 'Uploading...' : 'Add Attachment'}
                </span>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="hidden"
                />
              </label>
            </div>
          )}

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isActive"
              name="isActive"
              checked={formData.isActive}
              onChange={handleChange}
              className="w-4 h-4 text-coral-500 border-gray-300 rounded focus:ring-coral-500"
            />
            <label htmlFor="isActive" className="text-sm font-medium text-gray-700">
              Template is active
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-coral-500 text-white rounded-lg hover:bg-coral-600 transition-colors disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Template'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
