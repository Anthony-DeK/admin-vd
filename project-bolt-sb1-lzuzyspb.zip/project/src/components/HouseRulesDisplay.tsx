import React from 'react';
import { CheckCircle2, XCircle, Clock, DoorOpen, DoorClosed, Users } from 'lucide-react';

interface HouseRulesDisplayProps {
  petsAllowed?: boolean;
  partiesAllowed?: boolean;
  smokingAllowed?: boolean;
  photoshootsAllowed?: boolean;
  quietHoursStart?: string;
  quietHoursEnd?: string;
  checkInTime?: string;
  checkOutTime?: string;
  customHouseRules?: string;
  maxGuests?: number;
}

export const HouseRulesDisplay: React.FC<HouseRulesDisplayProps> = ({
  petsAllowed,
  partiesAllowed,
  smokingAllowed,
  photoshootsAllowed,
  quietHoursStart,
  quietHoursEnd,
  checkInTime,
  checkOutTime,
  customHouseRules,
  maxGuests
}) => {
  const hasAnyRules =
    petsAllowed !== undefined ||
    partiesAllowed !== undefined ||
    smokingAllowed !== undefined ||
    photoshootsAllowed !== undefined ||
    quietHoursStart ||
    quietHoursEnd ||
    checkInTime ||
    checkOutTime ||
    customHouseRules ||
    maxGuests;

  if (!hasAnyRules) {
    return (
      <p className="text-gray-400 italic">No house rules listed. Click the edit button to add house rules.</p>
    );
  }

  const formatTime = (time?: string) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const RuleItem = ({ allowed, label }: { allowed?: boolean; label: string }) => {
    if (allowed === undefined) return null;
    return (
      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
        {allowed ? (
          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
        ) : (
          <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
        )}
        <span className={allowed ? 'text-gray-700' : 'text-gray-700'}>
          {label} {allowed ? 'allowed' : 'not allowed'}
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Permissions */}
      {(petsAllowed !== undefined || partiesAllowed !== undefined || smokingAllowed !== undefined || photoshootsAllowed !== undefined) && (
        <div className="space-y-2">
          <RuleItem allowed={petsAllowed} label="Pets" />
          <RuleItem allowed={partiesAllowed} label="Parties / Events" />
          <RuleItem allowed={smokingAllowed} label="Smoking / Vaping" />
          <RuleItem allowed={photoshootsAllowed} label="Photoshoots / Filmmaking" />
        </div>
      )}

      {/* Guest Capacity */}
      {maxGuests && (
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <Users className="w-5 h-5 text-gray-600 flex-shrink-0" />
          <span className="text-gray-700">
            Maximum {maxGuests} {maxGuests === 1 ? 'guest' : 'guests'}
          </span>
        </div>
      )}

      {/* Quiet Hours */}
      {(quietHoursStart || quietHoursEnd) && (
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <Clock className="w-5 h-5 text-gray-600 flex-shrink-0" />
          <span className="text-gray-700">
            Quiet hours: {formatTime(quietHoursStart) || '–'} to {formatTime(quietHoursEnd) || '–'}
          </span>
        </div>
      )}

      {/* Check-in/Check-out Times */}
      {(checkInTime || checkOutTime) && (
        <div className="space-y-2">
          {checkInTime && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <DoorOpen className="w-5 h-5 text-gray-600 flex-shrink-0" />
              <span className="text-gray-700">
                Check-in: {formatTime(checkInTime)}
              </span>
            </div>
          )}
          {checkOutTime && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <DoorClosed className="w-5 h-5 text-gray-600 flex-shrink-0" />
              <span className="text-gray-700">
                Check-out: {formatTime(checkOutTime)}
              </span>
            </div>
          )}
        </div>
      )}

      {/* Custom Rules */}
      {customHouseRules && (
        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="text-sm font-semibold text-gray-900 mb-2">Additional Rules</h4>
          <p className="text-gray-700 whitespace-pre-wrap">{customHouseRules}</p>
        </div>
      )}
    </div>
  );
};
