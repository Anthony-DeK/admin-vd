import React from 'react';
import { Calendar, MapPin, ArrowLeft } from 'lucide-react';
import { Apartment, Booking } from '../types';
import { BookingCalendar } from './BookingCalendar';

interface CalendarViewProps {
  apartments: Apartment[];
  bookings: Booking[];
  selectedApartment?: Apartment;
  onSelectApartment: (apartment: Apartment) => void;
  onBack: () => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  apartments,
  bookings,
  selectedApartment,
  onSelectApartment,
  onBack
}) => {
  // Show calendar view if an apartment is selected
  if (selectedApartment) {
    return (
      <div className="max-w-3xl mx-auto">
        {/* Property Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 min-w-0 flex-1">
              <button
                onClick={onBack}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div className="min-w-0 flex-1">
                <h1 className="text-2xl font-bold text-gray-900 truncate">{selectedApartment.name}</h1>
                {selectedApartment.location && (
                  <div className="flex items-center gap-1 text-gray-600 mt-1 min-w-0">
                    <MapPin className="w-4 h-4 flex-shrink-0" />
                    <span className="truncate text-sm sm:text-base">{selectedApartment.location}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Calendar */}
        <BookingCalendar
          bookings={bookings.filter(b => b.apartmentId === selectedApartment.id)}
          apartmentId={selectedApartment.id}
          basePrice={selectedApartment.basePrice || 0}
          baseMinStay={selectedApartment.minimumStay || 1}
        />
      </div>
    );
  }

  // Show apartment selection grid
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900 mb-1">Calendar</h2>
        <p className="text-sm text-gray-600">Select a property to view its booking calendar</p>
      </div>

      <div className="p-6">
        {apartments.length === 0 ? (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Properties Yet</h3>
            <p className="text-gray-600">Add a property to start managing bookings</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {apartments.map((apartment) => (
              <button
                key={apartment.id}
                onClick={() => onSelectApartment(apartment)}
                className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-shadow text-left"
              >
                <div className="relative h-48 bg-gray-200">
                  {apartment.coverImage ? (
                    <img
                      src={apartment.coverImage}
                      alt={apartment.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Calendar className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                  <div className="absolute top-3 right-3">
                    <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                      apartment.isAvailable
                        ? 'bg-green-500 text-white'
                        : 'bg-red-500 text-white'
                    }`}>
                      {apartment.isAvailable ? 'Available' : 'Unavailable'}
                    </span>
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{apartment.name}</h3>

                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="truncate">{apartment.location}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
