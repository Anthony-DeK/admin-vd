import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, DollarSign } from 'lucide-react';
import { Booking } from '../types';
import { CustomPricingData } from './CustomPricingModal';
import { supabase } from '../lib/supabase';

interface DatePricing {
  id: string;
  date: string;
  fixedPrice: number;
  minimumStay: number;
}

interface BookingCalendarProps {
  bookings: Booking[];
  apartmentId: string;
  basePrice: number;
  baseMinStay: number;
}

export const BookingCalendar: React.FC<BookingCalendarProps> = ({
  bookings,
  apartmentId,
  basePrice,
  baseMinStay
}) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDates, setSelectedDates] = useState<Date[]>([]);
  const [customPricing, setCustomPricing] = useState<Map<string, DatePricing>>(new Map());
  const [showPricingSidebar, setShowPricingSidebar] = useState(false);
  const [isLoadingPricing, setIsLoadingPricing] = useState(false);
  const [fixedPrice, setFixedPrice] = useState('');
  const [minimumStay, setMinimumStay] = useState('');

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const formatDate = (year: number, month: number, day: number) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const formatDateForDB = (date: Date) => {
    // Format date in local timezone to avoid UTC conversion issues
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const getBookingsForDate = (date: string) => {
    return bookings.filter(booking => {
      const checkIn = new Date(booking.checkIn + 'T00:00:00');
      const checkOut = new Date(booking.checkOut + 'T00:00:00');
      const currentDate = new Date(date + 'T00:00:00');
      return currentDate >= checkIn && currentDate <= checkOut;
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const loadCustomPricing = async () => {
    const { data, error } = await supabase
      .from('date_specific_pricing')
      .select('*')
      .eq('apartment_id', apartmentId);

    if (error) {
      console.error('Error loading custom pricing:', error);
      return;
    }

    if (data) {
      const pricingMap = new Map<string, DatePricing>();

      data.forEach((entry) => {
        // Parse dates properly to avoid timezone issues
        const start = new Date(entry.start_date + 'T00:00:00');
        const end = new Date(entry.end_date + 'T00:00:00');

        // Create a new date object for each iteration
        const currentDate = new Date(start);
        while (currentDate <= end) {
          const dateStr = formatDate(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
          pricingMap.set(dateStr, {
            id: entry.id,
            date: dateStr,
            fixedPrice: entry.fixed_price || basePrice,
            minimumStay: entry.minimum_stay || baseMinStay
          });
          currentDate.setDate(currentDate.getDate() + 1);
        }
      });

      setCustomPricing(pricingMap);
    }
  };

  useEffect(() => {
    loadCustomPricing();
  }, [apartmentId]);

  const handleDateClick = (date: Date) => {
    const dateString = formatDate(date.getFullYear(), date.getMonth(), date.getDate());
    const bookingsForDate = getBookingsForDate(dateString);

    if (bookingsForDate.length > 0) {
      return;
    }

    const isSelected = selectedDates.some(
      d => d.toDateString() === date.toDateString()
    );

    if (isSelected) {
      const newDates = selectedDates.filter(
        d => d.toDateString() !== date.toDateString()
      );
      setSelectedDates(newDates);
    } else {
      setSelectedDates([...selectedDates, date]);
    }
  };

  const handleSaveCustomPricing = async () => {
    if (selectedDates.length === 0) return;

    setIsLoadingPricing(true);

    try {
      const priceValue = parseFloat(fixedPrice);
      const stayValue = parseInt(minimumStay);

      if (isNaN(priceValue) || priceValue < 0) {
        alert('Please enter a valid price');
        setIsLoadingPricing(false);
        return;
      }

      if (isNaN(stayValue) || stayValue < 1) {
        alert('Please enter a valid minimum stay (at least 1 night)');
        setIsLoadingPricing(false);
        return;
      }

      const sortedDates = [...selectedDates].sort((a, b) => a.getTime() - b.getTime());

      // Group consecutive dates into ranges
      const dateRanges: Array<{ start: Date; end: Date }> = [];
      let currentRangeStart = sortedDates[0];
      let currentRangeEnd = sortedDates[0];

      for (let i = 1; i < sortedDates.length; i++) {
        const prevDate = sortedDates[i - 1];
        const currDate = sortedDates[i];
        const dayDiff = Math.floor((currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24));

        if (dayDiff === 1) {
          // Consecutive date, extend current range
          currentRangeEnd = currDate;
        } else {
          // Gap found, save current range and start new one
          dateRanges.push({ start: currentRangeStart, end: currentRangeEnd });
          currentRangeStart = currDate;
          currentRangeEnd = currDate;
        }
      }
      // Add the last range
      dateRanges.push({ start: currentRangeStart, end: currentRangeEnd });

      // Delete existing pricing for all selected dates
      for (const date of selectedDates) {
        const dateStr = formatDateForDB(date);
        const { error: deleteError } = await supabase
          .from('date_specific_pricing')
          .delete()
          .eq('apartment_id', apartmentId)
          .lte('start_date', dateStr)
          .gte('end_date', dateStr);

        if (deleteError) {
          console.error('Error deleting overlapping pricing:', deleteError);
        }
      }

      // Insert new pricing for each consecutive date range
      const insertPromises = dateRanges.map(range =>
        supabase
          .from('date_specific_pricing')
          .insert({
            apartment_id: apartmentId,
            start_date: formatDateForDB(range.start),
            end_date: formatDateForDB(range.end),
            fixed_price: priceValue,
            price_multiplier: null,
            minimum_stay: stayValue
          })
      );

      const results = await Promise.all(insertPromises);
      const errors = results.filter(r => r.error);

      if (errors.length > 0) {
        console.error('Errors saving custom pricing:', errors);
        alert(`Failed to save some custom pricing entries`);
      } else {
        await loadCustomPricing();
        setSelectedDates([]);
        setShowPricingSidebar(false);
        setFixedPrice('');
        setMinimumStay('');
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      alert('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoadingPricing(false);
    }
  };

  const handleClearSelection = () => {
    setSelectedDates([]);
    setShowPricingSidebar(false);
    setFixedPrice('');
    setMinimumStay('');
  };

  useEffect(() => {
    if (selectedDates.length === 0) {
      setFixedPrice('');
      setMinimumStay('');
      return;
    }

    const prices: number[] = [];
    const stays: number[] = [];

    selectedDates.forEach(date => {
      const dateStr = formatDate(
        date.getFullYear(),
        date.getMonth(),
        date.getDate()
      );
      const pricing = customPricing.get(dateStr);
      if (pricing) {
        prices.push(pricing.fixedPrice);
        stays.push(pricing.minimumStay);
      }
    });

    if (prices.length > 0) {
      const minPrice = Math.min(...prices);
      const maxPrice = Math.max(...prices);
      const minStay = Math.min(...stays);
      const maxStay = Math.max(...stays);

      if (minPrice === maxPrice) {
        setFixedPrice(minPrice.toString());
      } else {
        setFixedPrice('');
      }

      if (minStay === maxStay) {
        setMinimumStay(minStay.toString());
      } else {
        setMinimumStay('');
      }
    } else {
      setFixedPrice('');
      setMinimumStay('');
    }
  }, [selectedDates, customPricing]);

  const formatDateRange = () => {
    if (selectedDates.length === 0) return '';
    if (selectedDates.length === 1) {
      return selectedDates[0].toLocaleDateString();
    }

    const sortedDates = [...selectedDates].sort((a, b) => a.getTime() - b.getTime());
    return `${sortedDates[0].toLocaleDateString()} - ${sortedDates[sortedDates.length - 1].toLocaleDateString()}`;
  };

  const getPriceRange = () => {
    const prices: number[] = [];
    selectedDates.forEach(date => {
      const dateStr = formatDate(date.getFullYear(), date.getMonth(), date.getDate());
      const pricing = customPricing.get(dateStr);
      if (pricing) {
        prices.push(pricing.fixedPrice);
      }
    });

    if (prices.length === 0) return null;
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    return minPrice !== maxPrice ? { min: minPrice, max: maxPrice } : null;
  };

  const getStayRange = () => {
    const stays: number[] = [];
    selectedDates.forEach(date => {
      const dateStr = formatDate(date.getFullYear(), date.getMonth(), date.getDate());
      const pricing = customPricing.get(dateStr);
      if (pricing) {
        stays.push(pricing.minimumStay);
      }
    });

    if (stays.length === 0) return null;
    const minStay = Math.min(...stays);
    const maxStay = Math.max(...stays);
    return minStay !== maxStay ? { min: minStay, max: maxStay } : null;
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const days = [];
  
  // Empty cells for days before the first day of the month
  for (let i = 0; i < firstDay; i++) {
    days.push(<div key={`empty-${i}`} className="h-20"></div>);
  }

  // Days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const dateString = formatDate(currentDate.getFullYear(), currentDate.getMonth(), day);
    const dayBookings = getBookingsForDate(dateString);
    const isToday = new Date().toDateString() === date.toDateString();
    const isSelected = selectedDates.some(d => d.toDateString() === date.toDateString());
    const hasCustomPricing = customPricing.has(dateString);
    const pricingInfo = customPricing.get(dateString);
    const hasBookings = dayBookings.length > 0;

    days.push(
      <div
        key={day}
        onClick={() => handleDateClick(date)}
        className={`h-20 border border-gray-200 p-2 transition-colors ${
          hasBookings
            ? 'cursor-not-allowed bg-white'
            : isSelected
            ? 'bg-coral-50 border-coral-300 cursor-pointer'
            : isToday
            ? 'bg-blue-50 border-blue-300 cursor-pointer hover:bg-blue-100'
            : 'bg-white hover:bg-gray-50 cursor-pointer'
        }`}
      >
        <div className={`text-xs font-semibold mb-1 ${
          isSelected ? 'text-coral-600' : isToday ? 'text-blue-600' : 'text-gray-900'
        }`}>
          {day}
        </div>
        <div className="space-y-1">
          {dayBookings.slice(0, 1).map((booking, index) => (
            <div
              key={`${booking.id}-${index}`}
              className={`text-xs px-1.5 py-0.5 rounded font-medium truncate ${
                booking.status === 'confirmed' ? 'bg-green-500 text-white' :
                booking.status === 'pending' ? 'bg-yellow-400 text-gray-900' :
                booking.status === 'cancelled' ? 'bg-red-500 text-white' :
                'bg-gray-500 text-white'
              }`}
              title={`${booking.guestName} - ${booking.status}`}
            >
              {booking.guestName}
            </div>
          ))}
          {dayBookings.length > 1 && (
            <div className="text-xs text-gray-600 px-1.5 font-medium">
              +{dayBookings.length - 1}
            </div>
          )}
          {!hasBookings && (
            <div className={`text-xs px-1.5 py-0.5 rounded flex items-center gap-0.5 ${
              hasCustomPricing && pricingInfo
                ? 'bg-green-50 text-green-700 border border-green-200'
                : 'bg-gray-50 text-gray-600'
            }`}>
              <DollarSign className="w-3 h-3" />
              ${hasCustomPricing && pricingInfo ? pricingInfo.fixedPrice : basePrice}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between p-4 border-b border-gray-200 gap-3">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </h2>
            <div className="flex flex-wrap items-center gap-3 mt-1.5">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-green-500"></div>
                <span className="text-xs text-gray-600">Confirmed</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-yellow-500"></div>
                <span className="text-xs text-gray-600">Pending</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-gray-500"></div>
                <span className="text-xs text-gray-600">Completed</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-red-500"></div>
                <span className="text-xs text-gray-600">Cancelled</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigateMonth('prev')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => navigateMonth('next')}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {selectedDates.length > 0 && (
          <div className="px-4 py-2.5 border-b border-gray-200 bg-blue-50">
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {selectedDates.length} date{selectedDates.length !== 1 ? 's' : ''} selected
                </p>
                <p className="text-xs text-gray-600 mt-0.5 truncate">
                  {formatDateRange()}
                </p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => setShowPricingSidebar(true)}
                  className="bg-coral-500 hover:bg-coral-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors text-sm"
                >
                  <DollarSign className="w-4 h-4" />
                  Set Pricing
                </button>
                <button
                  onClick={handleClearSelection}
                  className="bg-white hover:bg-gray-100 text-gray-700 px-4 py-2 rounded-lg border border-gray-300 transition-colors text-sm"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="p-4">
          <div className="grid grid-cols-7 gap-0 mb-1">
            {dayNames.map(day => (
              <div key={day} className="text-center text-xs font-medium text-gray-500 py-1.5">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0 border border-gray-200 rounded-lg overflow-hidden">
            {days}
          </div>
        </div>
      </div>

      {showPricingSidebar && selectedDates.length > 0 && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Custom Pricing</h3>
            </div>

            <div className="px-6 py-6 space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center gap-2 text-blue-800 mb-1">
                  <DollarSign className="w-4 h-4" />
                  <span className="text-sm font-medium">Selected Dates</span>
                </div>
                <p className="text-sm text-blue-700">{formatDateRange()}</p>
                <p className="text-xs text-blue-600 mt-1">
                  {selectedDates.length} date{selectedDates.length !== 1 ? 's' : ''} selected
                </p>
              </div>

              <div>
                <label htmlFor="fixedPrice" className="block text-sm font-medium text-gray-700 mb-2">
                  Price per Night
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="fixedPrice"
                    value={fixedPrice}
                    onChange={(e) => setFixedPrice(e.target.value)}
                    min="0"
                    step="1"
                    placeholder={basePrice.toString()}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                  />
                </div>
                {getPriceRange() ? (
                  <p className="text-xs text-amber-600 mt-1 font-medium">
                    Current range: ${getPriceRange()!.min} - ${getPriceRange()!.max}/night
                  </p>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">Base price: ${basePrice}/night</p>
                )}
              </div>

              <div>
                <label htmlFor="minimumStay" className="block text-sm font-medium text-gray-700 mb-2">
                  Minimum Stay (nights)
                </label>
                <input
                  type="number"
                  id="minimumStay"
                  value={minimumStay}
                  onChange={(e) => setMinimumStay(e.target.value.replace(/\D/g, ''))}
                  min="1"
                  placeholder={baseMinStay.toString()}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
                />
                {getStayRange() ? (
                  <p className="text-xs text-amber-600 mt-1 font-medium">
                    Current range: {getStayRange()!.min} - {getStayRange()!.max} night{getStayRange()!.max !== 1 ? 's' : ''}
                  </p>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">
                    Base minimum stay: {baseMinStay} night{baseMinStay !== 1 ? 's' : ''}
                  </p>
                )}
              </div>
            </div>

            <div className="px-6 py-4 border-t border-gray-200 bg-white flex flex-col gap-3">
              <button
                onClick={handleSaveCustomPricing}
                disabled={isLoadingPricing}
                className="w-full bg-coral-500 hover:bg-coral-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-colors"
              >
                {isLoadingPricing ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <DollarSign className="w-4 h-4" />
                )}
                {isLoadingPricing ? 'Saving...' : 'Save Custom Pricing'}
              </button>
              <button
                onClick={() => setShowPricingSidebar(false)}
                disabled={isLoadingPricing}
                className="w-full bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed text-gray-700 px-4 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};