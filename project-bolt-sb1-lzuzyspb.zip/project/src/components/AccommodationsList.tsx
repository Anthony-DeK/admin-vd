import React, { useState } from 'react';
import { Search, Plus, MapPin, Users, Bed, Bath, DollarSign, Eye } from 'lucide-react';
import { Apartment } from '../types';
import { AddApartmentModal, ApartmentFormData } from './AddPropertyModal';
import { useAuth } from '../contexts/AuthContext';

interface AccommodationsListProps {
  apartments: Apartment[];
  onViewDetails: (apartment: Apartment) => void;
  onAddProperty: (apartmentData: ApartmentFormData) => Promise<void>;
}

export const AccommodationsList: React.FC<AccommodationsListProps> = ({
  apartments,
  onViewDetails,
  onAddProperty
}) => {
  const { isGuestMode } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const filteredApartments = apartments.filter(apartment =>
    apartment.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apartment.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    apartment.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeLabel = (type: string) => {
    const typeLabels = {
      studio: 'Studio',
      '1bed': '1 Bedroom',
      '2bed': '2 Bedrooms',
      '3bed': '3 Bedrooms'
    };
    return typeLabels[type as keyof typeof typeLabels] || type;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleAddProperty = async (apartmentData: ApartmentFormData) => {
    await onAddProperty(apartmentData);
    setIsAddModalOpen(false);
  };

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Properties</h2>
            {!isGuestMode && (
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="bg-coral-500 hover:bg-coral-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Property
              </button>
            )}
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search properties..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral-500 focus:border-coral-500"
            />
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredApartments.map((apartment) => (
              <div
                key={apartment.id}
                className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => onViewDetails(apartment)}
              >
                <div className="relative h-48 bg-gray-200">
                  {apartment.coverImage ? (
                    <img
                      src={apartment.coverImage}
                      alt={apartment.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <Bed className="w-12 h-12" />
                    </div>
                  )}
                  <div className="absolute top-3 right-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      apartment.isAvailable 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {apartment.isAvailable ? 'Available' : 'Unavailable'}
                    </span>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 truncate">
                      {apartment.name}
                    </h3>
                  </div>

                  {apartment.location && (
                    <div className="flex items-center gap-1 text-sm text-gray-600 mb-3">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{apartment.location}</span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <Bed className="w-3 h-3 flex-shrink-0" />
                      <span className="whitespace-nowrap">{getTypeLabel(apartment.type)}</span>
                    </div>
                    {apartment.bathrooms && (
                      <div className="flex items-center gap-1">
                        <Bath className="w-3 h-3 flex-shrink-0" />
                        <span className="whitespace-nowrap">{apartment.bathrooms} Bath{apartment.bathrooms > 1 ? 's' : ''}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Users className="w-3 h-3 flex-shrink-0" />
                      <span className="whitespace-nowrap">{apartment.maxGuests} guests</span>
                    </div>
                  </div>

                  {apartment.basePrice && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-lg font-semibold text-gray-900">
                        <DollarSign className="w-4 h-4" />
                        <span>{formatCurrency(apartment.basePrice)}</span>
                        <span className="text-sm font-normal text-gray-500">/ night</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredApartments.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-500 mb-2">No accommodations found</div>
              <div className="text-sm text-gray-400">
                {searchTerm 
                  ? 'Try adjusting your search criteria'
                  : 'Add your first property to get started'
                }
              </div>
            </div>
          )}
        </div>
      </div>

      <AddApartmentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleAddProperty}
      />
    </>
  );
};