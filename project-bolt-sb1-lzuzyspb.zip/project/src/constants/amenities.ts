export interface AmenityCategory {
  name: string;
  amenities: string[];
}

export const AMENITY_CATEGORIES: AmenityCategory[] = [
  {
    name: 'Panoramic View',
    amenities: [
      'Garden view',
      'Sea view',
      'Street view'
    ]
  },
  {
    name: 'Bathroom',
    amenities: [
      'Hairdryer',
      'Cleaning products',
      'Hot water'
    ]
  },
  {
    name: 'Bedroom & Linen',
    amenities: [
      'Washing machine',
      'Basic equipment (towels, bedsheets, soap and toilet paper)',
      'Hangers',
      'Cotton bedsheets',
      'Iron',
      'Drying rack',
      'Closet'
    ]
  },
  {
    name: 'Entertainment',
    amenities: [
      'Television',
      'Chromecast',
      'Wifi'
    ]
  },
  {
    name: 'Heating & Air Conditioning',
    amenities: [
      'Air Conditioning',
      'Fan',
      'Mobile A/C',
      'Mobile heater'
    ]
  },
  {
    name: 'Home security',
    amenities: [
      'Smoke detector'
    ]
  },
  {
    name: 'Kitchen & Dining Area',
    amenities: [
      'Kitchen',
      'Refrigerator',
      'Microwave',
      'Basic kitchen equipment',
      'Dishes & cutlery',
      'Bowls, plates, mugs, etc.',
      'Freezer',
      'Oven',
      'Coffee machine',
      'Stove',
      'Dining area'
    ]
  },
  {
    name: 'Outdoor Area',
    amenities: [
      'Balcony',
      'Outdoor furniture',
      'Outdoor dining area',
      'Sun beds'
    ]
  },
  {
    name: 'Carpark & Amenities',
    amenities: [
      'Free parking',
      'Private outdoor swimming pool'
    ]
  },
  {
    name: 'Services',
    amenities: [
      'Service animals accepted',
      'Autonomous Check In & Check Out'
    ]
  }
];

// Flatten all amenities for easy access
export const ALL_AMENITIES = AMENITY_CATEGORIES.flatMap(category => category.amenities);
