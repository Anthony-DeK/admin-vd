export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      apartments: {
        Row: {
          id: string
          name: string
          type: 'studio' | '1bed' | '2bed' | '3bed'
          max_guests: number
          location: string
          bedrooms: number
          bathrooms: number
          square_feet: number | null
          base_price: number | null
          cleaning_fee: number | null
          service_fee: number | null
          security_deposit: number | null
          currency: string | null
          is_available: boolean | null
          is_active: boolean | null
          minimum_stay: number | null
          maximum_stay: number | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          name: string
          type: 'studio' | '1bed' | '2bed' | '3bed'
          max_guests: number
          location: string
          bedrooms: number
          bathrooms: number
          square_feet?: number | null
          base_price?: number | null
          cleaning_fee?: number | null
          service_fee?: number | null
          security_deposit?: number | null
          currency?: string | null
          is_available?: boolean | null
          is_active?: boolean | null
          minimum_stay?: number | null
          maximum_stay?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          name?: string
          type?: 'studio' | '1bed' | '2bed' | '3bed'
          max_guests?: number
          location?: string
          bedrooms?: number
          bathrooms?: number
          square_feet?: number | null
          base_price?: number | null
          cleaning_fee?: number | null
          service_fee?: number | null
          security_deposit?: number | null
          currency?: string | null
          is_available?: boolean | null
          is_active?: boolean | null
          minimum_stay?: number | null
          maximum_stay?: number | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      apartment_details: {
        Row: {
          id: number
          apartment_id: string
          short_description: string | null
          long_description: string | null
          amenities: string[] | null
          house_rules: string[] | null
          cover_image: string | null
          images: string[] | null
          base_price: number
          cleaning_fee: number
          service_fee: number
          created_at: string
          updated_at: string
          check_in_instructions: string | null
          wifi_name: string | null
          wifi_password: string | null
          emergency_contact: string | null
          pets_allowed: boolean | null
          parties_allowed: boolean | null
          smoking_allowed: boolean | null
          photoshoots_allowed: boolean | null
          quiet_hours_start: string | null
          quiet_hours_end: string | null
          check_in_time: string | null
          check_out_time: string | null
          custom_house_rules: string | null
        }
        Insert: {
          id?: number
          apartment_id: string
          short_description?: string | null
          long_description?: string | null
          amenities?: string[] | null
          house_rules?: string[] | null
          cover_image?: string | null
          images?: string[] | null
          base_price?: number
          cleaning_fee?: number
          service_fee?: number
          created_at?: string
          updated_at?: string
          check_in_instructions?: string | null
          wifi_name?: string | null
          wifi_password?: string | null
          emergency_contact?: string | null
          pets_allowed?: boolean | null
          parties_allowed?: boolean | null
          smoking_allowed?: boolean | null
          photoshoots_allowed?: boolean | null
          quiet_hours_start?: string | null
          quiet_hours_end?: string | null
          check_in_time?: string | null
          check_out_time?: string | null
          custom_house_rules?: string | null
        }
        Update: {
          id?: number
          apartment_id?: string
          short_description?: string | null
          long_description?: string | null
          amenities?: string[] | null
          house_rules?: string[] | null
          cover_image?: string | null
          images?: string[] | null
          base_price?: number
          cleaning_fee?: number
          service_fee?: number
          created_at?: string
          updated_at?: string
          check_in_instructions?: string | null
          wifi_name?: string | null
          wifi_password?: string | null
          emergency_contact?: string | null
          pets_allowed?: boolean | null
          parties_allowed?: boolean | null
          smoking_allowed?: boolean | null
          photoshoots_allowed?: boolean | null
          quiet_hours_start?: string | null
          quiet_hours_end?: string | null
          check_in_time?: string | null
          check_out_time?: string | null
          custom_house_rules?: string | null
        }
      }
      apartment_images: {
        Row: {
          id: string
          apartment_id: string | null
          image_url: string
          is_primary: boolean | null
          display_order: number | null
          created_at: string | null
          updated_at: string | null
          storage_path: string | null
          alt_text: string | null
          image_type: string | null
        }
        Insert: {
          id?: string
          apartment_id?: string | null
          image_url: string
          is_primary?: boolean | null
          display_order?: number | null
          created_at?: string | null
          updated_at?: string | null
          storage_path?: string | null
          alt_text?: string | null
          image_type?: string | null
        }
        Update: {
          id?: string
          apartment_id?: string | null
          image_url?: string
          is_primary?: boolean | null
          display_order?: number | null
          created_at?: string | null
          updated_at?: string | null
          storage_path?: string | null
          alt_text?: string | null
          image_type?: string | null
        }
      }
      bookings: {
        Row: {
          id: string
          apartment_id: string | null
          guest_name: string
          guest_email: string
          guest_phone: string
          check_in: string
          check_out: string
          status: string
          total_amount: number
          guests: number
          notes: string | null
          created_at: string | null
          updated_at: string | null
          guest_address: string | null
          adults: number | null
          children: number | null
          base_amount: number | null
          cleaning_fee: number | null
          service_fee: number | null
          tax_amount: number | null
          currency: string | null
          booking_source: string | null
          special_requests: string | null
        }
        Insert: {
          id?: string
          apartment_id?: string | null
          guest_name: string
          guest_email: string
          guest_phone: string
          check_in: string
          check_out: string
          status: string
          total_amount: number
          guests: number
          notes?: string | null
          created_at?: string | null
          updated_at?: string | null
          guest_address?: string | null
          adults?: number | null
          children?: number | null
          base_amount?: number | null
          cleaning_fee?: number | null
          service_fee?: number | null
          tax_amount?: number | null
          currency?: string | null
          booking_source?: string | null
          special_requests?: string | null
        }
        Update: {
          id?: string
          apartment_id?: string | null
          guest_name?: string
          guest_email?: string
          guest_phone?: string
          check_in?: string
          check_out?: string
          status?: string
          total_amount?: number
          guests?: number
          notes?: string | null
          created_at?: string | null
          updated_at?: string | null
          guest_address?: string | null
          adults?: number | null
          children?: number | null
          base_amount?: number | null
          cleaning_fee?: number | null
          service_fee?: number | null
          tax_amount?: number | null
          currency?: string | null
          booking_source?: string | null
          special_requests?: string | null
        }
      }
      date_specific_availability: {
        Row: {
          id: string
          apartment_id: string | null
          start_date: string
          end_date: string
          is_available: boolean | null
          reason: string | null
          created_at: string | null
          updated_at: string | null
          notes: string | null
        }
        Insert: {
          id?: string
          apartment_id?: string | null
          start_date: string
          end_date: string
          is_available?: boolean | null
          reason?: string | null
          created_at?: string | null
          updated_at?: string | null
          notes?: string | null
        }
        Update: {
          id?: string
          apartment_id?: string | null
          start_date?: string
          end_date?: string
          is_available?: boolean | null
          reason?: string | null
          created_at?: string | null
          updated_at?: string | null
          notes?: string | null
        }
      }
      date_specific_pricing: {
        Row: {
          id: string
          apartment_id: string | null
          start_date: string
          end_date: string
          price_multiplier: number | null
          minimum_stay: number | null
          created_at: string | null
          updated_at: string | null
          fixed_price: number | null
          reason: string | null
        }
        Insert: {
          id?: string
          apartment_id?: string | null
          start_date: string
          end_date: string
          price_multiplier?: number | null
          minimum_stay?: number | null
          created_at?: string | null
          updated_at?: string | null
          fixed_price?: number | null
          reason?: string | null
        }
        Update: {
          id?: string
          apartment_id?: string | null
          start_date?: string
          end_date?: string
          price_multiplier?: number | null
          minimum_stay?: number | null
          created_at?: string | null
          updated_at?: string | null
          fixed_price?: number | null
          reason?: string | null
        }
      }
      booking_payments: {
        Row: {
          id: string
          booking_id: string
          amount: number
          currency: string | null
          payment_method: string | null
          payment_status: string
          transaction_id: string | null
          payment_date: string | null
          notes: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          booking_id: string
          amount: number
          currency?: string | null
          payment_method?: string | null
          payment_status?: string
          transaction_id?: string | null
          payment_date?: string | null
          notes?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          booking_id?: string
          amount?: number
          currency?: string | null
          payment_method?: string | null
          payment_status?: string
          transaction_id?: string | null
          payment_date?: string | null
          notes?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      reviews: {
        Row: {
          id: string
          booking_id: string
          apartment_id: string
          guest_name: string
          rating: number
          title: string | null
          comment: string | null
          cleanliness_rating: number | null
          communication_rating: number | null
          location_rating: number | null
          value_rating: number | null
          is_public: boolean | null
          host_response: string | null
          host_response_date: string | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          booking_id: string
          apartment_id: string
          guest_name: string
          rating: number
          title?: string | null
          comment?: string | null
          cleanliness_rating?: number | null
          communication_rating?: number | null
          location_rating?: number | null
          value_rating?: number | null
          is_public?: boolean | null
          host_response?: string | null
          host_response_date?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          booking_id?: string
          apartment_id?: string
          guest_name?: string
          rating?: number
          title?: string | null
          comment?: string | null
          cleanliness_rating?: number | null
          communication_rating?: number | null
          location_rating?: number | null
          value_rating?: number | null
          is_public?: boolean | null
          host_response?: string | null
          host_response_date?: string | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}