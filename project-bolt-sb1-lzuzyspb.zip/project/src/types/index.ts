export interface Booking {
  id: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  checkIn: string;
  checkOut: string;
  apartment: string;
  apartmentId: string;
  status: 'confirmed' | 'pending' | 'cancelled' | 'completed';
  totalAmount: number;
  guests: number;
  createdAt: string;
  notes?: string;
}

export interface Apartment {
  id: string;
  name: string;
  type: 'studio' | '1bed' | '2bed' | '3bed';
  maxGuests: number;
  location?: string;
  bedrooms?: number;
  bathrooms?: number;
  shortDescription?: string;
  longDescription?: string;
  amenities?: string[];
  houseRules?: string[];
  coverImage?: string;
  images?: string[];
  basePrice?: number;
  cleaningFee?: number;
  serviceFee?: number;
  isAvailable?: boolean;
  checkInInstructions?: string;
  minimumStay?: number;
  maximumStay?: number;
  petsAllowed?: boolean;
  partiesAllowed?: boolean;
  smokingAllowed?: boolean;
  photoshootsAllowed?: boolean;
  quietHoursStart?: string;
  quietHoursEnd?: string;
  checkInTime?: string;
  checkOutTime?: string;
  customHouseRules?: string;
  poolOpeningSeason?: string;
  poolOpeningHours?: string;
}

export interface AccommodationDetails {
  id: string;
  apartmentId: string;
  shortDescription: string;
  longDescription: string;
  amenities: string[];
  houseRules: string[];
  coverImage: string;
  images: string[];
  basePrice: number;
  cleaningFee: number;
  serviceFee: number;
  petsAllowed?: boolean;
  partiesAllowed?: boolean;
  smokingAllowed?: boolean;
  photoshootsAllowed?: boolean;
  quietHoursStart?: string;
  quietHoursEnd?: string;
  checkInTime?: string;
  checkOutTime?: string;
  customHouseRules?: string;
}

export interface CheckInAttachment {
  id: string;
  apartmentId: string;
  fileName: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: number;
  displayOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface MessageTemplate {
  id: string;
  userId: string;
  name: string;
  type: 'booking_confirmation' | 'booking_cancellation' | 'check_in_reminder' | 'check_out_reminder' | 'post_checkout' | 'custom';
  subject: string;
  body: string;
  scheduleType: 'immediate' | 'before' | 'after';
  scheduleValue: number;
  scheduleUnit: 'hours' | 'days';
  scheduleEvent: 'booking_confirmed' | 'booking_cancelled' | 'check_in' | 'check_out';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TemplateAttachment {
  id: string;
  templateId: string;
  fileName: string;
  storagePath: string;
  fileSize: number;
  mimeType: string;
  createdAt: string;
}

export interface UserSettings {
  id: string;
  userId: string;
  senderEmail: string;
  senderName: string;
  createdAt: string;
  updatedAt: string;
}