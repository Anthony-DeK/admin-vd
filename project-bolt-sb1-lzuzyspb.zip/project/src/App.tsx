import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './components/LoginPage';
import { LoadingSpinner } from './components/LoadingSpinner';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { BookingCalendar } from './components/BookingCalendar';
import { BookingsList } from './components/BookingsList';
import { BookingModal } from './components/BookingModal';
import { AccommodationsList } from './components/AccommodationsList';
import { AccommodationDetails } from './components/AccommodationDetails';
import { CalendarView } from './components/CalendarView';
import { MessageTemplates } from './components/MessageTemplates';
import { Settings } from './components/Settings';
import { ErrorMessage } from './components/ErrorMessage';
import { useApartments } from './hooks/useApartments';
import { useBookings } from './hooks/useBookings';
import { Booking, Apartment } from './types';
import { ApartmentFormData } from './components/AddPropertyModal';

const AppContent: React.FC = () => {
  const { user, loading: authLoading, isGuestMode } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | undefined>();
  const [selectedApartment, setSelectedApartment] = useState<Apartment | undefined>();
  const [selectedCalendarApartment, setSelectedCalendarApartment] = useState<Apartment | undefined>();

  const { apartments, loading: apartmentsLoading, error: apartmentsError, createApartment, updateApartmentDetails, refetch: refetchApartments } = useApartments();
  const { 
    bookings, 
    loading: bookingsLoading, 
    error: bookingsError,
    createBooking,
    updateBooking,
    deleteBooking,
    refetch: refetchBookings
  } = useBookings();

  // Update selectedApartment when apartments data changes
  useEffect(() => {
    if (selectedApartment && apartments.length > 0) {
      const updatedApartment = apartments.find(apt => apt.id === selectedApartment.id);
      if (updatedApartment) {
        setSelectedApartment(updatedApartment);
      }
    }
  }, [apartments, selectedApartment]);

  // Clear calendar apartment selection when changing away from calendar view
  useEffect(() => {
    if (currentView !== 'calendar') {
      setSelectedCalendarApartment(undefined);
    }
  }, [currentView]);


  // Function to update booking statuses based on current date
  const updateBookingStatuses = (bookingsList: Booking[]): Booking[] => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time to start of day for accurate comparison

    return bookingsList.map(booking => {
      const checkOutDate = new Date(booking.checkOut);
      checkOutDate.setHours(0, 0, 0, 0);

      // If booking is confirmed and check-out date has passed, mark as completed
      if (booking.status === 'confirmed' && checkOutDate < today) {
        return { ...booking, status: 'completed' as const };
      }

      return booking;
    });
  };

  // Apply status updates to bookings
  const processedBookings = updateBookingStatuses(bookings);

  // Show loading spinner while checking authentication
  if (authLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  // Show login page if user is not authenticated and not in guest mode
  if (!user && !isGuestMode) {
    return <LoginPage />;
  }

  const handleAddBooking = () => {
    setEditingBooking(undefined);
    setIsModalOpen(true);
  };

  const handleEditBooking = (booking: Booking) => {
    setEditingBooking(booking);
    setIsModalOpen(true);
  };

  const handleDeleteBooking = async (bookingId: string) => {
    if (confirm('Are you sure you want to delete this booking?')) {
      try {
        await deleteBooking(bookingId);
      } catch (error) {
        console.error('Failed to delete booking:', error);
        alert('Failed to delete booking. Please try again.');
      }
    }
  };

  const handleSaveBooking = async (bookingData: Partial<Booking>) => {
    try {
      if (editingBooking) {
        // Update existing booking
        await updateBooking(editingBooking.id, bookingData);
      } else {
        // Add new booking
        await createBooking(bookingData);
      }
      
      setIsModalOpen(false);
      setEditingBooking(undefined);
    } catch (error) {
      console.error('Failed to save booking:', error);
      alert('Failed to save booking. Please try again.');
    }
  };

  const handleAddProperty = async (apartmentData: ApartmentFormData) => {
    try {
      await createApartment(apartmentData);
    } catch (error) {
      console.error('Failed to create apartment:', error);
      throw error; // Re-throw to let the modal handle the error display
    }
  };

  const handleViewApartmentDetails = (apartment: Apartment) => {
    setSelectedApartment(apartment);
  };

  const handleBackToAccommodations = () => {
    setSelectedApartment(undefined);
  };

  const handleUpdateApartment = async (apartmentId: string, updates: any) => {
    try {
      await updateApartmentDetails(apartmentId, updates);
      // Refresh apartments data to get the latest updates
      await refetchApartments();
    } catch (error) {
      console.error('Failed to update apartment:', error);
      throw error;
    }
  };

  const handleDeleteApartment = async (apartmentId: string) => {
    try {
      // Refresh apartments data after deletion
      await refetchApartments();
      await refetchBookings();
    } catch (error) {
      console.error('Failed to refresh data after deletion:', error);
      throw error;
    }
  };

  const handleSelectCalendarApartment = (apartment: Apartment) => {
    setSelectedCalendarApartment(apartment);
  };

  const handleBackToCalendarList = () => {
    setSelectedCalendarApartment(undefined);
  };

  // Show loading state
  if (apartmentsLoading || bookingsLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar currentView={currentView} onViewChange={setCurrentView} />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <LoadingSpinner />
          </div>
        </div>
      </div>
    );
  }

  // Show error state
  if (apartmentsError || bookingsError) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar currentView={currentView} onViewChange={setCurrentView} />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <ErrorMessage 
              message={apartmentsError || bookingsError || 'An error occurred'} 
              onRetry={() => {
                refetchApartments();
                refetchBookings();
              }}
            />
          </div>
        </div>
      </div>
    );
  }


  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard bookings={processedBookings} apartments={apartments} />;
      case 'calendar':
        return (
          <CalendarView
            apartments={apartments}
            bookings={processedBookings}
            selectedApartment={selectedCalendarApartment}
            onSelectApartment={handleSelectCalendarApartment}
            onBack={handleBackToCalendarList}
          />
        );
      case 'bookings':
        return (
          <BookingsList
            bookings={processedBookings}
            onAddBooking={handleAddBooking}
            onEditBooking={handleEditBooking}
            onDeleteBooking={handleDeleteBooking}
          />
        );
      case 'accommodations':
        return selectedApartment ? (
          <AccommodationDetails
            apartment={selectedApartment}
            bookings={processedBookings}
            onBack={handleBackToAccommodations}
            onUpdateApartment={handleUpdateApartment}
            onDeleteApartment={handleDeleteApartment}
          />
        ) : (
          <AccommodationsList
            apartments={apartments}
            onViewDetails={handleViewApartmentDetails}
            onAddProperty={handleAddProperty}
          />
        );
      case 'messages':
        return <MessageTemplates />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard bookings={processedBookings} apartments={apartments} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          {renderCurrentView()}
        </div>
      </div>

      <BookingModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingBooking(undefined);
        }}
        onSave={handleSaveBooking}
        booking={editingBooking}
        apartments={apartments}
      />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
export default App;