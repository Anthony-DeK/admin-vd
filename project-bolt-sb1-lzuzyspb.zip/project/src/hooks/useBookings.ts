import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Booking } from '../types'

export const useBookings = () => {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchBookings = async () => {
    try {
      setLoading(true)
      setError(null)

      const { data, error: bookingsError } = await supabase
        .from('bookings')
        .select(`
          *,
          apartments (
            name
          )
        `)
        .order('created_at', { ascending: false })

      if (bookingsError) {
        throw bookingsError
      }

      // Transform the data to match our Booking interface
      const transformedBookings: Booking[] = (data || []).map(booking => ({
        id: booking.id,
        guestName: booking.guest_name,
        guestEmail: booking.guest_email,
        guestPhone: booking.guest_phone,
        checkIn: booking.check_in,
        checkOut: booking.check_out,
        apartment: booking.apartments?.name || 'Unknown Apartment',
        apartmentId: booking.apartment_id,
        status: booking.status as Booking['status'],
        totalAmount: booking.total_amount,
        guests: booking.guests,
        createdAt: booking.created_at || new Date().toISOString(),
        notes: booking.notes || undefined
      }))

      setBookings(transformedBookings)
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch bookings'
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const createBooking = async (bookingData: Partial<Booking>) => {
    try {
      // Find the apartment ID by name
      const { data: apartmentData, error: apartmentError } = await supabase
        .from('apartments')
        .select('id')
        .eq('name', bookingData.apartment)
        .single()

      if (apartmentError || !apartmentData) {
        throw new Error('Apartment not found')
      }

      const { data, error } = await supabase
        .from('bookings')
        .insert({
          apartment_id: apartmentData.id,
          guest_name: bookingData.guestName!,
          guest_email: bookingData.guestEmail!,
          guest_phone: bookingData.guestPhone!,
          check_in: bookingData.checkIn!,
          check_out: bookingData.checkOut!,
          status: bookingData.status!,
          total_amount: bookingData.totalAmount!,
          guests: bookingData.guests!,
          notes: bookingData.notes || null
        })
        .select()
        .single()

      if (error) {
        throw error
      }

      await fetchBookings() // Refresh the list
      return data
    } catch (err) {
      console.error('Error creating booking:', err)
      throw err
    }
  }

  const updateBooking = async (id: string, bookingData: Partial<Booking>) => {
    try {
      let apartmentId: string | undefined

      // If apartment name is being updated, find the new apartment ID
      if (bookingData.apartment) {
        const { data: apartmentData, error: apartmentError } = await supabase
          .from('apartments')
          .select('id')
          .eq('name', bookingData.apartment)
          .single()

        if (apartmentError || !apartmentData) {
          throw new Error('Apartment not found')
        }
        apartmentId = apartmentData.id
      }

      const updateData: any = {}
      if (bookingData.guestName) updateData.guest_name = bookingData.guestName
      if (bookingData.guestEmail) updateData.guest_email = bookingData.guestEmail
      if (bookingData.guestPhone) updateData.guest_phone = bookingData.guestPhone
      if (bookingData.checkIn) updateData.check_in = bookingData.checkIn
      if (bookingData.checkOut) updateData.check_out = bookingData.checkOut
      if (bookingData.status) updateData.status = bookingData.status
      if (bookingData.totalAmount !== undefined) updateData.total_amount = bookingData.totalAmount
      if (bookingData.guests !== undefined) updateData.guests = bookingData.guests
      if (bookingData.notes !== undefined) updateData.notes = bookingData.notes
      if (apartmentId) updateData.apartment_id = apartmentId

      const { error } = await supabase
        .from('bookings')
        .update(updateData)
        .eq('id', id)

      if (error) {
        throw error
      }

      await fetchBookings() // Refresh the list
    } catch (err) {
      console.error('Error updating booking:', err)
      throw err
    }
  }

  const deleteBooking = async (id: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .delete()
        .eq('id', id)

      if (error) {
        throw error
      }

      await fetchBookings() // Refresh the list
    } catch (err) {
      console.error('Error deleting booking:', err)
      throw err
    }
  }

  useEffect(() => {
    fetchBookings()
  }, [])

  return {
    bookings,
    loading,
    error,
    createBooking,
    updateBooking,
    deleteBooking,
    refetch: fetchBookings
  }
}