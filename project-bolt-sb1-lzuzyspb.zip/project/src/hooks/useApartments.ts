import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Apartment } from '../types'
import { ApartmentFormData } from '../components/AddPropertyModal'

export const useApartments = () => {
  const [apartments, setApartments] = useState<Apartment[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchApartments = async () => {
    try {
      setLoading(true)
      setError(null)

      console.log('🔄 Fetching apartments from Supabase...')
      
      // Test basic connectivity first with enhanced error handling
      try {
        const { data: testData, error: testError } = await supabase
          .from('apartments')
          .select('count')
          .limit(1)
        
        if (testError) {
          console.error('❌ Supabase connectivity test failed:', testError)
          throw new Error(`Database connection failed: ${testError.message}`)
        }
        
        console.log('✅ Supabase connectivity test passed')
      } catch (connectError) {
        if (connectError instanceof TypeError && connectError.message === 'Failed to fetch') {
          throw new Error(`
Unable to connect to Supabase database. Please check:
1. Your internet connection
2. Supabase project is running and accessible
3. CORS settings allow localhost:5173
4. No firewall/VPN blocking the connection

Technical error: ${connectError.message}
          `.trim())
        }
        throw connectError
      }

      // Fetch apartments with their details
      const { data: apartmentsData, error: apartmentsError } = await supabase
        .from('apartments')
        .select(`
          *,
          apartment_details (
            short_description,
            long_description,
            amenities,
            house_rules,
            cover_image,
            images,
            check_in_instructions,
            wifi_name,
            wifi_password,
            emergency_contact,
            pets_allowed,
            parties_allowed,
            smoking_allowed,
            photoshoots_allowed,
            quiet_hours_start,
            quiet_hours_end,
            check_in_time,
            check_out_time,
            custom_house_rules,
            pool_opening_season,
            pool_opening_hours
          ),
          apartment_images (
            image_url,
            is_primary,
            display_order
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false })

      if (apartmentsError) {
        console.error('Error fetching apartments:', apartmentsError)
        throw apartmentsError
      }

      console.log('Raw apartments data:', apartmentsData)

      // Transform the data to match our Apartment interface
      const transformedApartments: Apartment[] = (apartmentsData || []).map(apt => {
        console.log('Processing apartment:', apt.name, 'Details:', apt.apartment_details)
        
        const details = apt.apartment_details?.[0] || apt.apartment_details
        const images = apt.apartment_images || []
        const primaryImage = images.find(img => img.is_primary)
        const sortedImages = images
          .sort((a, b) => (a.display_order || 0) - (b.display_order || 0))
          .map(img => img.image_url)

        const transformed = {
          id: apt.id,
          name: apt.name,
          type: apt.type,
          maxGuests: apt.max_guests,
          location: apt.location,
          bedrooms: apt.bedrooms,
          bathrooms: apt.bathrooms,
          shortDescription: details?.short_description || '',
          longDescription: details?.long_description || '',
          amenities: details?.amenities || [],
          houseRules: details?.house_rules || [],
          coverImage: primaryImage?.image_url || details?.cover_image || sortedImages[0] || undefined,
          images: sortedImages.length > 0 ? sortedImages : details?.images || [],
          basePrice: apt.base_price || undefined,
          cleaningFee: apt.cleaning_fee || undefined,
          serviceFee: apt.service_fee || undefined,
          isAvailable: apt.is_available ?? true,
          minimumStay: apt.minimum_stay || undefined,
          maximumStay: apt.maximum_stay || undefined,
          checkInInstructions: details?.check_in_instructions || undefined,
          petsAllowed: details?.pets_allowed ?? false,
          partiesAllowed: details?.parties_allowed ?? false,
          smokingAllowed: details?.smoking_allowed ?? false,
          photoshootsAllowed: details?.photoshoots_allowed ?? false,
          quietHoursStart: details?.quiet_hours_start || undefined,
          quietHoursEnd: details?.quiet_hours_end || undefined,
          checkInTime: details?.check_in_time || undefined,
          checkOutTime: details?.check_out_time || undefined,
          customHouseRules: details?.custom_house_rules || undefined,
          poolOpeningSeason: details?.pool_opening_season || undefined,
          poolOpeningHours: details?.pool_opening_hours || undefined
        }

        console.log('Transformed apartment:', transformed.name, {
          shortDescription: transformed.shortDescription,
          longDescription: transformed.longDescription
        })

        return transformed
      })

      console.log('Final transformed apartments:', transformedApartments)
      setApartments(transformedApartments)
    } catch (err) {
      console.error('Error fetching apartments:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch apartments')
    } finally {
      setLoading(false)
    }
  }

  const createApartment = async (apartmentData: ApartmentFormData) => {
    try {
      console.log('Creating apartment with data:', apartmentData)

      // First, create the apartment
      const { data: newApartmentData, error: apartmentError } = await supabase
        .from('apartments')
        .insert({
          name: apartmentData.name,
          type: apartmentData.type,
          max_guests: apartmentData.maxGuests,
          location: apartmentData.location,
          bedrooms: apartmentData.bedrooms,
          bathrooms: apartmentData.bathrooms,
          is_available: true,
          is_active: true
        })
        .select()
        .single()

      if (apartmentError) {
        console.error('Error creating apartment:', apartmentError)
        throw apartmentError
      }

      console.log('Created apartment:', newApartmentData)

      // Then, create the corresponding apartment_details entry
      const { error: detailsError } = await supabase
        .from('apartment_details')
        .insert({
          apartment_id: newApartmentData.id,
          short_description: '',
          long_description: '',
          amenities: [],
          house_rules: [],
          base_price: 0,
          cleaning_fee: 0,
          service_fee: 0
        })

      if (detailsError) {
        console.error('Error creating apartment details:', detailsError)
        // If apartment_details creation fails, we should clean up the apartment
        await supabase
          .from('apartments')
          .delete()
          .eq('id', newApartmentData.id)

        throw detailsError
      }

      console.log('Created apartment details successfully')
      await fetchApartments() // Refresh the list
      return newApartmentData
    } catch (err) {
      console.error('Error creating apartment:', err)
      throw err
    }
  }

  const updateApartmentDetails = async (apartmentId: string, updates: {
    shortDescription?: string
    longDescription?: string
    amenities?: string[]
    houseRules?: string[]
    basePrice?: number
    cleaningFee?: number
    serviceFee?: number
    checkInInstructions?: string
    minimumStay?: number
    maximumStay?: number | null
    maxGuests?: number
    petsAllowed?: boolean
    partiesAllowed?: boolean
    smokingAllowed?: boolean
    photoshootsAllowed?: boolean
    quietHoursStart?: string
    quietHoursEnd?: string
    checkInTime?: string
    checkOutTime?: string
    customHouseRules?: string
    poolOpeningSeason?: string
    poolOpeningHours?: string
  }) => {
    try {
      console.log('Updating apartment details for:', apartmentId, updates)

      // Separate updates for apartments table and apartment_details table
      const apartmentUpdates: any = {}
      const detailsUpdates: any = {}

      // Fields that go in apartments table
      if (updates.basePrice !== undefined) {
        apartmentUpdates.base_price = updates.basePrice
      }
      if (updates.cleaningFee !== undefined) {
        apartmentUpdates.cleaning_fee = updates.cleaningFee
      }
      if (updates.serviceFee !== undefined) {
        apartmentUpdates.service_fee = updates.serviceFee
      }
      if (updates.minimumStay !== undefined) {
        apartmentUpdates.minimum_stay = updates.minimumStay
      }
      if (updates.maximumStay !== undefined) {
        apartmentUpdates.maximum_stay = updates.maximumStay
      }
      if (updates.maxGuests !== undefined) {
        apartmentUpdates.max_guests = updates.maxGuests
      }

      // Fields that go in apartment_details table
      if (updates.shortDescription !== undefined) {
        detailsUpdates.short_description = updates.shortDescription
      }
      if (updates.longDescription !== undefined) {
        detailsUpdates.long_description = updates.longDescription
      }
      if (updates.amenities !== undefined) {
        detailsUpdates.amenities = updates.amenities
      }
      if (updates.houseRules !== undefined) {
        detailsUpdates.house_rules = updates.houseRules
      }
      if (updates.checkInInstructions !== undefined) {
        detailsUpdates.check_in_instructions = updates.checkInInstructions
      }
      if (updates.petsAllowed !== undefined) {
        detailsUpdates.pets_allowed = updates.petsAllowed
      }
      if (updates.partiesAllowed !== undefined) {
        detailsUpdates.parties_allowed = updates.partiesAllowed
      }
      if (updates.smokingAllowed !== undefined) {
        detailsUpdates.smoking_allowed = updates.smokingAllowed
      }
      if (updates.photoshootsAllowed !== undefined) {
        detailsUpdates.photoshoots_allowed = updates.photoshootsAllowed
      }
      if (updates.quietHoursStart !== undefined) {
        detailsUpdates.quiet_hours_start = updates.quietHoursStart
      }
      if (updates.quietHoursEnd !== undefined) {
        detailsUpdates.quiet_hours_end = updates.quietHoursEnd
      }
      if (updates.checkInTime !== undefined) {
        detailsUpdates.check_in_time = updates.checkInTime
      }
      if (updates.checkOutTime !== undefined) {
        detailsUpdates.check_out_time = updates.checkOutTime
      }
      if (updates.customHouseRules !== undefined) {
        detailsUpdates.custom_house_rules = updates.customHouseRules
      }
      if (updates.poolOpeningSeason !== undefined) {
        detailsUpdates.pool_opening_season = updates.poolOpeningSeason
      }
      if (updates.poolOpeningHours !== undefined) {
        detailsUpdates.pool_opening_hours = updates.poolOpeningHours
      }

      // Update apartments table if needed
      if (Object.keys(apartmentUpdates).length > 0) {
        console.log('Updating apartments table:', apartmentUpdates)
        const { error: apartmentError } = await supabase
          .from('apartments')
          .update(apartmentUpdates)
          .eq('id', apartmentId)

        if (apartmentError) {
          console.error('Error updating apartments table:', apartmentError)
          throw apartmentError
        }
      }

      // Update apartment_details table if needed
      if (Object.keys(detailsUpdates).length > 0) {
        console.log('Updating apartment_details table:', detailsUpdates)

        // First, check if apartment_details record exists
        const { data: existingDetails, error: checkError } = await supabase
          .from('apartment_details')
          .select('id, apartment_id')
          .eq('apartment_id', apartmentId)
          .maybeSingle()

        if (checkError) {
          console.error('Error checking existing details:', checkError)
          throw checkError
        }

        if (existingDetails) {
          // Update existing record
          const { error } = await supabase
            .from('apartment_details')
            .update(detailsUpdates)
            .eq('apartment_id', apartmentId)

          if (error) {
            console.error('Error updating apartment_details:', error)
            throw error
          }
        } else {
          // Create new record if it doesn't exist
          const { error } = await supabase
            .from('apartment_details')
            .insert({
              apartment_id: apartmentId,
              ...detailsUpdates
            })

          if (error) {
            console.error('Error creating apartment_details:', error)
            throw error
          }
        }
      }

      console.log('Successfully updated apartment')
      await fetchApartments() // Refresh the list
    } catch (err) {
      console.error('Error updating apartment details:', err)
      // Provide more specific error message
      const errorMessage = err instanceof Error ? err.message : 'Failed to update apartment details'
      throw new Error(`Failed to save changes: ${errorMessage}`)
    }
  }

  useEffect(() => {
    fetchApartments()
  }, [])

  // Close any dropdown menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // This will be handled by individual components
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return {
    apartments,
    loading,
    error,
    createApartment,
    updateApartmentDetails,
    refetch: fetchApartments
  }
}